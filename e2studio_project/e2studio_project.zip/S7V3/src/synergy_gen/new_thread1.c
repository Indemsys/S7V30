/* generated thread source file - do not edit */
#include "new_thread1.h"

TX_THREAD new_thread1;
void new_thread1_create(void);
static void new_thread1_func(ULONG thread_input);
static uint8_t new_thread1_stack[1024] BSP_PLACE_IN_SECTION_V2(".stack.new_thread1") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
void tx_startup_err_callback(void *p_instance, void *p_data);
void tx_startup_common_init(void);
static iwdt_instance_ctrl_t g_wdt1_ctrl;

static const wdt_cfg_t g_wdt1_cfg =
{ .p_callback = NULL, };

/* Instance structure to use this module. */
const wdt_instance_t g_wdt1 =
{ .p_ctrl = &g_wdt1_ctrl, .p_cfg = &g_wdt1_cfg, .p_api = &g_wdt_on_iwdt };
static wdt_instance_ctrl_t g_wdt0_ctrl;

static const wdt_cfg_t g_wdt0_cfg =
{ .start_mode = WDT_START_MODE_REGISTER,
  .autostart = true,
  .timeout = WDT_TIMEOUT_16384,
  .clock_division = WDT_CLOCK_DIVISION_8192,
  .window_start = WDT_WINDOW_START_100,
  .window_end = WDT_WINDOW_END_0,
  .reset_control = WDT_RESET_CONTROL_RESET,
  .stop_control = WDT_STOP_CONTROL_ENABLE,
  .p_callback = NULL, };

/* Instance structure to use this module. */
const wdt_instance_t g_wdt0 =
{ .p_ctrl = &g_wdt0_ctrl, .p_cfg = &g_wdt0_cfg, .p_api = &g_wdt_on_wdt };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_rtc0) && !defined(SSP_SUPPRESS_ISR_RTC)
SSP_VECTOR_DEFINE(rtc_alarm_isr, RTC, ALARM);
#endif
#endif
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_rtc0) && !defined(SSP_SUPPRESS_ISR_RTC)
SSP_VECTOR_DEFINE(rtc_period_isr, RTC, PERIOD);
#endif
#endif
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_rtc0) && !defined(SSP_SUPPRESS_ISR_RTC)
SSP_VECTOR_DEFINE( rtc_carry_isr, RTC, CARRY);
#endif
#endif
rtc_instance_ctrl_t g_rtc0_ctrl;
const rtc_cfg_t g_rtc0_cfg =
{ .clock_source = RTC_CLOCK_SOURCE_LOCO,
  .hw_cfg = true,
  .error_adjustment_value = 0,
  .error_adjustment_type = RTC_ERROR_ADJUSTMENT_NONE,
  .p_callback = NULL,
  .p_context = &g_rtc0,
  .alarm_ipl = (BSP_IRQ_DISABLED),
  .periodic_ipl = (BSP_IRQ_DISABLED),
  .carry_ipl = (12), };
/* Instance structure to use this module. */
const rtc_instance_t g_rtc0 =
{ .p_ctrl = &g_rtc0_ctrl, .p_cfg = &g_rtc0_cfg, .p_api = &g_rtc_on_rtc };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer13) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_SCI0_RXI)
#define DTC_ACTIVATION_SRC_ELC_EVENT_SCI0_RXI
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer13_ctrl;
transfer_info_t g_transfer13_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .repeat_area = TRANSFER_REPEAT_AREA_DESTINATION,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_cfg_t g_transfer13_cfg =
{ .p_info = &g_transfer13_info,
  .activation_source = ELC_EVENT_SCI0_RXI,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer13,
  .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer13 =
{ .p_ctrl = &g_transfer13_ctrl, .p_cfg = &g_transfer13_cfg, .p_api = &g_transfer_on_dtc };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer12) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_SCI0_TXI)
#define DTC_ACTIVATION_SRC_ELC_EVENT_SCI0_TXI
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer12_ctrl;
transfer_info_t g_transfer12_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_cfg_t g_transfer12_cfg =
{ .p_info = &g_transfer12_info,
  .activation_source = ELC_EVENT_SCI0_TXI,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer12,
  .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer12 =
{ .p_ctrl = &g_transfer12_ctrl, .p_cfg = &g_transfer12_cfg, .p_api = &g_transfer_on_dtc };
#if SCI_UART_CFG_RX_ENABLE
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_uart0) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_uart_rxi_isr, SCI, RXI, 0);
#endif
#endif
#endif
#if SCI_UART_CFG_TX_ENABLE
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_uart0) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_uart_txi_isr, SCI, TXI, 0);
#endif
#endif
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_uart0) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_uart_tei_isr, SCI, TEI, 0);
#endif
#endif
#endif
#if SCI_UART_CFG_RX_ENABLE
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_uart0) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_uart_eri_isr, SCI, ERI, 0);
#endif
#endif
#endif
sci_uart_instance_ctrl_t g_uart0_ctrl;

/** UART extended configuration for UARTonSCI HAL driver */
const uart_on_sci_cfg_t g_uart0_cfg_extend =
{ .clk_src = SCI_CLK_SRC_INT, .baudclk_out = false, .rx_edge_start = true, .noisecancel_en = false, .p_extpin_ctrl =
          NULL,
  .bitrate_modulation = true, .rx_fifo_trigger = SCI_UART_RX_FIFO_TRIGGER_MAX, .baud_rate_error_x_1000 = (uint32_t) (
          2.0 * 1000),
  .uart_comm_mode = UART_MODE_RS232, .uart_rs485_mode = UART_RS485_HD, .rs485_de_pin = IOPORT_PORT_09_PIN_14, };

/** UART interface configuration */
const uart_cfg_t g_uart0_cfg =
{ .channel = 0, .baud_rate = 9600, .data_bits = UART_DATA_BITS_8, .parity = UART_PARITY_OFF, .stop_bits =
          UART_STOP_BITS_1,
  .ctsrts_en = false, .p_callback = user_uart_callback, .p_context = &g_uart0, .p_extend = &g_uart0_cfg_extend,
#define SYNERGY_NOT_DEFINED (1)                        
#if (SYNERGY_NOT_DEFINED == g_transfer12)
                .p_transfer_tx       = NULL,
#else
  .p_transfer_tx = &g_transfer12,
#endif            
#if (SYNERGY_NOT_DEFINED == g_transfer13)
                .p_transfer_rx       = NULL,
#else
  .p_transfer_rx = &g_transfer13,
#endif   
#undef SYNERGY_NOT_DEFINED            
  .rxi_ipl = (12),
  .txi_ipl = (12), .tei_ipl = (12), .eri_ipl = (BSP_IRQ_DISABLED), };

/* Instance structure to use this module. */
const uart_instance_t g_uart0 =
{ .p_ctrl = &g_uart0_ctrl, .p_cfg = &g_uart0_cfg, .p_api = &g_uart_on_sci };
uint8_t g_sf_block_media_ram0_buffer[16 * 512] BSP_PLACE_IN_SECTION_V2(".noinit") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
static sf_block_media_ram_instance_ctrl_t g_sf_block_media_ram0_ctrl;
static const sf_block_media_on_ram_cfg_t g_sf_block_media_ram0_block_media_cfg =
{ .p_ram_buffer = g_sf_block_media_ram0_buffer, .ram_buffer_size = (16 * 512) };

static sf_block_media_cfg_t g_sf_block_media_ram0_cfg =
{ .block_size = 512, .p_extend = &g_sf_block_media_ram0_block_media_cfg };

sf_block_media_instance_t g_sf_block_media_ram0 =
{ .p_ctrl = &g_sf_block_media_ram0_ctrl, .p_cfg = &g_sf_block_media_ram0_cfg, .p_api =
          &g_sf_block_media_on_sf_block_media_ram };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer11) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_ADC0_COMPARE_MATCH)
#define DTC_ACTIVATION_SRC_ELC_EVENT_ADC0_COMPARE_MATCH
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer11_ctrl;
transfer_info_t g_transfer11_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_2_BYTE,
  .mode = TRANSFER_MODE_BLOCK,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 1,
  .length = 1, };
const transfer_cfg_t g_transfer11_cfg =
{ .p_info = &g_transfer11_info, .activation_source = ELC_EVENT_ADC0_COMPARE_MATCH, .auto_enable = false, .p_callback =
          NULL,
  .p_context = &g_transfer11, .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer11 =
{ .p_ctrl = &g_transfer11_ctrl, .p_cfg = &g_transfer11_cfg, .p_api = &g_transfer_on_dtc };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_timer0) && !defined(SSP_SUPPRESS_ISR_AGT0)
SSP_VECTOR_DEFINE_CHAN(agt_int_isr, AGT, INT, 0);
#endif
#endif
static agt_instance_ctrl_t g_timer0_ctrl;
static const timer_on_agt_cfg_t g_timer0_extend =
{ .count_source = AGT_CLOCK_PCLKB,
  .agto_output_enabled = false,
  .agtio_output_enabled = false,
  .output_inverted = false,
  .agtoa_output_enable = false,
  .agtob_output_enable = false, };
static const timer_cfg_t g_timer0_cfg =
{ .mode = TIMER_MODE_PERIODIC,
  .period = 10,
  .unit = TIMER_UNIT_PERIOD_USEC,
  .channel = 0,
  .autostart = false,
  .p_callback = NULL,
  .p_context = &g_timer0,
  .p_extend = &g_timer0_extend,
  .irq_ipl = (BSP_IRQ_DISABLED), };
/* Instance structure to use this module. */
const timer_instance_t g_timer0 =
{ .p_ctrl = &g_timer0_ctrl, .p_cfg = &g_timer0_cfg, .p_api = &g_timer_on_agt };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_adc0) && !defined(SSP_SUPPRESS_ISR_ADC0)
SSP_VECTOR_DEFINE_CHAN(adc_scan_end_isr, ADC, SCAN_END, 0);
#endif
#endif
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_adc0) && !defined(SSP_SUPPRESS_ISR_ADC0)
SSP_VECTOR_DEFINE_CHAN(adc_scan_end_b_isr, ADC, SCAN_END_B, 0);
#endif
#endif
adc_instance_ctrl_t g_adc0_ctrl;
const adc_cfg_t g_adc0_cfg =
{ .unit = 0,
  .mode = ADC_MODE_SINGLE_SCAN,
  .resolution = ADC_RESOLUTION_12_BIT,
  .alignment = ADC_ALIGNMENT_RIGHT,
  .add_average_count = ADC_ADD_OFF,
  .clearing = ADC_CLEAR_AFTER_READ_ON,
  .trigger = ADC_TRIGGER_SYNC_ELC,
  .trigger_group_b = ADC_TRIGGER_SYNC_ELC,
  .p_callback = NULL,
  .p_context = &g_adc0,
  .scan_end_ipl = (BSP_IRQ_DISABLED),
  .scan_end_b_ipl = (BSP_IRQ_DISABLED),
  .calib_adc_skip = false,
  .voltage_ref = ADC_EXTERNAL_VOLTAGE,
  .over_current = OVER_CURRENT_DETECTION_ENABLE,
  .pga0 = PGA_DISABLE,
  .pga1 = PGA_DISABLE,
  .pga2 = PGA_DISABLE, };
const adc_channel_cfg_t g_adc0_channel_cfg =
{ .scan_mask = (uint32_t) (
        ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | (0)),
  /** Group B channel mask is right shifted by 32 at the end to form the proper mask */
  .scan_mask_group_b = (uint32_t) (
          (((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                  | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                  | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                  | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0)
                  | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | ((uint64_t) 0) | (0)) >> 32),
  .priority_group_a = ADC_GROUP_A_PRIORITY_OFF, .add_mask = (uint32_t) (
          (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0)
                  | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0) | (0)),
  .sample_hold_mask = (uint32_t) ((0) | (0) | (0)), .sample_hold_states = 24, };
/* Instance structure to use this module. */
const adc_instance_t g_adc0 =
{ .p_ctrl = &g_adc0_ctrl, .p_cfg = &g_adc0_cfg, .p_channel_cfg = &g_adc0_channel_cfg, .p_api = &g_adc_on_adc };
#if defined(__ICCARM__)
            #define g_sf_adc_periodic0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_adc_periodic0_err_callback  = g_sf_adc_periodic0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_adc_periodic0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sf_adc_periodic0_err_callback_internal")))
            #endif
void g_sf_adc_periodic0_err_callback(void *p_instance, void *p_data)
g_sf_adc_periodic0_err_callback_WEAK_ATTRIBUTE;
#if ADC_PERIODIC_ON_ADC_PERIODIC_CALLBACK_USED_g_sf_adc_periodic0
            void g_adc_framework_user_callback(sf_adc_periodic_callback_args_t * p_args);
            #endif
#ifdef SF_ADC_PERIODIC_PRV_ADC_RESOLUTION_24_BIT
            uint32_t g_user_buffer[128];
            #else
uint16_t g_user_buffer[128];
#endif
sf_adc_periodic_instance_ctrl_t g_sf_adc_periodic0_ctrl;
sf_adc_periodic_cfg_t g_sf_adc_periodic0_cfg =
{ .p_lower_lvl_adc = &g_adc0,
  .p_lower_lvl_timer = &g_timer0,
#define SYNERGY_NOT_DEFINED (1)
#if (SYNERGY_NOT_DEFINED == g_transfer11)
                .p_lower_lvl_transfer = NULL,
#else
  .p_lower_lvl_transfer = &g_transfer11,
#endif
  .p_data_buffer = (uint16_t*) &g_user_buffer[0],
  .lower_level = (bool) 0,
  .data_buffer_length = 128,
  .sample_count = 10,
  .p_callback = g_adc_framework_user_callback,
  .p_extend = NULL, };

sf_adc_periodic_instance_t g_sf_adc_periodic0 =
        { .p_ctrl = &g_sf_adc_periodic0_ctrl, .p_cfg = &g_sf_adc_periodic0_cfg, .p_api =
                  &g_sf_adc_periodic_on_sf_adc_periodic, };
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_adc_periodic0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_adc_periodic0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_adc_periodic0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.

 *            - void sf_adc_periodic_init0(void)
 **********************************************************************************************************************/
void sf_adc_periodic_init0(void)
{
    ssp_err_t ssp_err_g_sf_adc_periodic0;
    ssp_err_g_sf_adc_periodic0 = g_sf_adc_periodic0.p_api->open (g_sf_adc_periodic0.p_ctrl, g_sf_adc_periodic0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_adc_periodic0)
    {
        g_sf_adc_periodic0_err_callback ((void*) &g_sf_adc_periodic0, &ssp_err_g_sf_adc_periodic0);
    }
}
#if defined(__ICCARM__)
            #define g_sf_crypto_trng1_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_crypto_trng1_err_callback  = g_sf_crypto_trng1_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_crypto_trng1_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sf_crypto_trng1_err_callback_internal")))
            #endif
void g_sf_crypto_trng1_err_callback(void *p_instance, void *p_data)
g_sf_crypto_trng1_err_callback_WEAK_ATTRIBUTE;

/* Control block for g_sf_crypto_trng1. */
sf_crypto_trng_instance_ctrl_t g_sf_crypto_trng1_ctrl;

/* Configuration structure for g_sf_crypto_trng1. */
sf_crypto_trng_cfg_t g_sf_crypto_trng1_cfg =
{ .p_lower_lvl_common = (sf_crypto_instance_t*) &g_sf_crypto0,
  .p_lower_lvl_instance = (trng_instance_t*) &g_sce_trng,
  .p_extend = NULL, };
/* Instance structure for g_sf_crypto_trng1. */
sf_crypto_trng_instance_t g_sf_crypto_trng1 =
{ .p_ctrl = &g_sf_crypto_trng1_ctrl, .p_cfg = &g_sf_crypto_trng1_cfg, .p_api = &g_sf_crypto_trng_api };
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_crypto_trng1_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_crypto_trng1_err_callback_internal(void *p_instance, void *p_data);
void g_sf_crypto_trng1_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_crypto_trng_init1(void)
 **********************************************************************************************************************/
void sf_crypto_trng_init1(void)
{
    ssp_err_t ssp_err_g_sf_crypto_trng1;
    ssp_err_g_sf_crypto_trng1 = g_sf_crypto_trng1.p_api->open (g_sf_crypto_trng1.p_ctrl, g_sf_crypto_trng1.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_trng1)
    {
        g_sf_crypto_trng1_err_callback ((void*) &g_sf_crypto_trng1, &ssp_err_g_sf_crypto_trng1);
    }
}
#if defined(BSP_MCU_GROUP_S7G2) || defined(BSP_MCU_GROUP_S5D9) || defined(BSP_MCU_GROUP_S5D5) || defined(BSP_MCU_GROUP_S5D3)
            hash_ctrl_t g_sce_hash_1_ctrl;
            hash_cfg_t  g_sce_hash_1_cfg =
            {
              .p_crypto_api  = &g_sce_crypto_api
            };
            const hash_instance_t g_sce_hash_1 =
            {
                  .p_ctrl = &g_sce_hash_1_ctrl ,
                  .p_cfg  = &g_sce_hash_1_cfg  ,
                  .p_api  = &g_sha256_hash_on_sce
            };
        #else
#error  "HASH Driver on SCE Feature not available for selected MCU"
#endif
/* Control block for g_sf_crypto_hash1. */
sf_crypto_hash_instance_ctrl_t g_sf_crypto_hash1_ctrl;

/* Configuration structure for g_sf_crypto_hash1. */
sf_crypto_hash_cfg_t g_sf_crypto_hash1_cfg =
{ .hash_type = SF_CRYPTO_HASH_ALGORITHM_SHA256,
  .p_lower_lvl_crypto_common = (sf_crypto_instance_t*) &g_sf_crypto0,
  .p_lower_lvl_instance = (hash_instance_t*) &g_sce_hash_1,
  .p_extend = NULL,

};
/* Instance structure for g_sf_crypto_hash1. */
sf_crypto_hash_instance_t g_sf_crypto_hash1 =
{ .p_ctrl = &g_sf_crypto_hash1_ctrl, .p_cfg = &g_sf_crypto_hash1_cfg, .p_api = &g_sf_crypto_hash_api };

#if defined(__ICCARM__)
            #define g_sf_crypto_hash1_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_crypto_hash1_err_callback  = g_sf_crypto_hash1_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_crypto_hash1_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sf_crypto_hash1_err_callback_internal")))
            #endif
void g_sf_crypto_hash1_err_callback(void *p_instance, void *p_data)
g_sf_crypto_hash1_err_callback_WEAK_ATTRIBUTE;

/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user function 
 *             with the prototype below.
 *             - void g_sf_crypto_hash1_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used
 *             to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_crypto_hash1_err_callback_internal(void *p_instance, void *p_data);
void g_sf_crypto_hash1_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_crypto_hash_init1(void)
 **********************************************************************************************************************/
void sf_crypto_hash_init1(void)
{
    /* Open Crypto Common Framework. */
    ssp_err_t ssp_err_g_sf_crypto_hash1;
    ssp_err_g_sf_crypto_hash1 = g_sf_crypto_hash1.p_api->open (g_sf_crypto_hash1.p_ctrl, g_sf_crypto_hash1.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_hash1)
    {
        BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
    }
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_hash1)
    {
        g_sf_crypto_hash1_err_callback ((void*) &g_sf_crypto_hash1, &ssp_err_g_sf_crypto_hash1);
    }
}
#if defined(__ICCARM__)
            #define g_sf_crypto_signature0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_crypto_signature0_err_callback  = g_sf_crypto_signature0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_crypto_signature0_err_callback_WEAK_ATTRIBUTE __attribute__ ((weak, alias("g_sf_crypto_signature0_err_callback_internal")))
            #endif
void g_sf_crypto_signature0_err_callback(void *p_instance, void *p_data)
g_sf_crypto_signature0_err_callback_WEAK_ATTRIBUTE;

#if (2400 < MIN_MEMORY_POOL_SIZE)
            #error  "Default Byte Pool size must be greater than or equal to 1450-Bytes"
            #undef MIN_MEMORY_POOL_SIZE
            #endif /* End of memory pool size condition */

/* Control block for g_sf_crypto_signature0. */
sf_crypto_signature_instance_ctrl_t g_sf_crypto_signature0_ctrl;

/* Configuration structure for g_sf_crypto_signature0. */
sf_crypto_signature_cfg_t g_sf_crypto_signature0_cfg =
{ .key_type = SF_CRYPTO_KEY_TYPE_RSA_PLAIN_TEXT, .key_size = SF_CRYPTO_KEY_SIZE_RSA_2048, .p_lower_lvl_sf_crypto_hash =
          (sf_crypto_hash_instance_t*) &g_sf_crypto_hash1,
  .p_lower_lvl_crypto_common = (sf_crypto_instance_t*) &g_sf_crypto0, .p_extend = NULL,

};

/* Instance structure for g_sf_crypto_signature0. */
sf_crypto_signature_instance_t g_sf_crypto_signature0 =
{ .p_ctrl = &g_sf_crypto_signature0_ctrl, .p_cfg = &g_sf_crypto_signature0_cfg, .p_api =
          &g_sf_crypto_signature_on_sf_crypto_signature };

/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_crypto_signature0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_crypto_signature0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_crypto_signature0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_crypto_signature_init0(void)
 **********************************************************************************************************************/
void sf_crypto_signature_init0(void)
{
    ssp_err_t ssp_err_g_sf_crypto_signature0;
    ssp_err_g_sf_crypto_signature0 = g_sf_crypto_signature0.p_api->open (g_sf_crypto_signature0.p_ctrl,
                                                                         g_sf_crypto_signature0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_signature0)
    {
        g_sf_crypto_signature0_err_callback ((void*) &g_sf_crypto_signature0, &ssp_err_g_sf_crypto_signature0);
    }
}
#if (defined(BSP_MCU_GROUP_S124) || defined(BSP_MCU_GROUP_S128) || defined(BSP_MCU_GROUP_S1JA))
            #error  "Key Installation not available for S1 Series MCUs"
            #else

/* Control block for g_sce_key_installation_0. */
key_installation_instance_ctrl_t g_sce_key_installation_0_ctrl;

/* Configuration structure for g_sce_key_installation_0. */
key_installation_cfg_t g_sce_key_installation_0_cfg =
{ .p_lower_lvl_crypto_api = &g_sce_crypto_api, .p_extend = NULL,

};
/* Instance structure for g_sce_key_installation_0. */
key_installation_instance_t g_sce_key_installation_0 =
        { .p_ctrl = &g_sce_key_installation_0_ctrl, .p_cfg = &g_sce_key_installation_0_cfg, .p_api =
                  &g_key_installation_on_sce };

#endif
#define SF_CRYPTO_KEY_TYPE_ENCRYPTED_RSA_PRIVATE_KEY 100
#define SF_CRYPTO_KEY_SIZE_RSA_1024                  110
#define SF_CRYPTO_KEY_SIZE_RSA_2048                  120
#define SF_CRYPTO_KEY_TYPE_ENCRYPTED_AES_KEY         200
#define SF_CRYPTO_KEY_SIZE_AES_128                   210
#define SF_CRYPTO_KEY_SIZE_AES_XTS_128               220 
#define SF_CRYPTO_KEY_SIZE_AES_192                   230
#define SF_CRYPTO_KEY_SIZE_AES_256                   240
#define SF_CRYPTO_KEY_SIZE_AES_XTS_256               250
#define SF_CRYPTO_KEY_TYPE_ENCRYPTED_ECC_PRIVATE_KEY 300
#define SF_CRYPTO_KEY_SIZE_ECC_192                   310
#define SF_CRYPTO_KEY_SIZE_ECC_256                   320
#if (SF_CRYPTO_KEY_TYPE_ENCRYPTED_RSA_PRIVATE_KEY == 100)
#if !((SF_CRYPTO_KEY_SIZE_RSA_2048 == 110) || \
                 (SF_CRYPTO_KEY_SIZE_RSA_2048 == 120))
            #error "Incorrect Key Type and Key Size pair."
            #endif
#endif
#if (SF_CRYPTO_KEY_TYPE_ENCRYPTED_RSA_PRIVATE_KEY == 200)
            #if !((SF_CRYPTO_KEY_SIZE_RSA_2048 == 210) || \
                 (SF_CRYPTO_KEY_SIZE_RSA_2048 == 220) ||  \
                 (SF_CRYPTO_KEY_SIZE_RSA_2048 == 230) ||  \
                 (SF_CRYPTO_KEY_SIZE_RSA_2048 == 240) ||  \
                 (SF_CRYPTO_KEY_SIZE_RSA_2048 == 250))
            #error "Incorrect Key Type and Key Size pair."
            #endif
            #endif
#if (SF_CRYPTO_KEY_TYPE_ENCRYPTED_RSA_PRIVATE_KEY == 300)
            #if !((SF_CRYPTO_KEY_SIZE_RSA_2048 == 310) || \
                (SF_CRYPTO_KEY_SIZE_RSA_2048 == 320))
            #error "Incorrect Key Type and Key Size pair."
            #endif
            #endif
#undef SF_CRYPTO_KEY_TYPE_ENCRYPTED_RSA_PRIVATE_KEY
#undef SF_CRYPTO_KEY_SIZE_RSA_1024
#undef SF_CRYPTO_KEY_SIZE_RSA_2048
#undef SF_CRYPTO_KEY_TYPE_ENCRYPTED_AES_KEY
#undef SF_CRYPTO_KEY_SIZE_AES_128
#undef SF_CRYPTO_KEY_SIZE_AES_XTS_128
#undef SF_CRYPTO_KEY_SIZE_AES_192
#undef SF_CRYPTO_KEY_SIZE_AES_256
#undef SF_CRYPTO_KEY_SIZE_AES_XTS_256
#undef SF_CRYPTO_KEY_TYPE_ENCRYPTED_ECC_PRIVATE_KEY
#undef SF_CRYPTO_KEY_SIZE_ECC_192
#undef SF_CRYPTO_KEY_SIZE_ECC_256
#if defined(__ICCARM__)
            #define g_sf_crypto_key_installation0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_crypto_key_installation0_err_callback  = g_sf_crypto_key_installation0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_crypto_key_installation0_err_callback_WEAK_ATTRIBUTE __attribute__ ((weak, alias("g_sf_crypto_key_installation0_err_callback_internal")))
            #endif
void g_sf_crypto_key_installation0_err_callback(void *p_instance, void *p_data)
g_sf_crypto_key_installation0_err_callback_WEAK_ATTRIBUTE;

/* Control block for g_sf_crypto_key_installation0. */
sf_crypto_key_installation_instance_ctrl_t g_sf_crypto_key_installation0_ctrl;

/* Configuration structure for g_sf_crypto_key_installation0. */
sf_crypto_key_installation_cfg_t g_sf_crypto_key_installation0_cfg =
{ .key_type = SF_CRYPTO_KEY_TYPE_ENCRYPTED_RSA_PRIVATE_KEY,
  .key_size = SF_CRYPTO_KEY_SIZE_RSA_2048,
  .p_lower_lvl_common = (sf_crypto_instance_t*) &g_sf_crypto0,
  .p_lower_lvl_instance = (key_installation_instance_t*) &g_sce_key_installation_0,
  .p_extend = NULL,

};
/* Instance structure for g_sf_crypto_key_installation0. */
sf_crypto_key_installation_instance_t g_sf_crypto_key_installation0 =
{ .p_ctrl = &g_sf_crypto_key_installation0_ctrl, .p_cfg = &g_sf_crypto_key_installation0_cfg, .p_api =
          &g_sf_crypto_key_installation_api };

/*******************************************************************************************************************//**
 * @brief  This is a weak example initialization error function. 
 *         It should be overridden by defining a user  function 
 *         with the prototype below.
 *         - void g_sf_crypto_key_installation0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback  
 *             arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_crypto_key_installation0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_crypto_key_installation0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_crypto_key_installation_init0(void)
 **********************************************************************************************************************/
void sf_crypto_key_installation_init0(void)
{
    ssp_err_t ssp_err_g_sf_crypto_key_installation0;
    ssp_err_g_sf_crypto_key_installation0 = g_sf_crypto_key_installation0.p_api->open (
            g_sf_crypto_key_installation0.p_ctrl, g_sf_crypto_key_installation0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_key_installation0)
    {
        g_sf_crypto_key_installation0_err_callback ((void*) &g_sf_crypto_key_installation0,
                                                    &ssp_err_g_sf_crypto_key_installation0);
    }
}
#if defined(__ICCARM__)
            #define g_sf_crypto_key0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_crypto_key0_err_callback  = g_sf_crypto_key0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_crypto_key0_err_callback_WEAK_ATTRIBUTE __attribute__ ((weak, alias("g_sf_crypto_key0_err_callback_internal")))
            #endif
void g_sf_crypto_key0_err_callback(void *p_instance, void *p_data)
g_sf_crypto_key0_err_callback_WEAK_ATTRIBUTE;

#define SF_CRYPTO_KEY_TYPE_RSA_PLAIN_TEXT 100
#define SF_CRYPTO_KEY_TYPE_RSA_CRT_PLAIN_TEXT 200
#define SF_CRYPTO_KEY_TYPE_RSA_WRAPPED 300
#define SF_CRYPTO_KEY_TYPE_AES_WRAPPED 400
#define SF_CRYPTO_KEY_TYPE_ECC_PLAIN_TEXT 500
#define SF_CRYPTO_KEY_TYPE_ECC_WRAPPED 600

#define SF_CRYPTO_KEY_SIZE_RSA_1024 100
#define SF_CRYPTO_KEY_SIZE_RSA_2048 200
#define SF_CRYPTO_KEY_SIZE_AES_128 300
#define SF_CRYPTO_KEY_SIZE_AES_XTS_128 400
#define SF_CRYPTO_KEY_SIZE_AES_192 500
#define SF_CRYPTO_KEY_SIZE_AES_256 600
#define SF_CRYPTO_KEY_SIZE_AES_XTS_256 700
#define SF_CRYPTO_KEY_SIZE_ECC_192 800
#define SF_CRYPTO_KEY_SIZE_ECC_224 900
#define SF_CRYPTO_KEY_SIZE_ECC_256 1000
#define SF_CRYPTO_KEY_SIZE_ECC_384 1100

#if ((SF_CRYPTO_KEY_TYPE_RSA_PLAIN_TEXT == SF_CRYPTO_KEY_TYPE_ECC_PLAIN_TEXT) || \
                 (SF_CRYPTO_KEY_TYPE_RSA_PLAIN_TEXT == SF_CRYPTO_KEY_TYPE_ECC_WRAPPED))

            #ifndef DEFINE_ECC_INPUT_PARAMETERS
            #define DEFINE_ECC_INPUT_PARAMETERS
            #endif /* End of DEFINE_ECC_INPUT_PARAMETERS */

            #define NUMBER_OF_BYTES_IN_WORD                (4U)

            #if (SF_CRYPTO_KEY_SIZE_RSA_2048 == SF_CRYPTO_KEY_SIZE_ECC_192)
            #define ECC_DOMAIN_PARAMETER_WITH_ORDER_LENGTH_WORDS        (24U)
            #define ECC_GENERATOR_POINT_LENGTH_WORDS                    (12U)
            #elif (SF_CRYPTO_KEY_SIZE_RSA_2048 == SF_CRYPTO_KEY_SIZE_ECC_224)
            #define ECC_DOMAIN_PARAMETER_WITH_ORDER_LENGTH_WORDS        (28U)
            #define ECC_GENERATOR_POINT_LENGTH_WORDS                    (14U)			
            #elif (SF_CRYPTO_KEY_SIZE_RSA_2048 == SF_CRYPTO_KEY_SIZE_ECC_256)
            #define ECC_DOMAIN_PARAMETER_WITH_ORDER_LENGTH_WORDS        (32U)
            #define ECC_GENERATOR_POINT_LENGTH_WORDS                    (16U)
            #elif (SF_CRYPTO_KEY_SIZE_RSA_2048 == SF_CRYPTO_KEY_SIZE_ECC_384)
            #define ECC_DOMAIN_PARAMETER_WITH_ORDER_LENGTH_WORDS        (48U)
            #define ECC_GENERATOR_POINT_LENGTH_WORDS                    (24U)			
            #else
            /* Do Nothing */
            #endif /* End of ECC key_size check. */

            /* User Must declare 2 parameters at global scope and fill the data, before Build */
            extern uint8_t sf_crypto_key_domain_params0[ECC_DOMAIN_PARAMETER_WITH_ORDER_LENGTH_WORDS*NUMBER_OF_BYTES_IN_WORD];
            extern uint8_t sf_crypto_key_generator_point0[ECC_GENERATOR_POINT_LENGTH_WORDS*NUMBER_OF_BYTES_IN_WORD];
            #endif /* End of ECC Check */

#undef SF_CRYPTO_KEY_SIZE_RSA_1024
#undef SF_CRYPTO_KEY_SIZE_RSA_2048
#undef SF_CRYPTO_KEY_SIZE_AES_128
#undef SF_CRYPTO_KEY_SIZE_AES_XTS_128
#undef SF_CRYPTO_KEY_SIZE_AES_192
#undef SF_CRYPTO_KEY_SIZE_AES_256
#undef SF_CRYPTO_KEY_SIZE_AES_XTS_256
#undef SF_CRYPTO_KEY_SIZE_ECC_192
#undef SF_CRYPTO_KEY_SIZE_ECC_224			
#undef SF_CRYPTO_KEY_SIZE_ECC_256
#undef SF_CRYPTO_KEY_SIZE_ECC_384

#undef SF_CRYPTO_KEY_TYPE_RSA_PLAIN_TEXT
#undef SF_CRYPTO_KEY_TYPE_RSA_CRT_PLAIN_TEXT
#undef SF_CRYPTO_KEY_TYPE_RSA_WRAPPED
#undef SF_CRYPTO_KEY_TYPE_AES_WRAPPED
#undef SF_CRYPTO_KEY_TYPE_ECC_PLAIN_TEXT
#undef SF_CRYPTO_KEY_TYPE_ECC_WRAPPED

/* Control block for g_sf_crypto_key0. */
sf_crypto_key_instance_ctrl_t g_sf_crypto_key0_ctrl;

/* Configuration structure for g_sf_crypto_key0. */
sf_crypto_key_cfg_t g_sf_crypto_key0_cfg =
{ .key_type = SF_CRYPTO_KEY_TYPE_RSA_PLAIN_TEXT, .key_size = SF_CRYPTO_KEY_SIZE_RSA_2048,
#ifdef DEFINE_ECC_INPUT_PARAMETERS
                .domain_params             = {&sf_crypto_key_domain_params0[0], ECC_DOMAIN_PARAMETER_WITH_ORDER_LENGTH_WORDS*NUMBER_OF_BYTES_IN_WORD},
                .generator_point           = {&sf_crypto_key_generator_point0[0], ECC_GENERATOR_POINT_LENGTH_WORDS*NUMBER_OF_BYTES_IN_WORD},
            #undef ECC_DOMAIN_PARAMETER_WITH_ORDER_LENGTH_WORDS
            #undef ECC_GENERATOR_POINT_LENGTH_WORDS
            #undef DEFINE_ECC_INPUT_PARAMETERS
            #else
  .domain_params =
  { NULL, 0 },
  .generator_point =
  { NULL, 0 },
#endif
  .p_lower_lvl_crypto_common = (sf_crypto_instance_t*) &g_sf_crypto0,
  .p_extend = NULL,

};

/* Instance structure for g_sf_crypto_key0. */
sf_crypto_key_instance_t g_sf_crypto_key0 =
{ .p_ctrl = &g_sf_crypto_key0_ctrl, .p_cfg = &g_sf_crypto_key0_cfg, .p_api = &g_sf_crypto_key_api };

/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_crypto_key0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_crypto_key0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_crypto_key0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_crypto_key_init0(void)
 **********************************************************************************************************************/
void sf_crypto_key_init0(void)
{
    ssp_err_t ssp_err_g_sf_crypto_key0;
    ssp_err_g_sf_crypto_key0 = g_sf_crypto_key0.p_api->open (g_sf_crypto_key0.p_ctrl, g_sf_crypto_key0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_key0)
    {
        g_sf_crypto_key0_err_callback ((void*) &g_sf_crypto_key0, &ssp_err_g_sf_crypto_key0);
    }
}
#if defined(BSP_MCU_GROUP_S7G2) || defined(BSP_MCU_GROUP_S5D9) || defined(BSP_MCU_GROUP_S5D5) || defined(BSP_MCU_GROUP_S5D3)
            hash_ctrl_t g_sce_hash_0_ctrl;
            hash_cfg_t  g_sce_hash_0_cfg =
            {
              .p_crypto_api  = &g_sce_crypto_api
            };
            const hash_instance_t g_sce_hash_0 =
            {
                  .p_ctrl = &g_sce_hash_0_ctrl ,
                  .p_cfg  = &g_sce_hash_0_cfg  ,
                  .p_api  = &g_sha256_hash_on_sce
            };
        #else
#error  "HASH Driver on SCE Feature not available for selected MCU"
#endif
/* Control block for g_sf_crypto_hash0. */
sf_crypto_hash_instance_ctrl_t g_sf_crypto_hash0_ctrl;

/* Configuration structure for g_sf_crypto_hash0. */
sf_crypto_hash_cfg_t g_sf_crypto_hash0_cfg =
{ .hash_type = SF_CRYPTO_HASH_ALGORITHM_SHA256,
  .p_lower_lvl_crypto_common = (sf_crypto_instance_t*) &g_sf_crypto0,
  .p_lower_lvl_instance = (hash_instance_t*) &g_sce_hash_0,
  .p_extend = NULL,

};
/* Instance structure for g_sf_crypto_hash0. */
sf_crypto_hash_instance_t g_sf_crypto_hash0 =
{ .p_ctrl = &g_sf_crypto_hash0_ctrl, .p_cfg = &g_sf_crypto_hash0_cfg, .p_api = &g_sf_crypto_hash_api };

#if defined(__ICCARM__)
            #define g_sf_crypto_hash0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_crypto_hash0_err_callback  = g_sf_crypto_hash0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_crypto_hash0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sf_crypto_hash0_err_callback_internal")))
            #endif
void g_sf_crypto_hash0_err_callback(void *p_instance, void *p_data)
g_sf_crypto_hash0_err_callback_WEAK_ATTRIBUTE;

/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user function 
 *             with the prototype below.
 *             - void g_sf_crypto_hash0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used
 *             to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_crypto_hash0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_crypto_hash0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_crypto_hash_init0(void)
 **********************************************************************************************************************/
void sf_crypto_hash_init0(void)
{
    /* Open Crypto Common Framework. */
    ssp_err_t ssp_err_g_sf_crypto_hash0;
    ssp_err_g_sf_crypto_hash0 = g_sf_crypto_hash0.p_api->open (g_sf_crypto_hash0.p_ctrl, g_sf_crypto_hash0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_hash0)
    {
        BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
    }
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_hash0)
    {
        g_sf_crypto_hash0_err_callback ((void*) &g_sf_crypto_hash0, &ssp_err_g_sf_crypto_hash0);
    }
}
#if defined(__ICCARM__)
            #define g_sf_crypto_trng0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_crypto_trng0_err_callback  = g_sf_crypto_trng0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_crypto_trng0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sf_crypto_trng0_err_callback_internal")))
            #endif
void g_sf_crypto_trng0_err_callback(void *p_instance, void *p_data)
g_sf_crypto_trng0_err_callback_WEAK_ATTRIBUTE;

/* Control block for g_sf_crypto_trng0. */
sf_crypto_trng_instance_ctrl_t g_sf_crypto_trng0_ctrl;

/* Configuration structure for g_sf_crypto_trng0. */
sf_crypto_trng_cfg_t g_sf_crypto_trng0_cfg =
{ .p_lower_lvl_common = (sf_crypto_instance_t*) &g_sf_crypto0,
  .p_lower_lvl_instance = (trng_instance_t*) &g_sce_trng,
  .p_extend = NULL, };
/* Instance structure for g_sf_crypto_trng0. */
sf_crypto_trng_instance_t g_sf_crypto_trng0 =
{ .p_ctrl = &g_sf_crypto_trng0_ctrl, .p_cfg = &g_sf_crypto_trng0_cfg, .p_api = &g_sf_crypto_trng_api };
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_crypto_trng0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_crypto_trng0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_crypto_trng0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_crypto_trng_init0(void)
 **********************************************************************************************************************/
void sf_crypto_trng_init0(void)
{
    ssp_err_t ssp_err_g_sf_crypto_trng0;
    ssp_err_g_sf_crypto_trng0 = g_sf_crypto_trng0.p_api->open (g_sf_crypto_trng0.p_ctrl, g_sf_crypto_trng0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_trng0)
    {
        g_sf_crypto_trng0_err_callback ((void*) &g_sf_crypto_trng0, &ssp_err_g_sf_crypto_trng0);
    }
}
#if defined(__ICCARM__)
            #define g_sf_crypto_cipher0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_crypto_cipher0_err_callback  = g_sf_crypto_cipher0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_crypto_cipher0_err_callback_WEAK_ATTRIBUTE __attribute__ ((weak, alias("g_sf_crypto_cipher0_err_callback_internal")))
            #endif
void g_sf_crypto_cipher0_err_callback(void *p_instance, void *p_data)
g_sf_crypto_cipher0_err_callback_WEAK_ATTRIBUTE;

/* Control block for g_sf_crypto_cipher0. */
sf_crypto_cipher_instance_ctrl_t g_sf_crypto_cipher0_ctrl;

/* Configuration structure for g_sf_crypto_cipher0. */
sf_crypto_cipher_cfg_t g_sf_crypto_cipher0_cfg =
{ .key_type = SF_CRYPTO_KEY_TYPE_RSA_PLAIN_TEXT, .key_size = SF_CRYPTO_KEY_SIZE_RSA_2048, .cipher_chaining_mode =
          SF_CRYPTO_CIPHER_MODE_ECB,
  .p_lower_lvl_crypto_common = (sf_crypto_instance_t*) &g_sf_crypto0, .p_lower_lvl_crypto_trng =
          (sf_crypto_trng_instance_t*) &g_sf_crypto_trng0,
  .p_extend = NULL,

};
/* Instance structure for g_sf_crypto_cipher0. */
sf_crypto_cipher_instance_t g_sf_crypto_cipher0 =
{ .p_ctrl = &g_sf_crypto_cipher0_ctrl, .p_cfg = &g_sf_crypto_cipher0_cfg, .p_api =
          &g_sf_crypto_cipher_on_sf_crypto_cipher };

/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_crypto_cipher0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_crypto_cipher0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_crypto_cipher0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_crypto_cipher_init0(void)
 **********************************************************************************************************************/
void sf_crypto_cipher_init0(void)
{
    ssp_err_t ssp_err_g_sf_crypto_cipher0;
    ssp_err_g_sf_crypto_cipher0 = g_sf_crypto_cipher0.p_api->open (g_sf_crypto_cipher0.p_ctrl,
                                                                   g_sf_crypto_cipher0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto_cipher0)
    {
        g_sf_crypto_cipher0_err_callback ((void*) &g_sf_crypto_cipher0, &ssp_err_g_sf_crypto_cipher0);
    }
}
can_bit_timing_cfg_t g_can1_bit_timing_cfg =
{ .baud_rate_prescaler = 5,
  .time_segment_1 = CAN_TIME_SEGMENT1_TQ15,
  .time_segment_2 = CAN_TIME_SEGMENT2_TQ8,
  .synchronization_jump_width = CAN_SYNC_JUMP_WIDTH_TQ2, };

uint32_t g_can1_mailbox_mask[CAN_NO_OF_MAILBOXES_g_can1 / 4] =
{ 0x1FFFFFFF,
#if CAN_NO_OF_MAILBOXES_g_can1 > 4
0x1FFFFFFF,
#endif
#if CAN_NO_OF_MAILBOXES_g_can1 > 8
0x1FFFFFFF,
0x1FFFFFFF,
#endif
#if CAN_NO_OF_MAILBOXES_g_can1 > 16
0x1FFFFFFF,
0x1FFFFFFF,
0x1FFFFFFF,
0x1FFFFFFF,
#endif
        };

static const can_extended_cfg_t g_can1_extended_cfg =
{ .clock_source = CAN_CLOCK_SOURCE_PCLKB, .p_mailbox_mask = g_can1_mailbox_mask, };

can_mailbox_t g_can1_mailbox[CAN_NO_OF_MAILBOXES_g_can1] =
{
{ .mailbox_id = 0, .mailbox_type = CAN_MAILBOX_TRANSMIT, .frame_type = CAN_FRAME_TYPE_REMOTE },
  { .mailbox_id = 1, .mailbox_type = CAN_MAILBOX_RECEIVE, .frame_type = CAN_FRAME_TYPE_DATA },
  { .mailbox_id = 2, .mailbox_type = CAN_MAILBOX_RECEIVE, .frame_type = CAN_FRAME_TYPE_DATA, },
  { .mailbox_id = 3, .mailbox_type = CAN_MAILBOX_RECEIVE, .frame_type = CAN_FRAME_TYPE_DATA },
#if CAN_NO_OF_MAILBOXES_g_can1 > 4
    {
        .mailbox_id              =  4,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  5,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  6,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  7,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
#endif
#if CAN_NO_OF_MAILBOXES_g_can1 > 8
    {
        .mailbox_id              =  8,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  9,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  10,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  11,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  12,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA,
    },
    {
        .mailbox_id              =  13,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  14,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  15,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
#endif  
#if CAN_NO_OF_MAILBOXES_g_can1 > 16
    {
        .mailbox_id              =  16,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    
    {
        .mailbox_id              =  17,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  18,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  19,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  20,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  21,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  22,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA,
    },
    {
        .mailbox_id              =  23,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  24,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  25,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  26,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  27,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  28,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  29,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  30,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    },
    {
        .mailbox_id              =  31,
        .mailbox_type            =  CAN_MAILBOX_RECEIVE,
        .frame_type              =  CAN_FRAME_TYPE_DATA
    }
#endif  
        };

#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_can1) && !defined(SSP_SUPPRESS_ISR_CAN0)
SSP_VECTOR_DEFINE_CHAN(can_error_isr, CAN, ERROR, 0);
#endif
#endif
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_can1) && !defined(SSP_SUPPRESS_ISR_CAN0)
SSP_VECTOR_DEFINE_CHAN(can_mailbox_rx_isr, CAN, MAILBOX_RX, 0);
#endif
#endif
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_can1) && !defined(SSP_SUPPRESS_ISR_CAN0)
SSP_VECTOR_DEFINE_CHAN(can_mailbox_tx_isr, CAN, MAILBOX_TX, 0);
#endif
#endif

static can_instance_ctrl_t g_can1_ctrl;
static const can_cfg_t g_can1_cfg =
{ .channel = 0, .p_bit_timing = &g_can1_bit_timing_cfg, .id_mode = CAN_ID_MODE_STANDARD, .mailbox_count =
          CAN_NO_OF_MAILBOXES_g_can1,
  .p_mailbox = g_can1_mailbox, .message_mode = CAN_MESSAGE_MODE_OVERWRITE, .p_callback = CAN_callback, .p_extend =
          &g_can1_extended_cfg,
  .p_context = &g_can1, .error_ipl = (12), .mailbox_tx_ipl = (12), .mailbox_rx_ipl = (12), };
/* Instance structure to use this module. */
const can_instance_t g_can1 =
{ .p_ctrl = &g_can1_ctrl, .p_cfg = &g_can1_cfg, .p_api = &g_can_on_can };

extern bool g_ssp_common_initialized;
extern uint32_t g_ssp_common_thread_count;
extern TX_SEMAPHORE g_ssp_common_initialized_semaphore;

void new_thread1_create(void)
{
    /* Increment count so we will know the number of ISDE created threads. */
    g_ssp_common_thread_count++;

    /* Initialize each kernel object. */

    UINT err;
    err = tx_thread_create (&new_thread1, (CHAR*) "New Thread", new_thread1_func, (ULONG) NULL, &new_thread1_stack,
                            1024, 1, 1, 1, TX_AUTO_START);
    if (TX_SUCCESS != err)
    {
        tx_startup_err_callback (&new_thread1, 0);
    }
}

static void new_thread1_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize common components */
    tx_startup_common_init ();

    /* Initialize each module instance. */
    /** Call initialization function if user has selected to do so. */
#if (1)
    sf_adc_periodic_init0 ();
#endif
    /** Call initialization function for g_sf_crypto_trng1. */
#if (1)
    /** Call initialization function if user has selected to do so. */
    sf_crypto_trng_init1 ();
#endif
    /** Call initialization function for g_sf_crypto_signature0. */
#if (1)
    /** Call initialization function if user has selected to do so. */
    sf_crypto_signature_init0 ();
#endif
    /** Call initialization function for g_sf_crypto_key_installation0. */
#if (1)
    /** Call initialization function if user has selected to do so. */
    sf_crypto_key_installation_init0 ();
#endif
    /** Call initialization function for g_sf_crypto_key0. */
#if (1)
    /** Call initialization function if user has selected to do so. */
    sf_crypto_key_init0 ();
#endif
    /** Call initialization function for g_sf_crypto_hash0. */
#if (1)
    sf_crypto_hash_init0 ();
#endif
    /** Call initialization function for g_sf_crypto_cipher0. */
#if (1)
    /** Call initialization function if user has selected to do so. */
    sf_crypto_cipher_init0 ();
#endif

    /* Enter user code for this thread. */
    new_thread1_entry ();
}
