/* generated common source file - do not edit */
#include "common_data.h"

#define UX_DCD_SYNERGY_USBFS_VECTOR
#define UX_HOST_INITIALIZE

#ifndef NX_DISABLE_IPV6
#ifndef FILL_NXD_IPV6_ADDRESS
#define FILL_NXD_IPV6_ADDRESS(ipv6,f0,f1,f2,f3,f4,f5,f6,f7) do { \
                                                                       ipv6.nxd_ip_address.v6[0] = (((uint32_t)f0 << 16) & 0xFFFF0000) | ((uint32_t)f1 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[1] = (((uint32_t)f2 << 16) & 0xFFFF0000) | ((uint32_t)f3 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[2] = (((uint32_t)f4 << 16) & 0xFFFF0000) | ((uint32_t)f5 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[3] = (((uint32_t)f6 << 16) & 0xFFFF0000) | ((uint32_t)f7 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_version       = NX_IP_VERSION_V6;\
                                                                   } while(0);
#endif /* FILL_NXD_IPV6_ADDRESS */
#endif

#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer10) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_SCI0_RXI)
#define DTC_ACTIVATION_SRC_ELC_EVENT_SCI0_RXI
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer10_ctrl;
transfer_info_t g_transfer10_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .repeat_area = TRANSFER_REPEAT_AREA_DESTINATION,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_cfg_t g_transfer10_cfg =
{ .p_info = &g_transfer10_info,
  .activation_source = ELC_EVENT_SCI0_RXI,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer10,
  .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer10 =
{ .p_ctrl = &g_transfer10_ctrl, .p_cfg = &g_transfer10_cfg, .p_api = &g_transfer_on_dtc };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer9) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_SCI0_TXI)
#define DTC_ACTIVATION_SRC_ELC_EVENT_SCI0_TXI
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer9_ctrl;
transfer_info_t g_transfer9_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_cfg_t g_transfer9_cfg =
{ .p_info = &g_transfer9_info,
  .activation_source = ELC_EVENT_SCI0_TXI,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer9,
  .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer9 =
{ .p_ctrl = &g_transfer9_ctrl, .p_cfg = &g_transfer9_cfg, .p_api = &g_transfer_on_dtc };
#if !defined(SSP_SUPPRESS_ISR_g_spi1) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_spi_rxi_isr, SCI, RXI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_spi1) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_spi_txi_isr, SCI, TXI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_spi1) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_spi_tei_isr, SCI, TEI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_spi1) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_spi_eri_isr, SCI, ERI, 0);
#endif
sci_spi_instance_ctrl_t g_spi1_ctrl;

/** SPI extended configuration */
const sci_spi_extended_cfg g_spi1_cfg_extend =
{ .bitrate_modulation = true };

const spi_cfg_t g_spi1_cfg =
{ .channel = 0, .operating_mode = SPI_MODE_MASTER, .clk_phase = SPI_CLK_PHASE_EDGE_ODD, .clk_polarity =
          SPI_CLK_POLARITY_LOW,
  .mode_fault = SPI_MODE_FAULT_ERROR_DISABLE, .bit_order = SPI_BIT_ORDER_MSB_FIRST, .bitrate = 100000,
#define SYNERGY_NOT_DEFINED (1)             
#if (SYNERGY_NOT_DEFINED == g_transfer9)
                .p_transfer_tx       = NULL,
#else
  .p_transfer_tx = &g_transfer9,
#endif
#if (SYNERGY_NOT_DEFINED == g_transfer10)
                .p_transfer_rx       = NULL,
#else
  .p_transfer_rx = &g_transfer10,
#endif
#undef SYNERGY_NOT_DEFINED	
  .p_callback = NULL,
  .p_context = (void*) &g_spi1, .rxi_ipl = (12), .txi_ipl = (12), .tei_ipl = (12), .eri_ipl = (12), .p_extend =
          &g_spi1_cfg_extend, };
/* Instance structure to use this module. */
const spi_instance_t g_spi1 =
{ .p_ctrl = &g_spi1_ctrl, .p_cfg = &g_spi1_cfg, .p_api = &g_spi_on_sci };
static TX_MUTEX sf_bus_mutex_g_sf_spi_bus0;
static TX_EVENT_FLAGS_GROUP sf_bus_eventflag_g_sf_spi_bus0;
static sf_spi_ctrl_t *p_sf_curr_ctrl_g_sf_spi_bus0;

sf_spi_bus_t g_sf_spi_bus0 =
{ .p_bus_name = (uint8_t*) "g_sf_spi_bus0",
  .channel = 0,
  .freq_hz_min = 0,
  .p_lock_mutex = &sf_bus_mutex_g_sf_spi_bus0,
  .p_sync_eventflag = &sf_bus_eventflag_g_sf_spi_bus0,
  .pp_curr_ctrl = (sf_spi_ctrl_t**) &p_sf_curr_ctrl_g_sf_spi_bus0,
  .p_lower_lvl_api = (spi_api_t*) &g_spi_on_sci,
  .device_count = 0, };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer8) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_IIC0_RXI)
#define DTC_ACTIVATION_SRC_ELC_EVENT_IIC0_RXI
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer8_ctrl;
transfer_info_t g_transfer8_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .repeat_area = TRANSFER_REPEAT_AREA_DESTINATION,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_cfg_t g_transfer8_cfg =
{ .p_info = &g_transfer8_info,
  .activation_source = ELC_EVENT_IIC0_RXI,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer8,
  .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer8 =
{ .p_ctrl = &g_transfer8_ctrl, .p_cfg = &g_transfer8_cfg, .p_api = &g_transfer_on_dtc };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer7) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_IIC0_TXI)
#define DTC_ACTIVATION_SRC_ELC_EVENT_IIC0_TXI
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer7_ctrl;
transfer_info_t g_transfer7_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_cfg_t g_transfer7_cfg =
{ .p_info = &g_transfer7_info,
  .activation_source = ELC_EVENT_IIC0_TXI,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer7,
  .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer7 =
{ .p_ctrl = &g_transfer7_ctrl, .p_cfg = &g_transfer7_cfg, .p_api = &g_transfer_on_dtc };
#if !defined(SSP_SUPPRESS_ISR_g_i2c0) && !defined(SSP_SUPPRESS_ISR_IIC0)
SSP_VECTOR_DEFINE_CHAN(iic_rxi_isr, IIC, RXI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_i2c0) && !defined(SSP_SUPPRESS_ISR_IIC0)
SSP_VECTOR_DEFINE_CHAN(iic_txi_isr, IIC, TXI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_i2c0) && !defined(SSP_SUPPRESS_ISR_IIC0)
SSP_VECTOR_DEFINE_CHAN(iic_tei_isr, IIC, TEI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_i2c0) && !defined(SSP_SUPPRESS_ISR_IIC0)
SSP_VECTOR_DEFINE_CHAN(iic_eri_isr, IIC, ERI, 0);
#endif
riic_instance_ctrl_t g_i2c0_ctrl;
const riic_extended_cfg g_i2c0_extend =
{ .timeout_mode = RIIC_TIMEOUT_MODE_SHORT, };
const i2c_cfg_t g_i2c0_cfg =
{ .channel = 0, .rate = I2C_RATE_STANDARD, .slave = 0, .addr_mode = I2C_ADDR_MODE_7BIT, .sda_delay = 300,
#define SYNERGY_NOT_DEFINED (1)            
#if (SYNERGY_NOT_DEFINED == g_transfer7)
                .p_transfer_tx       = NULL,
#else
  .p_transfer_tx = &g_transfer7,
#endif
#if (SYNERGY_NOT_DEFINED == g_transfer8)
                .p_transfer_rx       = NULL,
#else
  .p_transfer_rx = &g_transfer8,
#endif
#undef SYNERGY_NOT_DEFINED	
  .p_callback = NULL,
  .p_context = (void*) &g_i2c0, .rxi_ipl = (12), .txi_ipl = (12), .tei_ipl = (12), .eri_ipl = (12), .p_extend =
          &g_i2c0_extend, };
/* Instance structure to use this module. */
const i2c_master_instance_t g_i2c0 =
{ .p_ctrl = &g_i2c0_ctrl, .p_cfg = &g_i2c0_cfg, .p_api = &g_i2c_master_on_riic };
static TX_MUTEX sf_bus_mutex_g_sf_i2c_bus0;
static TX_EVENT_FLAGS_GROUP sf_bus_eventflag_g_sf_i2c_bus0;
static sf_i2c_instance_ctrl_t *sf_curr_ctrl_g_sf_i2c_bus0;
static sf_i2c_instance_ctrl_t *sf_curr_bus_ctrl_g_sf_i2c_bus0;
sf_i2c_bus_t g_sf_i2c_bus0 =
{ .p_bus_name = (uint8_t*) "g_sf_i2c_bus0",
  .channel = 0,
  .p_lock_mutex = &sf_bus_mutex_g_sf_i2c_bus0,
  .p_sync_eventflag = &sf_bus_eventflag_g_sf_i2c_bus0,
  .pp_curr_ctrl = (sf_i2c_ctrl_t**) &sf_curr_ctrl_g_sf_i2c_bus0,
  .p_lower_lvl_api = (i2c_api_master_t*) &g_i2c_master_on_riic,
  .device_count = 0,
  .pp_curr_bus_ctrl = (sf_i2c_ctrl_t**) &sf_curr_bus_ctrl_g_sf_i2c_bus0, };
#if defined(BSP_FEATURE_HAS_SCE_ON_S1)  /* Crypto on S1 */
            sce_interface_get_api_interfaces_t g_sce_selected_api_interfaces =
            {
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_128_ECB
                .aes128ecb_on_sce  = (uint32_t)&g_aes128ecb_on_sce,
            #else
                .aes128ecb_on_sce  = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_128_CBC
                .aes128cbc_on_sce  = (uint32_t)&g_aes128cbc_on_sce,
            #else
                .aes128cbc_on_sce  = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_128_CTR
                .aes128ctr_on_sce  = (uint32_t)&g_aes128ctr_on_sce,
            #else
                .aes128ctr_on_sce  = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_256_ECB
                .aes256ecb_on_sce  = (uint32_t)&g_aes256ecb_on_sce,
            #else
                .aes256ecb_on_sce  = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_256_CBC
                .aes256cbc_on_sce  = (uint32_t)&g_aes256cbc_on_sce,
            #else
                .aes256cbc_on_sce  = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_256_CTR
                .aes256ctr_on_sce  = (uint32_t)&g_aes256ctr_on_sce,
            #else
                .aes256ctr_on_sce  = 0,
            #endif
            #if R_SCE_SERVICES_TRNG
                .trng_on_sce       = (uint32_t)&g_trng_on_sce
            #else
                .trng_on_sce       = 0
            #endif
            };
            
            #elif defined(BSP_FEATURE_HAS_SCE5) /* SCE5 */

            sce_interface_get_api_interfaces_t g_sce_selected_api_interfaces =
            {
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_128_ECB
                .aes128ecb_on_sce     = (uint32_t)&g_aes128ecb_on_sce,
            #else
                .aes128ecb_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_128_CBC
                .aes128cbc_on_sce     = (uint32_t)&g_aes128cbc_on_sce,
            #else
                .aes128cbc_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_128_CTR
                .aes128ctr_on_sce     = (uint32_t)&g_aes128ctr_on_sce,
            #else
                .aes128ctr_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_128_GCM
                .aes128gcm_on_sce     = (uint32_t)&g_aes128gcm_on_sce,
            #else
                .aes128gcm_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_128_XTS
                .aes128xts_on_sce     = (uint32_t)&g_aes128xts_on_sce,
            #else
                .aes128xts_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_256_ECB
                .aes256ecb_on_sce     = (uint32_t)&g_aes256ecb_on_sce,
            #else
                .aes256ecb_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_256_CBC
                .aes256cbc_on_sce     = (uint32_t)&g_aes256cbc_on_sce,
            #else
                .aes256cbc_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_256_CTR
                .aes256ctr_on_sce     = (uint32_t)&g_aes256ctr_on_sce,
            #else
                .aes256ctr_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_256_GCM
                .aes256gcm_on_sce     = (uint32_t)&g_aes256gcm_on_sce,
            #else
                .aes256gcm_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_PLAIN_TEXT_256_XTS
                .aes256xts_on_sce     = (uint32_t)&g_aes256xts_on_sce,
            #else
                .aes256xts_on_sce     = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_128_ECB
                .aes128ecb_on_sceHrk  = (uint32_t)&g_aes128ecb_on_sceHrk,
            #else
                .aes128ecb_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_128_CBC
                .aes128cbc_on_sceHrk  = (uint32_t)&g_aes128cbc_on_sceHrk,
            #else
                .aes128cbc_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_128_CTR
                .aes128ctr_on_sceHrk  = (uint32_t)&g_aes128ctr_on_sceHrk,
            #else
                .aes128ctr_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_128_GCM
                .aes128gcm_on_sceHrk  = (uint32_t)&g_aes128gcm_on_sceHrk,
            #else
                .aes128gcm_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_128_XTS
                .aes128xts_on_sceHrk  = (uint32_t)&g_aes128xts_on_sceHrk,
            #else
                .aes128xts_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_256_ECB
                .aes256ecb_on_sceHrk  = (uint32_t)&g_aes256ecb_on_sceHrk,
            #else
                .aes256ecb_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_256_CBC
                .aes256cbc_on_sceHrk  = (uint32_t)&g_aes256cbc_on_sceHrk,
            #else
                .aes256cbc_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_256_CTR
                .aes256ctr_on_sceHrk  = (uint32_t)&g_aes256ctr_on_sceHrk,
            #else
                .aes256ctr_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_256_GCM
                .aes256gcm_on_sceHrk  = (uint32_t)&g_aes256gcm_on_sceHrk,
            #else
                .aes256gcm_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_AES_WRAPPED_256_XTS
                .aes256xts_on_sceHrk  = (uint32_t)&g_aes256xts_on_sceHrk,
            #else
                .aes256xts_on_sceHrk  = 0,
            #endif
            #if R_SCE_SERVICES_TRNG
                .trng_on_sce          = (uint32_t)&g_trng_on_sce
            #else
                .trng_on_sce          = 0
            #endif
            };
            
            #else /* SCE7 */

sce_interface_get_api_interfaces_t g_sce_selected_api_interfaces =
{
#if R_SCE_SERVICES_AES_PLAIN_TEXT_128_ECB
                .aes128ecb_on_sce     = (uint32_t)&g_aes128ecb_on_sce,
            #else
  .aes128ecb_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_128_CBC
                .aes128cbc_on_sce     = (uint32_t)&g_aes128cbc_on_sce,
            #else
  .aes128cbc_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_128_CTR
                .aes128ctr_on_sce     = (uint32_t)&g_aes128ctr_on_sce,
            #else
  .aes128ctr_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_128_GCM
                .aes128gcm_on_sce     = (uint32_t)&g_aes128gcm_on_sce,
            #else
  .aes128gcm_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_128_XTS
                .aes128xts_on_sce     = (uint32_t)&g_aes128xts_on_sce,
            #else
  .aes128xts_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_192_ECB
                .aes192ecb_on_sce     = (uint32_t)&g_aes192ecb_on_sce,
            #else
  .aes192ecb_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_192_CBC
                .aes192cbc_on_sce     = (uint32_t)&g_aes192cbc_on_sce,
            #else
  .aes192cbc_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_192_CTR
                .aes192ctr_on_sce     = (uint32_t)&g_aes192ctr_on_sce,
            #else
  .aes192ctr_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_192_GCM
                .aes192gcm_on_sce     = (uint32_t)&g_aes192gcm_on_sce,
            #else
  .aes192gcm_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_256_ECB
                .aes256ecb_on_sce     = (uint32_t)&g_aes256ecb_on_sce,
            #else
  .aes256ecb_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_256_CBC
                .aes256cbc_on_sce     = (uint32_t)&g_aes256cbc_on_sce,
            #else
  .aes256cbc_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_256_CTR
                .aes256ctr_on_sce     = (uint32_t)&g_aes256ctr_on_sce,
            #else
  .aes256ctr_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_256_GCM
                .aes256gcm_on_sce     = (uint32_t)&g_aes256gcm_on_sce,
            #else
  .aes256gcm_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_PLAIN_TEXT_256_XTS
                .aes256xts_on_sce     = (uint32_t)&g_aes256xts_on_sce,
            #else
  .aes256xts_on_sce = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_128_ECB
                .aes128ecb_on_sceHrk  = (uint32_t)&g_aes128ecb_on_sceHrk,
            #else
  .aes128ecb_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_128_CBC
                .aes128cbc_on_sceHrk  = (uint32_t)&g_aes128cbc_on_sceHrk,
            #else
  .aes128cbc_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_128_CTR
                .aes128ctr_on_sceHrk  = (uint32_t)&g_aes128ctr_on_sceHrk,
            #else
  .aes128ctr_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_128_GCM
                .aes128gcm_on_sceHrk  = (uint32_t)&g_aes128gcm_on_sceHrk,
            #else
  .aes128gcm_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_128_XTS
                .aes128xts_on_sceHrk  = (uint32_t)&g_aes128xts_on_sceHrk,
            #else
  .aes128xts_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_192_ECB
                .aes192ecb_on_sceHrk  = (uint32_t)&g_aes192ecb_on_sceHrk,
            #else
  .aes192ecb_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_192_CBC
                .aes192cbc_on_sceHrk  = (uint32_t)&g_aes192cbc_on_sceHrk,
            #else
  .aes192cbc_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_192_CTR
                .aes192ctr_on_sceHrk  = (uint32_t)&g_aes192ctr_on_sceHrk,
            #else
  .aes192ctr_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_192_GCM
                .aes192gcm_on_sceHrk  = (uint32_t)&g_aes192gcm_on_sceHrk,
            #else
  .aes192gcm_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_256_ECB
                .aes256ecb_on_sceHrk  = (uint32_t)&g_aes256ecb_on_sceHrk,
            #else
  .aes256ecb_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_256_CBC
                .aes256cbc_on_sceHrk  = (uint32_t)&g_aes256cbc_on_sceHrk,
            #else
  .aes256cbc_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_256_CTR
                .aes256ctr_on_sceHrk  = (uint32_t)&g_aes256ctr_on_sceHrk,
            #else
  .aes256ctr_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_256_GCM
                .aes256gcm_on_sceHrk  = (uint32_t)&g_aes256gcm_on_sceHrk,
            #else
  .aes256gcm_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_AES_WRAPPED_256_XTS
                .aes256xts_on_sceHrk  = (uint32_t)&g_aes256xts_on_sceHrk,
            #else
  .aes256xts_on_sceHrk = 0,
#endif
#if R_SCE_SERVICES_RSA_PLAIN_TEXT_1024
                .rsa1024_on_sce       = (uint32_t)&g_rsa1024_on_sce,
            #else
  .rsa1024_on_sce = 0,
#endif
#if R_SCE_SERVICES_RSA_PLAIN_TEXT_2048
                .rsa2048_on_sce       = (uint32_t)&g_rsa2048_on_sce,
            #else
  .rsa2048_on_sce = 0,
#endif
#if R_SCE_SERVICES_RSA_WRAPPED_1024
                .rsa1024_on_sce_hrk   = (uint32_t)&g_rsa1024_on_sce_hrk,
            #else
  .rsa1024_on_sce_hrk = 0,
#endif
#if R_SCE_SERVICES_RSA_WRAPPED_2048
                .rsa2048_on_sce_hrk   = (uint32_t)&g_rsa2048_on_sce_hrk,
            #else
  .rsa2048_on_sce_hrk = 0,
#endif
#if R_SCE_SERVICES_HASH_MD5
                .md5_hash_on_sce      = (uint32_t)&g_md5_hash_on_sce,
            #else
  .md5_hash_on_sce = 0,
#endif
#if R_SCE_SERVICES_HASH_SHA1
                .sha1_hash_on_sce     = (uint32_t)&g_sha1_hash_on_sce,
            #else
  .sha1_hash_on_sce = 0,
#endif
#if R_SCE_SERVICES_HASH_SHA256
                .sha256_hash_on_sce   = (uint32_t)&g_sha256_hash_on_sce,
            #else
  .sha256_hash_on_sce = 0,
#endif
#if R_SCE_SERVICES_ECC_PLAIN_TEXT_192
                .ecc192_on_sce        = (uint32_t)&g_ecc192_on_sce,
            #else
  .ecc192_on_sce = 0,
#endif
#if R_SCE_SERVICES_ECC_PLAIN_TEXT_224
                .ecc224_on_sce        = (uint32_t)&g_ecc224_on_sce,
            #else
  .ecc224_on_sce = 0,
#endif
#if R_SCE_SERVICES_ECC_PLAIN_TEXT_256
                .ecc256_on_sce        = (uint32_t)&g_ecc256_on_sce,
            #else
  .ecc256_on_sce = 0,
#endif
#if R_SCE_SERVICES_ECC_PLAIN_TEXT_384
                .ecc384_on_sce        = (uint32_t)&g_ecc384_on_sce,
            #else
  .ecc384_on_sce = 0,
#endif
#if R_SCE_SERVICES_ECC_WRAPPED_192
                .ecc192_on_sce_hrk    = (uint32_t)&g_ecc192_on_sce_hrk,
            #else
  .ecc192_on_sce_hrk = 0,
#endif
#if R_SCE_SERVICES_ECC_WRAPPED_224
                .ecc224_on_sce_hrk    = (uint32_t)&g_ecc224_on_sce_hrk,
            #else
  .ecc224_on_sce_hrk = 0,
#endif
#if R_SCE_SERVICES_ECC_WRAPPED_256
                .ecc256_on_sce_hrk    = (uint32_t)&g_ecc256_on_sce_hrk,
            #else
  .ecc256_on_sce_hrk = 0,
#endif
#if R_SCE_SERVICES_ECC_WRAPPED_384
                .ecc384_on_sce_hrk    = (uint32_t)&g_ecc384_on_sce_hrk,
            #else
  .ecc384_on_sce_hrk = 0,
#endif
#if R_SCE_SERVICES_TRNG
                .trng_on_sce          = (uint32_t)&g_trng_on_sce
            #else
  .trng_on_sce = 0
#endif
        };

#endif /* Crypto on S1 / SCE5 / SCE7 */

crypto_ctrl_t g_sce_0_ctrl;
crypto_cfg_t g_sce_0_cfg =
{ .p_sce_long_plg_start_callback = NULL,
  .p_sce_long_plg_end_callback = NULL,
  .endian_flag = CRYPTO_WORD_ENDIAN_LITTLE,
  .p_sce_api_interfaces = &g_sce_selected_api_interfaces };
const crypto_instance_t g_sce_0 =
{ .p_ctrl = &g_sce_0_ctrl, .p_cfg = &g_sce_0_cfg, .p_api = &g_sce_crypto_api };

/** WEAK system error call back */
#if defined(__ICCARM__)
            #define g_sce_0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sce_0_err_callback  = g_sce_0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sce_0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sce_0_err_callback_internal")))
            #endif
void g_sce_0_err_callback(void *p_instance, void *p_data)
g_sce_0_err_callback_WEAK_ATTRIBUTE;

/*******************************************************************************************************************//**
 * @brief        This is a weak example initialization error function.   
 *               It should be overridden by defining a user function with the prototype below.
 *               void g_sce_0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]    p_instance arguments used to identify which instance caused the error and p_data Callback arguments 
 *               used to identify what error caused the callback. 
 **********************************************************************************************************************/
void g_sce_0_err_callback_internal(void *p_instance, void *p_data);
void g_sce_0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
trng_ctrl_t g_sce_trng_ctrl;
trng_cfg_t g_sce_trng_cfg =
{ .p_crypto_api = &g_sce_crypto_api, .nattempts = 2 };
const trng_instance_t g_sce_trng =
{ .p_ctrl = &g_sce_trng_ctrl, .p_cfg = &g_sce_trng_cfg, .p_api = &g_trng_on_sce };
/** Work memory to store Crypto HAL context for algorithm modules. */
static unsigned char g_sf_crypto0_memory_pool[2400 + 4] =
{ 0 };

/* Crypto Common Framework Control Block for g_sf_crypto0. */
sf_crypto_instance_ctrl_t g_sf_crypto0_ctrl;

/* Crypto Common Framework Configuration for g_sf_crypto0. */
const sf_crypto_cfg_t g_sf_crypto0_cfg =
{ .wait_option = TX_WAIT_FOREVER, .p_lower_lvl_crypto = (crypto_instance_t*) &g_sce_0, .p_extend = NULL, .p_context =
          NULL,
  .p_memory_pool = g_sf_crypto0_memory_pool, .memory_pool_size = 2400, .close_option = SF_CRYPTO_CLOSE_OPTION_DEFAULT, };

/* Crypto Common Framework Instance for g_sf_crypto0. */
const sf_crypto_instance_t g_sf_crypto0 =
{ .p_ctrl = &g_sf_crypto0_ctrl, .p_cfg = &g_sf_crypto0_cfg, .p_api = &g_sf_crypto_api };
const crypto_instance_t *p_lower_lvl_hw_crypto = (crypto_instance_t*) &g_sce_0;
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_external_irq0) && !defined(SSP_SUPPRESS_ISR_ICU0)
SSP_VECTOR_DEFINE( icu_irq_isr, ICU, IRQ0);
#endif
#endif
static icu_instance_ctrl_t g_external_irq0_ctrl;
static const external_irq_cfg_t g_external_irq0_cfg =
{ .channel = 0,
  .trigger = EXTERNAL_IRQ_TRIG_FALLING,
  .filter_enable = false,
  .pclk_div = EXTERNAL_IRQ_PCLK_DIV_BY_64,
  .autostart = true,
  .p_callback = custom_hw_irq_isr,
  .p_context = &g_external_irq0,
  .p_extend = NULL,
  .irq_ipl = (12), };
/* Instance structure to use this module. */
const external_irq_instance_t g_external_irq0 =
{ .p_ctrl = &g_external_irq0_ctrl, .p_cfg = &g_external_irq0_cfg, .p_api = &g_external_irq_on_icu };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer6) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_SCI0_RXI)
#define DTC_ACTIVATION_SRC_ELC_EVENT_SCI0_RXI
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer6_ctrl;
transfer_info_t g_transfer6_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .repeat_area = TRANSFER_REPEAT_AREA_DESTINATION,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_cfg_t g_transfer6_cfg =
{ .p_info = &g_transfer6_info,
  .activation_source = ELC_EVENT_SCI0_RXI,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer6,
  .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer6 =
{ .p_ctrl = &g_transfer6_ctrl, .p_cfg = &g_transfer6_cfg, .p_api = &g_transfer_on_dtc };
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer5) && !defined(SSP_SUPPRESS_ISR_DTCELC_EVENT_SCI0_TXI)
#define DTC_ACTIVATION_SRC_ELC_EVENT_SCI0_TXI
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_0) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_0);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_0
#endif
#if defined(DTC_ACTIVATION_SRC_ELC_EVENT_ELC_SOFTWARE_EVENT_1) && !defined(DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE(elc_software_event_isr, ELC, SOFTWARE_EVENT_1);
#define DTC_VECTOR_DEFINED_SOFTWARE_EVENT_1
#endif
#endif
#endif

dtc_instance_ctrl_t g_transfer5_ctrl;
transfer_info_t g_transfer5_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_END,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_cfg_t g_transfer5_cfg =
{ .p_info = &g_transfer5_info,
  .activation_source = ELC_EVENT_SCI0_TXI,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer5,
  .irq_ipl = (BSP_IRQ_DISABLED) };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer5 =
{ .p_ctrl = &g_transfer5_ctrl, .p_cfg = &g_transfer5_cfg, .p_api = &g_transfer_on_dtc };
#if !defined(SSP_SUPPRESS_ISR_g_spi0) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_spi_rxi_isr, SCI, RXI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_spi0) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_spi_txi_isr, SCI, TXI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_spi0) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_spi_tei_isr, SCI, TEI, 0);
#endif
#if !defined(SSP_SUPPRESS_ISR_g_spi0) && !defined(SSP_SUPPRESS_ISR_SCI0)
SSP_VECTOR_DEFINE_CHAN(sci_spi_eri_isr, SCI, ERI, 0);
#endif
sci_spi_instance_ctrl_t g_spi0_ctrl;

/** SPI extended configuration */
const sci_spi_extended_cfg g_spi0_cfg_extend =
{ .bitrate_modulation = true };

const spi_cfg_t g_spi0_cfg =
{ .channel = 0, .operating_mode = SPI_MODE_MASTER, .clk_phase = SPI_CLK_PHASE_EDGE_EVEN, .clk_polarity =
          SPI_CLK_POLARITY_HIGH,
  .mode_fault = SPI_MODE_FAULT_ERROR_DISABLE, .bit_order = SPI_BIT_ORDER_MSB_FIRST, .bitrate = 100000,
#define SYNERGY_NOT_DEFINED (1)             
#if (SYNERGY_NOT_DEFINED == g_transfer5)
                .p_transfer_tx       = NULL,
#else
  .p_transfer_tx = &g_transfer5,
#endif
#if (SYNERGY_NOT_DEFINED == g_transfer6)
                .p_transfer_rx       = NULL,
#else
  .p_transfer_rx = &g_transfer6,
#endif
#undef SYNERGY_NOT_DEFINED	
  .p_callback = NULL,
  .p_context = (void*) &g_spi0, .rxi_ipl = (12), .txi_ipl = (12), .tei_ipl = (12), .eri_ipl = (12), .p_extend =
          &g_spi0_cfg_extend, };
/* Instance structure to use this module. */
const spi_instance_t g_spi0 =
{ .p_ctrl = &g_spi0_ctrl, .p_cfg = &g_spi0_cfg, .p_api = &g_spi_on_sci };
static const sf_wifi_on_gt202_cfg_t g_sf_wifi0_on_gt202_cfg =
{ .p_lower_lvl_spi = &g_spi0,
  .p_lower_lvl_icu = &g_external_irq0,
  .pin_reset = IOPORT_PORT_06_PIN_00,
  .pin_slave_select = IOPORT_PORT_01_PIN_03,
  .driver_task_priority = 5, };

static sf_wifi_ctrl_t g_sf_wifi0_ctrl;
static const sf_wifi_cfg_t g_sf_wifi0_cfg =
        { .mac_addr =
        { 0x0, 0x0, 0x0, 0x0, 0x0, 0x0 },
          .hw_mode = SF_WIFI_INTERFACE_HW_MODE_11N, .tx_power = 10, .rts = SF_WIFI_RTS_ENABLE, .fragmentation = 0, .dtim =
                  3,
          .high_throughput = SF_WIFI_HIGH_THROUGHPUT_DISABLE, .preamble = SF_WIFI_PREAMBLE_LONG, .wmm =
                  SF_WIFI_WMM_DISABLE,
          .max_stations = 0, .ssid_broadcast = SF_WIFI_SSID_BROADCAST_ENABLE, .access_control =
                  SF_WIFI_ACCESS_CONTROL_DISABLE,
          .beacon = 1024, .station_inactivity_timeout = 100, .wds = SF_WIFI_WDS_DISABLE, .req_high_throughput =
                  SF_WIFI_MANDATORY_HIGH_THROUGHPUT_DISABLE,
          .p_buffer_pool_rx = NULL, .p_callback = NULL, .p_context = NULL, .p_extend = &g_sf_wifi0_on_gt202_cfg, };

/* Instance structure to use this module. */
sf_wifi_instance_t g_sf_wifi0 =
{ .p_ctrl = &g_sf_wifi0_ctrl, .p_cfg = &g_sf_wifi0_cfg, .p_api = &g_sf_wifi_on_sf_wifi_gt202 };

#if !SF_WIFI_GT202_CFG_ONCHIP_STACK_SUPPORT

#define SF_WIFI_NX_PACKET_CHAIN_ENABLE (1)
#define SF_WIFI_MAX_MTU (1500)

#if SF_WIFI_NX_PACKET_CHAIN_ENABLE
/** Tx buffer used to consolidate data from chained NetX packets */
static uint8_t g_tx_buffer[SF_WIFI_MAX_MTU];
#endif

/** NSAL Zero copy support configuration */
const sf_wifi_nsal_cfg_t g_sf_wifi0_nsal_cfg =
{ .rx_zero_copy = SF_WIFI_NSAL_ZERO_COPY_DISABLE, .tx_zero_copy = SF_WIFI_NSAL_ZERO_COPY_DISABLE,
#if SF_WIFI_NX_PACKET_CHAIN_ENABLE
  .p_tx_packet_buffer = g_tx_buffer,
#else
	.p_tx_packet_buffer = NULL,
#endif
        };
#endif
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_wifi0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_wifi0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_wifi0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sf_wifi_gt202_init0(void)
 **********************************************************************************************************************/
void sf_wifi_gt202_init0(void)
{
    ssp_err_t ssp_err_g_sf_wifi0;
    ssp_err_g_sf_wifi0 = g_sf_wifi0.p_api->open (g_sf_wifi0.p_ctrl, g_sf_wifi0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_wifi0)
    {
        g_sf_wifi0_err_callback_internal ((void*) &g_sf_wifi0, &ssp_err_g_sf_wifi0);
    }
}
extern const sf_wifi_nsal_cfg_t g_sf_wifi0_nsal_cfg;
/** NetX driver entry function. We will take what NetX gives and add on WiFi framework instance. */
VOID g_sf_el_nx0(NX_IP_DRIVER *p_driver)
{
    nsal_netx_driver (p_driver, &g_sf_wifi0, (sf_wifi_nsal_cfg_t*) &g_sf_wifi0_nsal_cfg);
}
/***********************************************************************************************************************
 * USB CDC-ACM Interface Descriptor for FS mode g_usb_interface_desc_cdcacm_0
 **********************************************************************************************************************/
#if defined(__GNUC__)
            static volatile const unsigned char g_usb_interface_desc_cdcacm_0_full_speed[] BSP_PLACE_IN_SECTION_V2(".usb_interface_desc_fs") BSP_ALIGN_VARIABLE_V2(1)
            #else /* __ICCARM__ */
#pragma section = ".usb_interface_desc_fs" 1
__root static const unsigned char g_usb_interface_desc_cdcacm_0_full_speed[] BSP_PLACE_IN_SECTION_V2(".usb_interface_desc_fs")
#endif
=
{
    /****************************************************************
     * Interface Association Descriptor(IAD)                        *
     ****************************************************************/
    0x08, /* 0 bLength */
    UX_INTERFACE_ASSOCIATION_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    0x00, /* 2 bFirstInterface */
    0x02, /* 3 bInterfaceCount */
    0x02, /* 4 bFunctionClass : Communication */
    0x02, /* 5 bFunctionSubClass : Abstract Control Model */
    0x00, /* 6 bFunctionProtocol : Standard or enhanced AT Command set protocol */
    0x00, /* 7 iFunction : String descriptor index */
    /****************************************************************
     * Communication Class Interface Descriptor                     *
     ****************************************************************/
    0x09, /* 0 bLength */
    UX_INTERFACE_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    0x00, /* 2 bInterfaceNumber */
    0x00, /* 3 bAlternateSetting  : Alternate for SetInterface Request */
    0x01, /* 4 bNumEndpoints      : 1 Endpoint for Interface#1 */
    0x02, /* 5 bInterfaceClass    : Communications Interface Class(0x2) */
    0x02, /* 6 bInterfaceSubClass : Abstract Control Model(0x2) */
    0x01, /* 7 bInterfaceProtocol : Common AT command(0x01) */
    0x00, /* 8 iInterface Index */
    /****************************************************************
     * Header Functional Descriptor                                 *
     ****************************************************************/
    0x05, /* 0 bFunctionLength */
    0x24, /* 1 bDescriptorType : CS_INTERFACE(24h) */
    0x00, /* 2 bDescriptorSubtype : Header Functional Descriptor(0x0) */
    0x10, /* 3 bcdCDC Number  0x0110 == 1.10 */
    0x01, /* 4 bcdCDC */
    /****************************************************************
     * Abstract Control Management Functional Functional Descriptor *
     ****************************************************************/
    0x04, /* 0 bFunctionLength */
    0x24, /* 1 bDescriptorType : CS_INTERFACE(24h) */
    0x02, /* 2 bDescriptorSubtype : Abstract Control Management Functional Descriptor(0x2) */
    0x06, /* 3 bmCapabilities (Supports SendBreak, GetLineCoding, SetControlLineState, GetLineCoding) */
    /****************************************************************
     * Union Functional Descriptor                                  *
     ****************************************************************/
    0x05, /* 0 bFunctionLength */
    0x24, /* 1 bDescriptorType : CS_INTERFACE(24h) */
    0x06, /* 2 bDescriptorSubtype : Union Functional Descriptor(0x6) */
    0x00, /* 3 bMasterInterface */
    0x01, /* 4 bSubordinateInterface0 */
    /****************************************************************
     * Call Management Functional Descriptor                        *
     ****************************************************************/
    0x05, /* 0 bFunctionLength */
    0x24, /* 1 bDescriptorType */
    0x01, /* 2 bDescriptorSubtype : Call Management Functional Descriptor(0x1) */
    0x03, /* 3 bmCapabilities */
    0x01, /* 4 bDataInterface */
    /****************************************************************
     * CDC-ACM Endpoint descriptor (Interrupt) for Interface#0      *
     ****************************************************************/
    0x07, /* 0 bLength */
    UX_ENDPOINT_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    (UX_ENDPOINT_IN | 3), /* 2 bEndpointAddress */
    UX_INTERRUPT_ENDPOINT, /* 3 bmAttributes  */
    0x08, /* 4 wMaxPacketSize */
    0x00, /* 5 wMaxPacketSize */
    0x0F, /* 6 bInterval */
    /****************************************************************
     * CDC-ACM Data Class Interface Descriptor                      *
     ****************************************************************/
    0x09, /* 0 bLength */
    UX_INTERFACE_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    0x01, /* 2 bInterfaceNumber */
    0x00, /* 3 bAlternateSetting  : Alternate for SetInterface Request */
    0x02, /* 4 bNumEndpoints      : 2 Endpoints for Interface#0 */
    0x0A, /* 5 bInterfaceClass    : Data Interface Class(0xA) */
    0x00, /* 6 bInterfaceSubClass : Abstract Control Model */
    0x00, /* 7 bInterfaceProtocol : No class specific protocol required */
    0x00, /* 8 iInterface Index   : String descriptor index */
    /****************************************************************
     * CDC-ACM Endpoint Descriptor (Bulk-Out)  for Interface#1      *
     ****************************************************************/
    0x07, /* 0 bLength */
    UX_ENDPOINT_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    (UX_ENDPOINT_OUT | 1), /* 2 bEndpointAddress */
    UX_BULK_ENDPOINT, /* 3 bmAttributes  */
    0x40, /* 4 wMaxPacketSize */
    0x00, /* 5 wMaxPacketSize */
    0x00, /* 6 bInterval */
    /****************************************************************
     * CDC-ACM Endpoint Descriptor (Bulk-In) for Interface#1        *
     ****************************************************************/
    0x07, /* 0 bLength */
    UX_ENDPOINT_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    (UX_ENDPOINT_IN | 2), /* 2 bEndpointAddress */
    UX_BULK_ENDPOINT, /* 3 bmAttributes  */
    0x40, /* 4 wMaxPacketSize */
    0x00, /* 5 wMaxPacketSize */
    0x00, /* 6 bInterval */
};

#if defined(UX_DCD_SYNERY_USE_USBHS)
/***********************************************************************************************************************
 * USB CDC-ACM Interface Descriptor for HS mode g_usb_interface_desc_cdcacm_0
 **********************************************************************************************************************/
#if defined(__GNUC__)
static volatile const unsigned char g_usb_interface_desc_cdcacm_0_high_speed[] BSP_PLACE_IN_SECTION_V2(".usb_interface_desc_hs") BSP_ALIGN_VARIABLE_V2(1)
#else /* __ICCARM__ */
#pragma section = ".usb_interface_desc_hs" 1
__root static const unsigned char g_usb_interface_desc_cdcacm_0_high_speed[] BSP_PLACE_IN_SECTION_V2(".usb_interface_desc_hs")
#endif
=
{
    /****************************************************************
     * Interface Association Descriptor(IAD)                        *
     ****************************************************************/
    0x08, /* 0 bLength */
    UX_INTERFACE_ASSOCIATION_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    0x00, /* 2 bFirstInterface */
    0x02, /* 3 bInterfaceCount */
    0x02, /* 4 bFunctionClass : Communication */
    0x02, /* 5 bFunctionSubClass : Abstract Control Model */
    0x00, /* 6 bFunctionProtocol : Standard or enhanced AT Command set protocol */
    0x00, /* 7 iFunction : String descriptor index */
    /****************************************************************
     * Communication Class Interface Descriptor                     *
     ****************************************************************/
    0x09, /* 0 bLength */
    UX_INTERFACE_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    0x00, /* 2 bInterfaceNumber */
    0x00, /* 3 bAlternateSetting  : Alternate for SetInterface Request */
    0x01, /* 4 bNumEndpoints      : 1 Endpoint for Interface#1 */
    0x02, /* 5 bInterfaceClass    : Communications Interface Class(0x2) */
    0x02, /* 6 bInterfaceSubClass : Abstract Control Model(0x2) */
    0x01, /* 7 bInterfaceProtocol : Common AT command(0x01) */
    0x00, /* 8 iInterface Index */
    /****************************************************************
     * Header Functional Descriptor                                 *
     ****************************************************************/
    0x05, /* 0 bFunctionLength */
    0x24, /* 1 bDescriptorType : CS_INTERFACE(24h) */
    0x00, /* 2 bDescriptorSubtype : Header Functional Descriptor(0x0) */
    0x10, /* 3 bcdCDC Number  0x0110 == 1.10 */
    0x01, /* 4 bcdCDC */
    /****************************************************************
     * Abstract Control Management Functional Functional Descriptor *
     ****************************************************************/
    0x04, /* 0 bFunctionLength */
    0x24, /* 1 bDescriptorType : CS_INTERFACE(24h) */
    0x02, /* 2 bDescriptorSubtype : Abstract Control Management Functional Descriptor(0x2) */
    0x06, /* 3 bmCapabilities (Supports SendBreak, GetLineCoding, SetControlLineState, GetLineCoding) */
    /****************************************************************
     * Union Functional Descriptor                                  *
     ****************************************************************/
    0x05, /* 0 bFunctionLength */
    0x24, /* 1 bDescriptorType : CS_INTERFACE(24h) */
    0x06, /* 2 bDescriptorSubtype : Union Functional Descriptor(0x6) */
    0x00, /* 3 bMasterInterface */
    0x01, /* 4 bSubordinateInterface0 */
    /****************************************************************
     * Call Management Functional Descriptor                        *
     ****************************************************************/
    0x05, /* 0 bFunctionLength */
    0x24, /* 1 bDescriptorType */
    0x01, /* 2 bDescriptorSubtype : Call Management Functional Descriptor(0x1) */
    0x03, /* 3 bmCapabilities */
    0x01, /* 4 bDataInterface */
    /****************************************************************
     * CDC-ACM Endpoint descriptor (Interrupt) for Interface#0      *
     ****************************************************************/
    0x07, /* 0 bLength */
    UX_ENDPOINT_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    (UX_ENDPOINT_IN | 3), /* 2 bEndpointAddress */
    UX_INTERRUPT_ENDPOINT, /* 3 bmAttributes  */
    0x08, /* 4 wMaxPacketSize */
    0x00, /* 5 wMaxPacketSize */
    0x0F, /* 6 bInterval */
    /****************************************************************
     * CDC-ACM Data Class Interface Descriptor                      *
     ****************************************************************/
    0x09, /* 0 bLength */
    UX_INTERFACE_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    0x01, /* 2 bInterfaceNumber */
    0x00, /* 3 bAlternateSetting  : Alternate for SetInterface Request */
    0x02, /* 4 bNumEndpoints      : 2 Endpoints for Interface#0 */
    0x0A, /* 5 bInterfaceClass    : Data Interface Class(0xA) */
    0x00, /* 6 bInterfaceSubClass : Abstract Control Model */
    0x00, /* 7 bInterfaceProtocol : No class specific protocol required */
    0x00, /* 8 iInterface Index   : String descriptor index */
    /****************************************************************
     * CDC-ACM Endpoint Descriptor (Bulk-Out)  for Interface#1      *
     ****************************************************************/
    0x07, /* 0 bLength */
    UX_ENDPOINT_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    (UX_ENDPOINT_OUT | 1), /* 2 bEndpointAddress */
    UX_BULK_ENDPOINT, /* 3 bmAttributes  */
    0x00, /* 4 wMaxPacketSize */
    0x02, /* 5 wMaxPacketSize */
    0x00, /* 6 bInterval */
    /****************************************************************
     * CDC-ACM Endpoint Descriptor (Bulk-In) for Interface#1        *
     ****************************************************************/
    0x07, /* 0 bLength */
    UX_ENDPOINT_DESCRIPTOR_ITEM, /* 1 bDescriptorType */
    (UX_ENDPOINT_IN | 2), /* 2 bEndpointAddress */
    UX_BULK_ENDPOINT, /* 3 bmAttributes  */
    0x00, /* 4 wMaxPacketSize */
    0x02, /* 5 wMaxPacketSize */
    0x00, /* 6 bInterval */
};
#endif

/* Size of this USB Interface Descriptor */
#define USB_IFD_SIZE_0x00       (sizeof(g_usb_interface_desc_cdcacm_0_full_speed))
/* Number of Interface this USB Interface Descriptor has */
#define USB_IFD_NUM_0x00        (2)
#ifndef USB_IFD_NUM_0
#define USB_IFD_NUM_0  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_0 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_1
#define USB_IFD_NUM_1  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_1 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_2
#define USB_IFD_NUM_2  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_2 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_3
#define USB_IFD_NUM_3  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_3 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_4
#define USB_IFD_NUM_4  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_4 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_5
#define USB_IFD_NUM_5  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_5 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_6
#define USB_IFD_NUM_6  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_6 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_7
#define USB_IFD_NUM_7  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_7 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_8
#define USB_IFD_NUM_8  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_8 USB_IFD_SIZE_0x00
#else
#ifndef USB_IFD_NUM_9
#define USB_IFD_NUM_9  USB_IFD_NUM_0x00
#define USB_IFD_SIZE_9 USB_IFD_SIZE_0x00
#endif 
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#if (11) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer4) && !defined(SSP_SUPPRESS_ISR_DMACELC_EVENT_ELC_SOFTWARE_EVENT_1)
SSP_VECTOR_DEFINE_CHAN(dmac_int_isr, DMAC, INT, 4);
#endif
#endif
dmac_instance_ctrl_t g_transfer4_ctrl;
transfer_info_t g_transfer4_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .repeat_area = TRANSFER_REPEAT_AREA_DESTINATION,
  .irq = TRANSFER_IRQ_EACH,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_BLOCK,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_on_dmac_cfg_t g_transfer4_extend =
{ .channel = 4, .offset_byte = 0, };
const transfer_cfg_t g_transfer4_cfg =
{ .p_info = &g_transfer4_info, .activation_source = ELC_EVENT_ELC_SOFTWARE_EVENT_1, .auto_enable = false, .p_callback =
          NULL,
  .p_context = &g_transfer4, .irq_ipl = (11), .p_extend = &g_transfer4_extend, };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer4 =
{ .p_ctrl = &g_transfer4_ctrl, .p_cfg = &g_transfer4_cfg, .p_api = &g_transfer_on_dmac };
#if (11) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer3) && !defined(SSP_SUPPRESS_ISR_DMACELC_EVENT_ELC_SOFTWARE_EVENT_0)
SSP_VECTOR_DEFINE_CHAN(dmac_int_isr, DMAC, INT, 3);
#endif
#endif
dmac_instance_ctrl_t g_transfer3_ctrl;
transfer_info_t g_transfer3_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_EACH,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_BLOCK,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_on_dmac_cfg_t g_transfer3_extend =
{ .channel = 3, .offset_byte = 0, };
const transfer_cfg_t g_transfer3_cfg =
{ .p_info = &g_transfer3_info, .activation_source = ELC_EVENT_ELC_SOFTWARE_EVENT_0, .auto_enable = false, .p_callback =
          NULL,
  .p_context = &g_transfer3, .irq_ipl = (11), .p_extend = &g_transfer3_extend, };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer3 =
{ .p_ctrl = &g_transfer3_ctrl, .p_cfg = &g_transfer3_cfg, .p_api = &g_transfer_on_dmac };
/***********************************************************************************************************************
 * Registers Interrupt Vector for USBHS Controller.
 **********************************************************************************************************************/
#if (SF_EL_UX_HCD_CFG_HS_IRQ_IPL != BSP_IRQ_DISABLED)
            /* USBHS ISR vector registering. */
            #if !defined(SSP_SUPPRESS_ISR_g_sf_el_ux_hcd_hs_0) && !defined(SSP_SUPPRESS_ISR_USB)
            #if !defined(UX_DCD_SYNERGY_USBHS_VECTOR)
            SSP_VECTOR_DEFINE_UNIT(usbhs_usb_int_resume_isr, USB, HS, USB_INT_RESUME, 0);
            #endif
            #endif
            #endif

#undef SYNERGY_NOT_DEFINED
#define SYNERGY_NOT_DEFINED (1)
/***********************************************************************************************************************
 * The definition of wrapper interface for USBX Synergy Port HCD Driver.
 **********************************************************************************************************************/
static UINT g_sf_el_ux_hcd_hs_0_initialize(UX_HCD *hcd)
{
#if ((SYNERGY_NOT_DEFINED != g_transfer3) && (SYNERGY_NOT_DEFINED != g_transfer4))
    /* DMA support */
    UX_HCD_SYNERGY_TRANSFER hcd_transfer;
    hcd_transfer.ux_synergy_transfer_tx = (transfer_instance_t*) &g_transfer3;
    hcd_transfer.ux_synergy_transfer_rx = (transfer_instance_t*) &g_transfer4;
    return (UINT) ux_hcd_synergy_initialize_transfer_support (hcd, (UX_HCD_SYNERGY_TRANSFER*) &hcd_transfer);
#else
                /* Non DMA support */
                return (UINT)ux_hcd_synergy_initialize(hcd);
            #endif
} /* End of function g_sf_el_ux_hcd_hs_0_initialize() */
#undef SYNERGY_NOT_DEFINED
#if (11) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer2) && !defined(SSP_SUPPRESS_ISR_DMACELC_EVENT_USBFS_FIFO_1)
SSP_VECTOR_DEFINE_CHAN(dmac_int_isr, DMAC, INT, 2);
#endif
#endif
dmac_instance_ctrl_t g_transfer2_ctrl;
transfer_info_t g_transfer2_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .repeat_area = TRANSFER_REPEAT_AREA_DESTINATION,
  .irq = TRANSFER_IRQ_EACH,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_BLOCK,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_on_dmac_cfg_t g_transfer2_extend =
{ .channel = 2, .offset_byte = 0, };
const transfer_cfg_t g_transfer2_cfg =
{ .p_info = &g_transfer2_info,
  .activation_source = ELC_EVENT_USBFS_FIFO_1,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer2,
  .irq_ipl = (11),
  .p_extend = &g_transfer2_extend, };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer2 =
{ .p_ctrl = &g_transfer2_ctrl, .p_cfg = &g_transfer2_cfg, .p_api = &g_transfer_on_dmac };
#if (11) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer1) && !defined(SSP_SUPPRESS_ISR_DMACELC_EVENT_USBFS_FIFO_0)
SSP_VECTOR_DEFINE_CHAN(dmac_int_isr, DMAC, INT, 1);
#endif
#endif
dmac_instance_ctrl_t g_transfer1_ctrl;
transfer_info_t g_transfer1_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_EACH,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_BLOCK,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_on_dmac_cfg_t g_transfer1_extend =
{ .channel = 1, .offset_byte = 0, };
const transfer_cfg_t g_transfer1_cfg =
{ .p_info = &g_transfer1_info,
  .activation_source = ELC_EVENT_USBFS_FIFO_0,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer1,
  .irq_ipl = (11),
  .p_extend = &g_transfer1_extend, };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer1 =
{ .p_ctrl = &g_transfer1_ctrl, .p_cfg = &g_transfer1_cfg, .p_api = &g_transfer_on_dmac };
#if defined(__ICCARM__)
            #define g_sf_el_ux_dcd_fs_0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sf_el_ux_dcd_fs_0_err_callback  = g_sf_el_ux_dcd_fs_0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sf_el_ux_dcd_fs_0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sf_el_ux_dcd_fs_0_err_callback_internal")))
            #endif
void g_sf_el_ux_dcd_fs_0_err_callback(void *p_instance, void *p_data)
g_sf_el_ux_dcd_fs_0_err_callback_WEAK_ATTRIBUTE;
#if (SF_EL_UX_CFG_FS_IRQ_IPL != BSP_IRQ_DISABLED)
            /* USBFS ISR vector registering. */
            #if !defined(SSP_SUPPRESS_ISR_g_sf_el_ux_dcd_fs_0) && !defined(SSP_SUPPRESS_ISR_USB)
            SSP_VECTOR_DEFINE_UNIT(usbfs_int_isr, USB, FS, INT, 0);
            #endif
            #endif

/* Prototype function for USBX DCD Initializer. */
void ux_dcd_initialize(void);

#undef SYNERGY_NOT_DEFINED
#define SYNERGY_NOT_DEFINED (1)
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_sf_el_ux_dcd_fs_0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sf_el_ux_dcd_fs_0_err_callback_internal(void *p_instance, void *p_data);
void g_sf_el_ux_dcd_fs_0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
#if ((SYNERGY_NOT_DEFINED != g_transfer1) && (SYNERGY_NOT_DEFINED != g_transfer2))
/***********************************************************************************************************************
 * The definition of wrapper interface for USBX Synergy Port DCD Driver to get a transfer module instance.
 **********************************************************************************************************************/
static UINT g_sf_el_ux_dcd_fs_0_initialize_transfer_support(ULONG dcd_io)
{
    UX_DCD_SYNERGY_TRANSFER dcd_transfer;
    dcd_transfer.ux_synergy_transfer_tx = (transfer_instance_t*) &g_transfer1;
    dcd_transfer.ux_synergy_transfer_rx = (transfer_instance_t*) &g_transfer2;
    return (UINT) ux_dcd_synergy_initialize_transfer_support (dcd_io, (UX_DCD_SYNERGY_TRANSFER*) &dcd_transfer);
} /* End of function g_sf_el_ux_dcd_fs_0_initialize_transfer_support() */
#endif

/***********************************************************************************************************************
 * Initializes USBX Device Controller Driver.
 **********************************************************************************************************************/
void ux_dcd_initialize(void)
{
    UINT status;
    /* Initializes the USB device controller, enabling DMA transfer if transfer module instances are given. */
#if ((SYNERGY_NOT_DEFINED == g_transfer1) || (SYNERGY_NOT_DEFINED == g_transfer2))
                status = (UINT)ux_dcd_synergy_initialize(R_USBFS_BASE);
                #else
    status = g_sf_el_ux_dcd_fs_0_initialize_transfer_support (R_USBFS_BASE);
#endif
#undef SYNERGY_NOT_DEFINED
    if (UX_SUCCESS != status)
    {
        g_sf_el_ux_dcd_fs_0_err_callback (NULL, &status);
    }
} /* End of function ux_dcd_initialize() */
#if defined(__ICCARM__)
        #define ux_v2_err_callback_WEAK_ATTRIBUTE
        #pragma weak ux_v2_err_callback  = ux_v2_err_callback_internal
        #elif defined(__GNUC__)
        #define ux_v2_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("ux_v2_err_callback_internal")))
        #endif
void ux_v2_err_callback(void *p_instance, void *p_data)
ux_v2_err_callback_WEAK_ATTRIBUTE;
/* memory pool allocation used by USBX system. */
CHAR g_ux_pool_memory[18432] =
{ 0 };
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void ux_v2_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void ux_v2_err_callback_internal(void *p_instance, void *p_data);
void ux_v2_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

#ifdef UX_HOST_INITIALIZE

#ifdef USB_HOST_STORAGE_CLASS_REGISTER

            /* A semaphore for synchronizing to the USB media storage mount timing. */
            static TX_SEMAPHORE ux_host_storage_semaphore_insertion;

            /* Temporary storage place for the pointer to a USBX Host Mass Storage Class Instance. */
            static UX_HOST_CLASS_STORAGE * g_ux_new_host_storage_instance;

            /* Function prototype for the function to notify changes happened to the USBX Host Class Mass Storage. */
            static UINT ux_system_host_storage_change_function(ULONG event, VOID * instance);

            /*******************************************************************************************************************//**
             * @brief      This is the function to register the USBX Host Class Mass Storage.
             **********************************************************************************************************************/
            void ux_host_stack_class_register_storage(void)
            {
                UINT status;
                status =  ux_host_stack_class_register(_ux_system_host_class_storage_name, ux_host_class_storage_entry);
                if (UX_SUCCESS != status)
                {
                    ux_v2_err_callback(NULL, &status);
                }

                /* Create semaphores used for the USB Mass Storage Media Initialization. */
                
                if(ux_host_storage_semaphore_insertion.tx_semaphore_id != ((ULONG) 0x53454D41))
                {
                    status = tx_semaphore_create(&ux_host_storage_semaphore_insertion, "ux_host_storage_semaphore_insertion", 0);
                    if (TX_SUCCESS != status)
                    {
                        ux_v2_err_callback(NULL, &status);
                    }
                }
            }

            /*******************************************************************************************************************//**
             * @brief      This is the function to notify changes happened to the USBX Host Class Mass Storage.
             * @param[in]  event      Event code from happened to the USBX Host system.
             * @param[in]  instance   Pointer to a USBX Host class instance, which occurs a event.
             * @retval     USBX error code
             **********************************************************************************************************************/
            static UINT ux_system_host_storage_change_function(ULONG event, VOID * instance)
            {
                if (UX_DEVICE_INSERTION == event) /* Check if there is a device insertion. */
                {
                    g_ux_new_host_storage_instance = instance;

                    /* Put the semaphore for a USBX Mass Storage Media insertion. */
                    tx_semaphore_put (&ux_host_storage_semaphore_insertion);
                }
                else if (UX_DEVICE_REMOVAL == event) /* Check if there is a device removal. */
                {
                    g_ux_new_host_storage_instance = NULL;
                }
                return UX_SUCCESS;
            }

            /*******************************************************************************************************************//**
             * @brief      This is the function to get the FileX Media Control Block for a USB Mass Storage device.
             * @param[in]      new_instance     Pointer to a USBX Host Mass Storage Class instance.
             * @param[in/out]  p_storage_media  Pointer of the pointer to save an instance of the USBX Host Mass Storage Media.
             * @param[in/out]  p_fx_media       Pointer of the pointer to save an instance of FileX Media Control Block.
             * @retval     UX_HOST_CLASS_INSTANCE_UNKNOWN  The instance provided was not for a valid Mass Storage device.
             **********************************************************************************************************************/
            UINT ux_system_host_storage_fx_media_get(UX_HOST_CLASS_STORAGE * instance, UX_HOST_CLASS_STORAGE_MEDIA ** p_storage_media,
                                                                                       FX_MEDIA ** p_fx_media)
            {
                UINT            error = UX_SUCCESS;
                UX_HOST_CLASS * p_host_class;
                UX_HOST_CLASS_STORAGE_MEDIA * p_storage_media_local;
                FX_MEDIA      * p_fx_media_local;
                int             index;

                /** Get the USBX Host Mass Storage Class. */
                ux_host_stack_class_get(_ux_system_host_class_storage_name, &p_host_class);

                /** Get the pointer to a media attached to the class container for USB Host Mass Storage. */
                p_storage_media_local = (UX_HOST_CLASS_STORAGE_MEDIA *) p_host_class->ux_host_class_media;

                /** Get the pointer to a FileX Media Control Block. */
                for (index = 0; index < UX_HOST_CLASS_STORAGE_MAX_MEDIA; index++)
                {
                    p_fx_media_local = &p_storage_media_local->ux_host_class_storage_media;
                    if (p_fx_media_local->fx_media_driver_info != instance)
                    {
                        /* None of FileX Media Control Blocks matched to this USBX Host Mass Storage Instance. */
                        p_storage_media_local++;
                    }
                    else
                    {
                        /* Found a FileX Media Control Block used for this USBX Host Mass Storage Instance. */
                        break;
                    }
                }
                if (UX_HOST_CLASS_STORAGE_MAX_MEDIA == index)
                {
                    error = UX_HOST_CLASS_INSTANCE_UNKNOWN;
                }
                else
                {
                    *p_storage_media = p_storage_media_local;
                    *p_fx_media      = p_fx_media_local;
                }

                return error;
            }
#endif /* USB_HOST_STORAGE_CLASS_REGISTER */

/*******************************************************************************************************************//**
 * @brief      This is the function to notify a USB event from the USBX Host system.
 * @param[in]  event     Event code from happened to the USBX Host system.
 * @param[in]  usb_class Pointer to a USBX Host class, which occurs a event.
 * @param[in]  instance  Pointer to a USBX Host class instance, which occurs a event.
 * @retval     USBX error code
 **********************************************************************************************************************/
UINT ux_system_host_change_function(ULONG event, UX_HOST_CLASS *host_class, VOID *instance)
{
    UINT status = UX_SUCCESS;
    SSP_PARAMETER_NOT_USED (event);
    SSP_PARAMETER_NOT_USED (host_class);
    SSP_PARAMETER_NOT_USED (instance);

#if !defined(NULL)
    /* Call user function back for USBX Host Class event notification. */
    status = NULL (event, host_class, instance);
    if (UX_SUCCESS != status)
    {
        return status;
    }
#endif

#ifdef USB_HOST_STORAGE_CLASS_REGISTER
                /* Check the class container if it is for a USBX Host Mass Storage class. */
                if (UX_SUCCESS == _ux_utility_memory_compare(_ux_system_host_class_storage_name, host_class, _ux_utility_string_length_get(_ux_system_host_class_storage_name)))
                {
                   status = ux_system_host_storage_change_function(event, instance);
                }
#endif
    return status;
}
#endif

#ifdef USB_HOST_HID_CLASS_REGISTER
            /* Function prototype to register USBX Host HID Clients to the USBX Host system. */
            static void ux_host_class_hid_clients_register(void);
#endif

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void ux_common_init0(void)
 **********************************************************************************************************************/
void ux_common_init0(void)
{
    UINT status_ux_init;

    /** Initialize the USBX system. */
    status_ux_init = ux_system_initialize ((CHAR*) g_ux_pool_memory, 18432, UX_NULL, 0);
    if (UX_SUCCESS != status_ux_init)
    {
        ux_v2_err_callback (NULL, &status_ux_init);
    }

#ifdef UX_HOST_INITIALIZE
    /** Initialize the USBX Host stack. */
    status_ux_init = ux_host_stack_initialize (ux_system_host_change_function);
    if (UX_SUCCESS != status_ux_init)
    {
        ux_v2_err_callback (NULL, &status_ux_init);
    }

    /** Register USB Host classes. */
#ifdef USB_HOST_HUB_CLASS_REGISTER
                status_ux_init =  ux_host_stack_class_register(_ux_system_host_class_hub_name, ux_host_class_hub_entry);
                if (UX_SUCCESS != status_ux_init)
                {
                    ux_v2_err_callback(NULL,&status_ux_init);
                }
#endif

#ifdef USB_HOST_CDC_ACM_CLASS_REGISTER
                status_ux_init =  ux_host_stack_class_register(_ux_system_host_class_cdc_acm_name, ux_host_class_cdc_acm_entry);
                if (UX_SUCCESS != status_ux_init)
                {
                    ux_v2_err_callback(NULL,&status_ux_init);
                }
#endif

#ifdef USB_HOST_HID_CLASS_REGISTER
                status_ux_init =  ux_host_stack_class_register(_ux_system_host_class_hid_name, ux_host_class_hid_entry);
                if (UX_SUCCESS != status_ux_init)
                {
                    ux_v2_err_callback(NULL,&status_ux_init);
                }
            
                ux_host_class_hid_clients_register ();
#endif

#ifdef USB_HOST_STORAGE_CLASS_REGISTER
                ux_host_stack_class_register_storage();
#endif

#ifdef USB_HOST_VIDEO_CLASS_REGISTER
                status_ux_init =  ux_host_stack_class_register(_ux_system_host_class_video_name, ux_host_class_video_entry);
                if (UX_SUCCESS != status_ux_init)
                {
                    ux_v2_err_callback(NULL,&status_ux_init);
                }
#endif

#ifdef USB_HOST_AUDIO_CLASS_REGISTER
                status_ux_init =  ux_host_stack_class_register(_ux_system_host_class_audio_name, ux_host_class_audio_entry);
                if (UX_SUCCESS != status_ux_init)
                {
                    ux_v2_err_callback(NULL,&status_ux_init);
                }
#endif

#ifdef USB_HOST_PRINTER_CLASS_REGISTER
                status_ux_init =  ux_host_stack_class_register(_ux_system_host_class_printer_name, _ux_host_class_printer_entry);
                if (UX_SUCCESS != status_ux_init)
                {
                    ux_v2_err_callback(NULL,&status_ux_init);
                }
#endif

#endif /* UX_HOST_INITIALIZE */
}
#if defined(__ICCARM__)
              #define g_ux_host_0_err_callback_WEAK_ATTRIBUTE
              #pragma weak g_ux_host_0_err_callback  = g_ux_host_0_err_callback_internal
              #elif defined(__GNUC__)
              #define g_ux_host_0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_ux_host_0_err_callback_internal")))
              #endif
void g_ux_host_0_err_callback(void *p_instance, void *p_data)
g_ux_host_0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function 
 *             with the prototype below.
 *             - void g_ux_host_0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_ux_host_0_err_callback_internal(void *p_instance, void *p_data);
void g_ux_host_0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void ux_host_init0(void)
 **********************************************************************************************************************/
void ux_host_init0(void)
{
    /** Register a USB host controller. */
    UINT status_g_ux_host_0 = ux_host_stack_hcd_register ((UCHAR*) "g_sf_el_ux_hcd_hs_0",
                                                          g_sf_el_ux_hcd_hs_0_initialize, R_USBHS_BASE,
                                                          UX_SYNERGY_CONTROLLER);
    if (UX_SUCCESS != status_g_ux_host_0)
    {
        g_ux_host_0_err_callback (NULL, &status_g_ux_host_0);
    }
}
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_transfer0) && !defined(SSP_SUPPRESS_ISR_DMACELC_EVENT_SDHIMMC0_DMA_REQ)
SSP_VECTOR_DEFINE_CHAN(dmac_int_isr, DMAC, INT, 0);
#endif
#endif
dmac_instance_ctrl_t g_transfer0_ctrl;
transfer_info_t g_transfer0_info =
{ .dest_addr_mode = TRANSFER_ADDR_MODE_FIXED,
  .repeat_area = TRANSFER_REPEAT_AREA_SOURCE,
  .irq = TRANSFER_IRQ_EACH,
  .chain_mode = TRANSFER_CHAIN_MODE_DISABLED,
  .src_addr_mode = TRANSFER_ADDR_MODE_INCREMENTED,
  .size = TRANSFER_SIZE_1_BYTE,
  .mode = TRANSFER_MODE_NORMAL,
  .p_dest = (void*) NULL,
  .p_src = (void const*) NULL,
  .num_blocks = 0,
  .length = 0, };
const transfer_on_dmac_cfg_t g_transfer0_extend =
{ .channel = 0, .offset_byte = 0, };
const transfer_cfg_t g_transfer0_cfg =
{ .p_info = &g_transfer0_info,
  .activation_source = ELC_EVENT_SDHIMMC0_DMA_REQ,
  .auto_enable = false,
  .p_callback = NULL,
  .p_context = &g_transfer0,
  .irq_ipl = (12),
  .p_extend = &g_transfer0_extend, };
/* Instance structure to use this module. */
const transfer_instance_t g_transfer0 =
{ .p_ctrl = &g_transfer0_ctrl, .p_cfg = &g_transfer0_cfg, .p_api = &g_transfer_on_dmac };
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_sdmmc0) && !defined(SSP_SUPPRESS_ISR_SDMMC0)
SSP_VECTOR_DEFINE_CHAN(sdhimmc_accs_isr, SDHIMMC, ACCS, 0);
#endif
#endif
#if (12) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_sdmmc0) && !defined(SSP_SUPPRESS_ISR_SDMMC0)
SSP_VECTOR_DEFINE_CHAN(sdhimmc_card_isr, SDHIMMC, CARD, 0);
#endif
#endif
#if (BSP_IRQ_DISABLED) != BSP_IRQ_DISABLED
#if !defined(SSP_SUPPRESS_ISR_g_sdmmc0) && !defined(SSP_SUPPRESS_ISR_SDMMC0)
SSP_VECTOR_DEFINE_CHAN(sdhimmc_dma_req_isr, SDHIMMC, DMA_REQ, 0);
#endif
#endif
sdmmc_instance_ctrl_t g_sdmmc0_ctrl;

/** SDMMC extended configuration */
const sdmmc_extended_cfg_t g_sdmmc0_ext_cfg_t =
{ .block_size = 512, .card_detect = SDMMC_CARD_DETECT_NONE, .write_protect = SDMMC_WRITE_PROTECT_WP, };

sdmmc_cfg_t g_sdmmc0_cfg =
{ .hw =
{ .media_type = SDMMC_MEDIA_TYPE_EMBEDDED, .bus_width = SDMMC_BUS_WIDTH_4_BITS, .channel = 0, },
  .p_callback = NULL,

  .p_extend = (void*) &g_sdmmc0_ext_cfg_t,
  .p_lower_lvl_transfer = &g_transfer0,

  .access_ipl = (12),
  .sdio_ipl = BSP_IRQ_DISABLED, .card_ipl = (12), .dma_req_ipl = (BSP_IRQ_DISABLED), };
/* Instance structure to use this module. */
const sdmmc_instance_t g_sdmmc0 =
{ .p_ctrl = &g_sdmmc0_ctrl, .p_cfg = &g_sdmmc0_cfg, .p_api = &g_sdmmc_on_sdmmc };
static const sf_block_media_on_sdmmc_cfg_t g_sf_block_media_sdmmc0_block_media_cfg =
{ .p_lower_lvl_sdmmc = &g_sdmmc0, };
static sf_block_media_sdmmc_instance_ctrl_t g_sf_block_media_sdmmc0_ctrl;
static sf_block_media_cfg_t g_sf_block_media_sdmmc0_cfg =
{ .block_size = 512, .p_extend = &g_sf_block_media_sdmmc0_block_media_cfg };

sf_block_media_instance_t g_sf_block_media_sdmmc0 =
{ .p_ctrl = &g_sf_block_media_sdmmc0_ctrl, .p_cfg = &g_sf_block_media_sdmmc0_cfg, .p_api = &g_sf_block_media_on_sdmmc };
#define g_sf_el_fx0_total_partition       0U

#if (g_sf_el_fx0_total_partition > 1U)
            sf_el_fx_media_partition_data_info_t g_sf_el_fx0_partition_data_info[g_sf_el_fx0_total_partition];
            #endif

sf_el_fx_instance_ctrl_t g_sf_el_fx0_ctrl;

/** SF_EL_FX interface configuration */
const sf_el_fx_config_t g_sf_el_fx0_config =
{
#if (g_sf_el_fx0_total_partition > 1U) 
                .p_partition_data        = (sf_el_fx_media_partition_data_info_t *)g_sf_el_fx0_partition_data_info, 
            #else 
  .p_partition_data = NULL,
#endif 
  .p_lower_lvl_block_media = &g_sf_block_media_sdmmc0,
  .p_context = &g_sf_el_fx0_cfg, .p_extend = NULL, .total_partitions = g_sf_el_fx0_total_partition,
#if (g_sf_el_fx0_total_partition > 1U) 
                .p_callback              = NULL, 
            #else 
  .p_callback = NULL,
#endif 
        };

/* Instance structure to use this module. */
sf_el_fx_t g_sf_el_fx0_cfg =
{ .p_ctrl = &g_sf_el_fx0_ctrl, .p_config = &g_sf_el_fx0_config, };
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void nx_common_init0(void)
 **********************************************************************************************************************/
void nx_common_init0(void)
{
    /** Initialize the NetX Duo system. */
    nx_system_initialize ();
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void nx_secure_common_init(void)
 **********************************************************************************************************************/
void nx_secure_common_init(void)
{
#ifndef    NX_CRYPTO_ENGINE_SW 
    ssp_err_t ssp_err_g_sce_0;

    /* Initialise secure crypto engine driver */
    ssp_err_g_sce_0 = sce_initialize ();
    if (SSP_SUCCESS != ssp_err_g_sce_0)
    {
        g_sce_0_err_callback ((void*) &g_sce_0, &ssp_err_g_sce_0);
    }
#endif

    /* Initialises the various control data structures for the TLS component */
    nx_secure_tls_initialize ();
}
NX_PACKET_POOL g_packet_pool0;
uint8_t g_packet_pool0_pool_memory[(16 * (1568 + sizeof(NX_PACKET)))];
#if defined(__ICCARM__)
            #define g_packet_pool0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_packet_pool0_err_callback  = g_packet_pool0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_packet_pool0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_packet_pool0_err_callback_internal")))
            #endif
void g_packet_pool0_err_callback(void *p_instance, void *p_data)
g_packet_pool0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_packet_pool0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_packet_pool0_err_callback_internal(void *p_instance, void *p_data);
void g_packet_pool0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void packet_pool_init0(void)
 **********************************************************************************************************************/
void packet_pool_init0(void)
{
    UINT g_packet_pool0_err;
    /* Create Client packet pool. */
    g_packet_pool0_err = nx_packet_pool_create (&g_packet_pool0, "g_packet_pool0 Packet Pool", 1568,
                                                &g_packet_pool0_pool_memory[0], (16 * (1568 + sizeof(NX_PACKET))));
    if (NX_SUCCESS != g_packet_pool0_err)
    {
        g_packet_pool0_err_callback ((void*) &g_packet_pool0, &g_packet_pool0_err);
    }
}
NX_IP g_ip0;
#ifndef NX_DISABLE_IPV6
UINT g_ip0_interface_index = 0;
UINT g_ip0_address_index;
NXD_ADDRESS g_ip0_global_ipv6_address;
NXD_ADDRESS g_ip0_local_ipv6_address;
#endif            
uint8_t g_ip0_stack_memory[2048] BSP_PLACE_IN_SECTION_V2(".stack.g_ip0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if 1 == 1                       // Check for ARP is enabled
#if (0 == 0)    // Check for ARP cache storage units is in bytes
#define    NX_ARP_CACHE_SIZE    (520)
#else
#define    NX_ARP_CACHE_SIZE    (520 * sizeof(NX_ARP))
#endif
uint8_t g_ip0_arp_cache_memory[NX_ARP_CACHE_SIZE] BSP_ALIGN_VARIABLE(4);
#endif
ULONG g_ip0_actual_status;

#ifndef NULL
#define NULL_DEFINE
void NULL(struct NX_IP_STRUCT *ip_ptr, UINT interface_index, UINT link_up);
#endif            
#if defined(__ICCARM__)
            #define g_ip0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_ip0_err_callback  = g_ip0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_ip0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_ip0_err_callback_internal")))
            #endif
void g_ip0_err_callback(void *p_instance, void *p_data)
g_ip0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_ip0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_ip0_err_callback_internal(void *p_instance, void *p_data);
void g_ip0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void ip_init0(void)
 **********************************************************************************************************************/
void ip_init0(void)
{
    UINT g_ip0_err;
#ifndef NX_DISABLE_IPV6
    FILL_NXD_IPV6_ADDRESS(g_ip0_global_ipv6_address, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);
    FILL_NXD_IPV6_ADDRESS(g_ip0_local_ipv6_address, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0);

#endif
    /* Create an IP instance. */
    g_ip0_err = nx_ip_create (&g_ip0, "g_ip0 IP Instance", IP_ADDRESS (0, 0, 0, 0), IP_ADDRESS (255, 255, 255, 0),
                              &g_packet_pool0, g_sf_el_nx0, &g_ip0_stack_memory[0], 2048, 3);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
#define SYNERGY_NOT_DEFINED     (0xFFFFFFFF)
#if (SYNERGY_NOT_DEFINED != 1)
    g_ip0_err = nx_arp_enable (&g_ip0, &g_ip0_arp_cache_memory[0], NX_ARP_CACHE_SIZE);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
                g_ip0_err = nx_rarp_enable(&g_ip0);
                if (NX_SUCCESS != g_ip0_err)
                {
                    g_ip0_err_callback((void *)&g_ip0,&g_ip0_err);
                }
                #endif
#if (SYNERGY_NOT_DEFINED != 1)
    g_ip0_err = nx_tcp_enable (&g_ip0);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
#endif
#if (SYNERGY_NOT_DEFINED != 1)
    g_ip0_err = nx_udp_enable (&g_ip0);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
#endif
#if (SYNERGY_NOT_DEFINED != 1)
    g_ip0_err = nx_icmp_enable (&g_ip0);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
#endif
#if (SYNERGY_NOT_DEFINED != 1)
    g_ip0_err = nx_igmp_enable (&g_ip0);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
#endif
#if (SYNERGY_NOT_DEFINED != SYNERGY_NOT_DEFINED)
                g_ip0_err = nx_ip_fragment_enable(&g_ip0);
                if (NX_SUCCESS != g_ip0_err)
                {
                    g_ip0_err_callback((void *)&g_ip0,&g_ip0_err);
                }                        
                #endif            
#undef SYNERGY_NOT_DEFINED

#ifndef NX_DISABLE_IPV6
    /** Here's where IPv6 is enabled. */
    g_ip0_err = nxd_ipv6_enable (&g_ip0);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
    g_ip0_err = nxd_icmp_enable (&g_ip0);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
    /* Wait for link to be initialized so MAC address is valid. */
    /** Wait for init to finish. */
    g_ip0_err = nx_ip_interface_status_check (&g_ip0, 0, NX_IP_INITIALIZE_DONE, &g_ip0_actual_status, NX_WAIT_FOREVER);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
    /** Setting link local address */
    if (0x0
            == (g_ip0_local_ipv6_address.nxd_ip_address.v6[0] | g_ip0_local_ipv6_address.nxd_ip_address.v6[1]
                    | g_ip0_local_ipv6_address.nxd_ip_address.v6[2] | g_ip0_local_ipv6_address.nxd_ip_address.v6[3]))
    {
        g_ip0_err = nxd_ipv6_address_set (&g_ip0, g_ip0_interface_index, NX_NULL, 10, NX_NULL);
    }
    else
    {
        g_ip0_err = nxd_ipv6_address_set (&g_ip0, g_ip0_interface_index, &g_ip0_local_ipv6_address, 10,
                                          &g_ip0_address_index);
    }
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
    if (0x0
            != (g_ip0_global_ipv6_address.nxd_ip_address.v6[0] | g_ip0_global_ipv6_address.nxd_ip_address.v6[1]
                    | g_ip0_global_ipv6_address.nxd_ip_address.v6[2] | g_ip0_global_ipv6_address.nxd_ip_address.v6[3]))
    {
        g_ip0_err = nxd_ipv6_address_set (&g_ip0, g_ip0_interface_index, &g_ip0_global_ipv6_address, 64,
                                          &g_ip0_address_index);
    }
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
#endif

#ifdef NULL_DEFINE
    g_ip0_err = nx_ip_link_status_change_notify_set (&g_ip0, NULL);
    if (NX_SUCCESS != g_ip0_err)
    {
        g_ip0_err_callback ((void*) &g_ip0, &g_ip0_err);
    }
#endif

    /* Gateway IP Address */
#define IP_VALID(a,b,c,d)     (a|b|c|d)
#if IP_VALID(0,0,0,0)
                g_ip0_err = nx_ip_gateway_address_set(&g_ip0,
											     IP_ADDRESS(0,0,0,0));       
														   
                if (NX_SUCCESS != g_ip0_err)
                {
                    g_ip0_err_callback((void *)&g_ip0,&g_ip0_err);
                }                       
                #endif         
#undef IP_VALID

}
CHAR nx_bsd_stack_memory[2048] BSP_PLACE_IN_SECTION_V2(".stack.nx_bsd") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define nx_bsd_err_callback_WEAK_ATTRIBUTE
#pragma weak nx_bsd_err_callback  = nx_bsd_err_callback_internal
#elif defined(__GNUC__)
#define nx_bsd_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("nx_bsd_err_callback_internal")))
#endif
void nx_bsd_err_callback(void *p_instance, void *p_data)
nx_bsd_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void nx_bsd_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void nx_bsd_err_callback_internal(void *p_instance, void *p_data);
void nx_bsd_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void nx_bsd_init0(void)
 **********************************************************************************************************************/
void nx_bsd_init0(void)
{
    INT nx_bsd_err;
    /* Initialize BSD Support for NetX Duo. */
    nx_bsd_err = bsd_initialize (&g_ip0, &g_packet_pool0, &nx_bsd_stack_memory[0], 2048, 3);
    if (NX_SUCCESS != nx_bsd_err)
    {
        nx_bsd_err_callback ((void*) NULL, &nx_bsd_err);
    }
}
#define FX_COMMON_INITIALIZE (1)
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void fx_common_init0(void)
 **********************************************************************************************************************/
void fx_common_init0(void)
{
    /** Initialize the FileX system. */
    fx_system_initialize ();
}
#if defined(__ICCARM__)
            #define g_fx_media0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_fx_media0_err_callback  = g_fx_media0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_fx_media0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_fx_media0_err_callback_internal")))
            #endif
void g_fx_media0_err_callback(void *p_instance, void *p_data)
g_fx_media0_err_callback_WEAK_ATTRIBUTE;
#define SF_EL_FX_FORMAT_MEDIA_ENABLE_g_fx_media0 (0)
#define SF_EL_FX_FORMAT_FULL_MEDIA_g_fx_media0 (1)
#define SF_EL_FX_AUTO_INIT_g_fx_media0 (1)
ssp_err_t SF_EL_FX_Get_MEDIA_Info(sf_el_fx_ctrl_t *const p_api_ctrl, sf_el_fx_config_t const *const p_config,
        uint32_t *sector_size, uint32_t *sector_count);
FX_MEDIA g_fx_media0;
uint8_t g_media_memory_g_fx_media0[512];
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_fx_media0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_fx_media0_err_callback_internal(void *p_instance, void *p_data);
void g_fx_media0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

ssp_err_t fx_media_init0_format(void)
{
    uint32_t fx_ret_val = FX_SUCCESS;

    uint32_t sector_size = 512;
    uint32_t sector_count = 3751936;

#if SF_EL_FX_FORMAT_FULL_MEDIA_g_fx_media0
    ssp_err_t error = SF_EL_FX_Get_MEDIA_Info (g_sf_el_fx0_cfg.p_ctrl, g_sf_el_fx0_cfg.p_config, &sector_size,
                                               &sector_count);

    if ((error != SSP_SUCCESS) || (sector_count <= 0))
    {
        return SSP_ERR_MEDIA_FORMAT_FAILED;
    }

    sector_count -= 0;
#endif

    if (sizeof(g_media_memory_g_fx_media0) < 512)
    {
        return SSP_ERR_MEDIA_FORMAT_FAILED;
    }

    /* Format media.  */
#ifdef FX_ENABLE_EXFAT
                fx_ret_val = fx_media_exFAT_format(&g_fx_media0, // Pointer to FileX media control block.
                                             SF_EL_FX_BlockDriver, // Driver entry
                                             &g_sf_el_fx0_cfg, // Pointer to Block Media Driver
                                             g_media_memory_g_fx_media0, // Media buffer pointer
                                             sizeof(g_media_memory_g_fx_media0), // Media buffer size
                                             (CHAR *)"Volume 1", // Volume Name
                                             1, // Number of FATs
                                             0, // Hidden sectors
                                             sector_count, // Total sectors - Hidden Sectors
                                             sector_size, // Sector size
                                             1, // Sectors per cluster
                                             12345, // Volume Serial Number
                                             128); // Boundary unit
#else
    fx_ret_val = fx_media_format (&g_fx_media0, // Pointer to FileX media control block.
            SF_EL_FX_BlockDriver, // Driver entry
            &g_sf_el_fx0_cfg, // Pointer to Block Media Driver
            g_media_memory_g_fx_media0, // Media buffer pointer
            sizeof(g_media_memory_g_fx_media0), // Media buffer size
            (CHAR*) "Volume 1", // Volume Name
            1, // Number of FATs
            256, // Directory Entries
            0, // Hidden sectors
            sector_count, // Total sectors - Hidden Sectors
            sector_size, // Sector size
            1, // Sectors per cluster
            1, // Heads
            1); // Sectors per track
#endif
    if (FX_SUCCESS != fx_ret_val)
    {
        return SSP_ERR_MEDIA_FORMAT_FAILED;
    }

    return SSP_SUCCESS;
}

uint32_t fx_media_init0_open(void)
{
    return fx_media_open (&g_fx_media0, (CHAR*) "g_fx_media0", SF_EL_FX_BlockDriver, &g_sf_el_fx0_cfg,
                          g_media_memory_g_fx_media0, sizeof(g_media_memory_g_fx_media0));
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void fx_media_init0(void)
 **********************************************************************************************************************/
void fx_media_init0(void)
{
#if SF_EL_FX_FORMAT_MEDIA_ENABLE_g_fx_media0

                ssp_err_t err_format = fx_media_init0_format();
                    
                if(err_format != SSP_SUCCESS)
                {
                    g_fx_media0_err_callback((void *)&g_fx_media0,&err_format);
                }

                #endif

    uint32_t err_open = fx_media_init0_open ();

    if (err_open != FX_SUCCESS)
    {
        g_fx_media0_err_callback ((void*) &g_fx_media0, &err_open);
    }
}
/* Instance structure to use this module. */
const fmi_instance_t g_fmi =
{ .p_api = &g_fmi_on_fmi };
const ioport_instance_t g_ioport =
{ .p_api = &g_ioport_on_ioport, .p_cfg = NULL };
const elc_instance_t g_elc =
{ .p_api = &g_elc_on_elc, .p_cfg = NULL };
const cgc_instance_t g_cgc =
{ .p_api = &g_cgc_on_cgc, .p_cfg = NULL };
ssp_err_t SF_EL_FX_Get_MEDIA_Info(sf_el_fx_ctrl_t *const p_api_ctrl, sf_el_fx_config_t const *const p_config,
        uint32_t *sector_size, uint32_t *sector_count)
{
    sf_el_fx_instance_ctrl_t *p_ctrl = (sf_el_fx_instance_ctrl_t*) p_api_ctrl;
    sf_block_media_instance_t *p_block_media = (sf_block_media_instance_t*) p_config->p_lower_lvl_block_media;
    ssp_err_t ret_val = SSP_SUCCESS;

    if (SF_EL_FX_PARTITION_GLOBAL_OPEN != p_ctrl->media_info.global_open.status)
    {
        ret_val = p_block_media->p_api->open (p_block_media->p_ctrl, p_block_media->p_cfg);
        if (ret_val != SSP_SUCCESS)
        {
            return ret_val;
        }
    }

    /* Get actual sector size from media. */
    ret_val = p_block_media->p_api->ioctl (p_block_media->p_ctrl, SSP_COMMAND_GET_SECTOR_SIZE, sector_size);
    if (ret_val != SSP_SUCCESS)
    {
        return ret_val;
    }

    /* Get actual sector count from media. */
    ret_val = p_block_media->p_api->ioctl (p_block_media->p_ctrl, SSP_COMMAND_GET_SECTOR_COUNT, sector_count);
    if (ret_val != SSP_SUCCESS)
    {
        return ret_val;
    }

    if (SF_EL_FX_PARTITION_GLOBAL_OPEN != p_ctrl->media_info.global_open.status)
    {
        /* Close driver.  */
        ret_val = p_block_media->p_api->close (p_block_media->p_ctrl);
    }

    return ret_val;
}
void g_common_init(void)
{

    /* Open Crypto Common Framework, only if 'Auto Initialization' property is enabled. */
#if (1)
    ssp_err_t ssp_err_g_sf_crypto0;
    ssp_err_g_sf_crypto0 = g_sf_crypto0.p_api->open (g_sf_crypto0.p_ctrl, g_sf_crypto0.p_cfg);
    if (SSP_SUCCESS != ssp_err_g_sf_crypto0)
    {
        BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
    }
#endif
    /** Call initialization function if user has selected to do so. */
#if (0)
            sf_wifi_gt202_init0();
        #endif

    /** Call initialization function if user has selected to do so. */
#if (1)
    ux_common_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    ux_host_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    nx_common_init0 ();
#endif
    /**  Call initialization function if user has selected to do so. */
#if (1)
    nx_secure_common_init ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    packet_pool_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    ip_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    nx_bsd_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if FX_COMMON_INITIALIZE
    fx_common_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if SF_EL_FX_AUTO_INIT_g_fx_media0
    fx_media_init0 ();
#endif
}
