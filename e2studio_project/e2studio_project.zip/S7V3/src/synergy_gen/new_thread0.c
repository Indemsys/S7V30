/* generated thread source file - do not edit */
#include "new_thread0.h"

#ifndef NX_DISABLE_IPV6
#ifndef FILL_NXD_IPV6_ADDRESS
#define FILL_NXD_IPV6_ADDRESS(ipv6,f0,f1,f2,f3,f4,f5,f6,f7) do { \
                                                                       ipv6.nxd_ip_address.v6[0] = (((uint32_t)f0 << 16) & 0xFFFF0000) | ((uint32_t)f1 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[1] = (((uint32_t)f2 << 16) & 0xFFFF0000) | ((uint32_t)f3 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[2] = (((uint32_t)f4 << 16) & 0xFFFF0000) | ((uint32_t)f5 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[3] = (((uint32_t)f6 << 16) & 0xFFFF0000) | ((uint32_t)f7 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_version       = NX_IP_VERSION_V6;\
                                                                   } while(0);
#endif /* FILL_NXD_IPV6_ADDRESS */
#endif
#ifndef NX_DISABLE_IPV6
#ifndef FILL_NXD_IPV6_ADDRESS
            #define FILL_NXD_IPV6_ADDRESS(ipv6,f0,f1,f2,f3,f4,f5,f6,f7) do { \
                                                                       ipv6.nxd_ip_address.v6[0] = (((uint32_t)f0 << 16) & 0xFFFF0000) | ((uint32_t)f1 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[1] = (((uint32_t)f2 << 16) & 0xFFFF0000) | ((uint32_t)f3 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[2] = (((uint32_t)f4 << 16) & 0xFFFF0000) | ((uint32_t)f5 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_address.v6[3] = (((uint32_t)f6 << 16) & 0xFFFF0000) | ((uint32_t)f7 & 0x0000FFFF);\
                                                                       ipv6.nxd_ip_version       = NX_IP_VERSION_V6;\
                                                                   } while(0);
            #endif /* FILL_NXD_IPV6_ADDRESS */
#endif

TX_THREAD new_thread0;
void new_thread0_create(void);
static void new_thread0_func(ULONG thread_input);
static uint8_t new_thread0_stack[1024] BSP_PLACE_IN_SECTION_V2(".stack.new_thread0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
void tx_startup_err_callback(void *p_instance, void *p_data);
void tx_startup_common_init(void);
/* Define the SNMP agent */
NX_SNMP_AGENT g_snmp_agent0;

#if defined(__ICCARM__)
      #define g_snmp_agent0_err_callback_WEAK_ATTRIBUTE
      #pragma weak g_snmp_agent0_err_callback  = g_snmp_agent0_err_callback_internal
      #elif defined(__GNUC__)
      #define g_snmp_agent0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_snmp_agent0_err_callback_internal")))
      #endif

void g_snmp_agent0_err_callback(void *p_instance, void *p_data)
g_snmp_agent0_err_callback_WEAK_ATTRIBUTE;
/*********************************************************************************************************************
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_snmp_agent0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_snmp_agent0_err_callback_internal(void *p_instance, void *p_data);
void g_snmp_agent0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

uint8_t g_snmp_agent0_stack_memory[NX_SNMP_AGENT_THREAD_STACK_SIZE] BSP_PLACE_IN_SECTION_V2(".stack.g_snmp_agent0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
/*********************************************************************************************************************
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void snmp_agent_init0(void)
 **********************************************************************************************************************/
void snmp_agent_init0(void)
{
    UINT g_snmp_agent0_err;
    /* Create SNMP Client. */
    g_snmp_agent0_err = nx_snmp_agent_create (&g_snmp_agent0, "REA SNMP AGENTg_snmp_agent0", &g_ip0,
                                              &g_snmp_agent0_stack_memory[0], NX_SNMP_AGENT_THREAD_STACK_SIZE,
                                              &g_packet_pool0, sf_snmp0_username_handler, sf_snmp0_get_handler,
                                              sf_snmp0_getnext_handler, sf_snmp0_set_handler);
    if (NX_SUCCESS != g_snmp_agent0_err)
    {
        g_snmp_agent0_err_callback ((void*) &g_snmp_agent0, &g_snmp_agent0_err);
    }

    /* Configure the community strings. These can be overriden by user before calling nx_snmp_agent_start */
    /* Configure Read community string */
    g_snmp_agent0_err = nx_snmp_agent_public_string_set (&g_snmp_agent0, (UCHAR*) "public");
    if (NX_SUCCESS != g_snmp_agent0_err)
    {
        g_snmp_agent0_err_callback ((void*) &g_snmp_agent0, &g_snmp_agent0_err);
    }

    /* Configure Write community string */
    g_snmp_agent0_err = nx_snmp_agent_private_string_set (&g_snmp_agent0, (UCHAR*) "private");
    if (NX_SUCCESS != g_snmp_agent0_err)
    {
        g_snmp_agent0_err_callback ((void*) &g_snmp_agent0, &g_snmp_agent0_err);
    }
}
NX_SMTP_CLIENT g_smtp_client0;
NXD_ADDRESS g_smtp_client0_ip_address;
#if defined(__ICCARM__)
            #define g_smtp_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_smtp_client0_err_callback  = g_smtp_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_smtp_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_smtp_client0_err_callback_internal")))
            #endif
void g_smtp_client0_err_callback(void *p_instance, void *p_data)
g_smtp_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_smtp_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_smtp_client0_err_callback_internal(void *p_instance, void *p_data);
void g_smtp_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void smtp_client_init0(void)
 **********************************************************************************************************************/
void smtp_client_init0(void)
{
    UINT g_smtp_client0_err;
    /* Create SMTP Client. */
#if !(1)
                g_smtp_client0_ip_address.nxd_ip_version = NX_IP_VERSION_V4;
                g_smtp_client0_ip_address.nxd_ip_address.v4 = IP_ADDRESS(192,168,0,2);
                #else
    FILL_NXD_IPV6_ADDRESS(g_smtp_client0_ip_address, 0x2001, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1);
#endif
    g_smtp_client0_err = nxd_smtp_client_create (&g_smtp_client0, &g_ip0, &g_packet_pool0, "username", "password",
                                                 "username@domain.com", "domain.com", NX_SMTP_CLIENT_AUTH_LOGIN,
                                                 &g_smtp_client0_ip_address, 25);
    if (NX_SUCCESS != g_smtp_client0_err)
    {
        g_smtp_client0_err_callback ((void*) &g_smtp_client0, &g_smtp_client0_err);
    }
}
NX_POP3_CLIENT g_pop3_client0;
#ifndef NX_DISABLE_IPV6
NXD_ADDRESS g_pop3_client0_ip_address;
#else
            ULONG g_pop3_client0_ip_address;
            #endif
#if defined(__ICCARM__)
            #define g_pop3_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_pop3_client0_err_callback  = g_pop3_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_pop3_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_pop3_client0_err_callback_internal")))
            #endif
void g_pop3_client0_err_callback(void *p_instance, void *p_data)
g_pop3_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_pop3_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_pop3_client0_err_callback_internal(void *p_instance, void *p_data);
void g_pop3_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void pop3_client_init0(void)
 **********************************************************************************************************************/
void pop3_client_init0(void)
{
    UINT g_pop3_client0_err;
    /* Create POP3 Client. */
#ifndef NX_DISABLE_IPV6
#if !(0)
    g_pop3_client0_ip_address.nxd_ip_version = NX_IP_VERSION_V4;
    g_pop3_client0_ip_address.nxd_ip_address.v4 = IP_ADDRESS (192, 168, 0, 2);
#else
                FILL_NXD_IPV6_ADDRESS(g_pop3_client0_ip_address,0x2001,0x0,0x0,0x0,0x0,0x0,0x0,0x1);
                #endif
    g_pop3_client0_err = nxd_pop3_client_create (&g_pop3_client0, NX_FALSE, &g_ip0, &g_packet_pool0,
                                                 &g_pop3_client0_ip_address, 110, "username@domain.com", "password");
#else
                g_pop3_client0_ip_address = IP_ADDRESS(192,168,0,2);
                g_pop3_client0_err = nx_pop3_client_create(&g_pop3_client0,
                                                                             NX_FALSE,
                                                                             &g_ip0,
                                                                             &g_packet_pool0,
                                                                             g_pop3_client0_ip_address,
                                                                             110,
                                                                             "username@domain.com",
                                                                             "password");
                #endif
    if (NX_SUCCESS != g_pop3_client0_err)
    {
        g_pop3_client0_err_callback ((void*) &g_pop3_client0, &g_pop3_client0_err);
    }
}
NX_HTTP_SERVER g_http_server0;
uint8_t g_http_server0_stack_memory[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_http_server0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define g_http_server0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_http_server0_err_callback  = g_http_server0_err_callback_internal
#elif defined(__GNUC__)
#define g_http_server0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_http_server0_err_callback_internal")))
#endif
void g_http_server0_err_callback(void *p_instance, void *p_data)
g_http_server0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_http_server0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_http_server0_err_callback_internal(void *p_instance, void *p_data);
void g_http_server0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void http_server_init0(void)
 **********************************************************************************************************************/
void http_server_init0(void)
{
    UINT g_http_server0_err;
    /* Create HTTP Server. */
    g_http_server0_err = nx_http_server_create (&g_http_server0, "g_http_server0 HTTP Server", &g_ip0, &g_fx_media0,
                                                &g_http_server0_stack_memory[0], 4096, &g_packet_pool0,
                                                authentication_check, request_notify);
    if (NX_SUCCESS != g_http_server0_err)
    {
        g_http_server0_err_callback ((void*) &g_http_server0, &g_http_server0_err);
    }
}
NX_HTTP_CLIENT g_http_client0;
#if defined(__ICCARM__)
            #define g_http_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_http_client0_err_callback  = g_http_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_http_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_http_client0_err_callback_internal")))
            #endif
void g_http_client0_err_callback(void *p_instance, void *p_data)
g_http_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_http_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_http_client0_err_callback_internal(void *p_instance, void *p_data);
void g_http_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void http_client_init0(void)
 **********************************************************************************************************************/
void http_client_init0(void)
{
    UINT g_http_client0_err;
    /* Create HTTP Client. */
    g_http_client0_err = nx_http_client_create (&g_http_client0, "g_http_client0 HTTP Client", &g_ip0, &g_packet_pool0,
                                                1024);
    if (NX_SUCCESS != g_http_client0_err)
    {
        g_http_client0_err_callback ((void*) &g_http_client0, &g_http_client0_err);
    }
}
NX_DHCPV6_SERVER g_dhcpv6_server0;
uint8_t g_dhcpv6_server0_stack_memory[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_dhcpv6_server0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define g_dhcpv6_server0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_dhcpv6_server0_err_callback  = g_dhcpv6_server0_err_callback_internal
#elif defined(__GNUC__)
#define g_dhcpv6_server0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_dhcpv6_server0_err_callback_internal")))
#endif
void g_dhcpv6_server0_err_callback(void *p_instance, void *p_data)
g_dhcpv6_server0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_dhcpv6_server0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_dhcpv6_server0_err_callback_internal(void *p_instance, void *p_data);
void g_dhcpv6_server0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void dhcpv6_server_init0(void)
 **********************************************************************************************************************/
void dhcpv6_server_init0(void)
{
    UINT g_dhcpv6_server0_err;
    /* Create DHCP Server. */
    g_dhcpv6_server0_err = nx_dhcpv6_server_create (&g_dhcpv6_server0, &g_ip0, "g_dhcpv6_server0 dhcp Server",
                                                    &g_packet_pool0, &g_dhcpv6_server0_stack_memory[0], 4096,
                                                    dhcpv6_address_declined_handler, dhcpv6_option_request_handler);
    if (NX_SUCCESS != g_dhcpv6_server0_err)
    {
        g_dhcpv6_server0_err_callback ((void*) &g_dhcpv6_server0, &g_dhcpv6_server0_err);
    }
}
NX_DHCPV6 g_dhcpv6_client0;
uint8_t g_dhcpv6_client0_stack_memory[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_dhcpv6_client0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define g_dhcpv6_client0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_dhcpv6_client0_err_callback  = g_dhcpv6_client0_err_callback_internal
#elif defined(__GNUC__)
#define g_dhcpv6_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_dhcpv6_client0_err_callback_internal")))
#endif
void g_dhcpv6_client0_err_callback(void *p_instance, void *p_data)
g_dhcpv6_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_dhcpv6_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_dhcpv6_client0_err_callback_internal(void *p_instance, void *p_data);
void g_dhcpv6_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     This is nx dhcpv6 client initialization function. User Can call this function in the application if required with the below mentioned prototype.
 *            - void nx_dhcpv6_client_init0(void)
 **********************************************************************************************************************/
void nx_dhcpv6_client_init0(void)
{
    UINT g_dhcpv6_client0_err;
    /* Create DHCPv6 client. */
    g_dhcpv6_client0_err = nx_dhcpv6_client_create (&g_dhcpv6_client0, &g_ip0, "g_dhcpv6_client0_DHCPv6",
                                                    &g_packet_pool0, &g_dhcpv6_client0_stack_memory[0], 4096,
                                                    dhcpv6_state_change_notify, dhcpv6_server_error_handler);
    if (NX_SUCCESS != g_dhcpv6_client0_err)
    {
        g_dhcpv6_client0_err_callback ((void*) &g_dhcpv6_client0, &g_dhcpv6_client0_err);
    }
}
NX_MDNS g_mdns0;
UCHAR g_mdns0_stack_memory[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_mdns0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
UCHAR g_mdns0_local_service_cache[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_mdns0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
UCHAR g_mdns0_peer_service_cache[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_mdns0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);

#if defined(__ICCARM__)
#define g_mdns0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_mdns0_err_callback  = g_mdns0_err_callback_internal
#elif defined(__GNUC__)
#define g_mdns0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_mdns0_err_callback_internal")))
#endif
void g_mdns0_err_callback(void *p_instance, void *p_data)
g_mdns0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_mdns0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_mdns0_err_callback_internal(void *p_instance, void *p_data);
void g_mdns0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void mdns_init0(void)
 **********************************************************************************************************************/
void mdns_init0(void)
{
    UINT g_mdns0_err;

    /* Create mDNS Client. */
    g_mdns0_err = nx_mdns_create (&g_mdns0, &g_ip0, &g_packet_pool0, 3, g_mdns0_stack_memory, 4096,
                                  (UCHAR*) "NETX-MDNS-HOST", (VOID*) g_mdns0_local_service_cache, 4096,
                                  (VOID*) g_mdns0_peer_service_cache, 4096, probing_notify);
    if (NX_SUCCESS != g_mdns0_err)
    {
        g_mdns0_err_callback ((void*) &g_mdns0, &g_mdns0_err);
    }
}
NX_WEB_HTTP_SERVER g_web_http_server0;
uint8_t g_web_http_server0_stack_memory[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_web_http_server0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define g_web_http_server0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_web_http_server0_err_callback  = g_web_http_server0_err_callback_internal
#elif defined(__GNUC__)
#define g_web_http_server0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_web_http_server0_err_callback_internal")))
#endif
void g_web_http_server0_err_callback(void *p_instance, void *p_data)
g_web_http_server0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_web_http_server0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_web_http_server0_err_callback_internal(void *p_instance, void *p_data);
void g_web_http_server0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void web_http_server_init0(void)
 **********************************************************************************************************************/
void web_http_server_init0(void)
{
    UINT g_web_http_server0_err;
    /* Create HTTP Server. */
    g_web_http_server0_err = nx_web_http_server_create (&g_web_http_server0, "g_web_http_server0 HTTP Server", &g_ip0,
                                                        80, &g_fx_media0, &g_web_http_server0_stack_memory[0], 4096,
                                                        &g_packet_pool0, NULL, NULL);
    if (NX_SUCCESS != g_web_http_server0_err)
    {
        g_web_http_server0_err_callback ((void*) &g_web_http_server0, &g_web_http_server0_err);
    }
}
NX_WEB_HTTP_CLIENT g_web_http_client0;
#if defined(__ICCARM__)
            #define g_web_http_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_web_http_client0_err_callback  = g_web_http_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_web_http_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_web_http_client0_err_callback_internal")))
            #endif
void g_web_http_client0_err_callback(void *p_instance, void *p_data)
g_web_http_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_web_http_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_web_http_client0_err_callback_internal(void *p_instance, void *p_data);
void g_web_http_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void web_http_client_init0(void)
 **********************************************************************************************************************/
void web_http_client_init0(void)
{
    UINT g_web_http_client0_err;
    /* Create HTTP Client. */
    g_web_http_client0_err = nx_web_http_client_create (&g_web_http_client0, "g_web_http_client0 HTTP Client", &g_ip0,
                                                        &g_packet_pool0, 1024);
    if (NX_SUCCESS != g_web_http_client0_err)
    {
        g_web_http_client0_err_callback ((void*) &g_web_http_client0, &g_web_http_client0_err);
    }
}
NX_TELNET_SERVER g_telnet_server0;
uint8_t g_telnet_server0_stack_memory[2048] BSP_PLACE_IN_SECTION_V2(".stack.g_telnet_server0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define g_telnet_server0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_telnet_server0_err_callback  = g_telnet_server0_err_callback_internal
#elif defined(__GNUC__)
#define g_telnet_server0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_telnet_server0_err_callback_internal")))
#endif
void g_telnet_server0_err_callback(void *p_instance, void *p_data)
g_telnet_server0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_telnet_server0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_telnet_server0_err_callback_internal(void *p_instance, void *p_data);
void g_telnet_server0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void telnet_server_init0(void)
 **********************************************************************************************************************/
void telnet_server_init0(void)
{
    UINT g_telnet_server0_err;
    /* Create Telnet Server. */
    g_telnet_server0_err = nx_telnet_server_create (&g_telnet_server0, "g_telnet_server0 Telnet Server", &g_ip0,
                                                    &g_telnet_server0_stack_memory[0], 2048, telnet_client_connect,
                                                    telnet_receive_data, telnet_client_disconnect);
    if (NX_SUCCESS != g_telnet_server0_err)
    {
        g_telnet_server0_err_callback ((void*) &g_telnet_server0, &g_telnet_server0_err);
    }
}
NX_TELNET_CLIENT g_telnet_client0;
#if defined(__ICCARM__)
            #define g_telnet_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_telnet_client0_err_callback  = g_telnet_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_telnet_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_telnet_client0_err_callback_internal")))
            #endif
void g_telnet_client0_err_callback(void *p_instance, void *p_data)
g_telnet_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_telnet_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_telnet_client0_err_callback_internal(void *p_instance, void *p_data);
void g_telnet_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void telnet_client_init0(void)
 **********************************************************************************************************************/
void telnet_client_init0(void)
{
    UINT g_telnet_client0_err;

    /* Create Telnet Client. */
    g_telnet_client0_err = nx_telnet_client_create (&g_telnet_client0, "g_telnet_client0 Telnet Client", &g_ip0, 1024);

    if (NX_SUCCESS != g_telnet_client0_err)
    {
        g_telnet_client0_err_callback ((void*) &g_telnet_client0, &g_telnet_client0_err);
    }
}
NX_SNTP_CLIENT g_sntp_client0;
#if defined(__ICCARM__)
            #define g_sntp_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_sntp_client0_err_callback  = g_sntp_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_sntp_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_sntp_client0_err_callback_internal")))
            #endif
void g_sntp_client0_err_callback(void *p_instance, void *p_data)
g_sntp_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_sntp_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_sntp_client0_err_callback_internal(void *p_instance, void *p_data);
void g_sntp_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void sntp_client_init0(void)
 **********************************************************************************************************************/
void sntp_client_init0(void)
{
    UINT g_sntp_client0_err;
    /* Create SNTP Client. */
    g_sntp_client0_err = nx_sntp_client_create (&g_sntp_client0, &g_ip0, 0, &g_packet_pool0, leap_second_handler,
                                                kiss_of_death_handler, NULL);
    if (NX_SUCCESS != g_sntp_client0_err)
    {
        g_sntp_client0_err_callback ((void*) &g_sntp_client0, &g_sntp_client0_err);
    }
}
NXD_MQTT_CLIENT g_mqtt_client0;
#if defined(__ICCARM__)
            #define g_mqtt_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_mqtt_client0_err_callback  = g_mqtt_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_mqtt_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_mqtt_client0_err_callback_internal")))
            #endif
void g_mqtt_client0_err_callback(void *p_instance, void *p_data)
g_mqtt_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_mqtt_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error 
 * @param[in]  p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_mqtt_client0_err_callback_internal(void *p_instance, void *p_data);
void g_mqtt_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}

static UCHAR g_mqtt_client0_stack[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_mqtt_client0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
char g_mqtt_client0_client_id[12];
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void mqtt_client_init0(void)
 **********************************************************************************************************************/
void mqtt_client_init0(void)
{
    UINT g_mqtt_client0_err;
    uint32_t mqtt_client_id_len = 0;

#if NXD_MQTT_CLIENT_ID_CALLBACK_USED_g_mqtt_client0
                /** Declaration of user callback function. This function MUST be defined in the user application.*/
                 mqtt_client_id_callback( g_mqtt_client0_client_id, &mqtt_client_id_len );
                #endif                

    /* Create MQTT client. */
    g_mqtt_client0_err = nxd_mqtt_client_create (&g_mqtt_client0, "g_mqtt_client0 MQTT Client",
                                                 g_mqtt_client0_client_id, mqtt_client_id_len, &g_ip0, &g_packet_pool0,
                                                 (VOID*) g_mqtt_client0_stack, 4096, 2, NULL, 0); /* memory_ptr and memory_size are deprecated in NetX Secure 6.1.3.*/

    if (NX_SUCCESS != g_mqtt_client0_err)
    {
        g_mqtt_client0_err_callback ((void*) &g_mqtt_client0, &g_mqtt_client0_err);
    }
}
extern const sf_wifi_nsal_cfg_t g_sf_wifi0_nsal_cfg;
/** NetX driver entry function. We will take what NetX gives and add on WiFi framework instance. */
VOID g_sf_el_nx1(NX_IP_DRIVER *p_driver)
{
    nsal_netx_driver (p_driver, &g_sf_wifi0, (sf_wifi_nsal_cfg_t*) &g_sf_wifi0_nsal_cfg);
}
NX_NAT_DEVICE g_nat0;
uint8_t g_nat0_cache_memory[1024];
#if defined(__ICCARM__)
            #define g_nat0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_nat0_err_callback  = g_nat0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_nat0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_nat0_err_callback_internal")))
            #endif
void g_nat0_err_callback(void *p_instance, void *p_data)
g_nat0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_nat0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_nat0_err_callback_internal(void *p_instance, void *p_data);
void g_nat0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void nat_init0(void)
 **********************************************************************************************************************/
void nat_init0(void)
{
    UINT g_nat0_err;
    /* Set the private interface. External was already created. */
    g_nat0_err = nx_ip_interface_attach (&g_ip0, "g_nat0 Private Interface", IP_ADDRESS (192, 168, 0, 2),
                                         IP_ADDRESS (255, 255, 255, 0), g_sf_el_nx1);
    if (NX_SUCCESS != g_nat0_err)
    {
        g_nat0_err_callback ((void*) &g_nat0, &g_nat0_err);
    }
    /* Create a NAT server and cache with a global interface index. */
    g_nat0_err = nx_nat_create (&g_nat0, &g_ip0, 0, &g_nat0_cache_memory[0], 1024);

    if (NX_SUCCESS != g_nat0_err)
    {
        g_nat0_err_callback ((void*) &g_nat0, &g_nat0_err);
    }
}
NX_FTP_SERVER g_ftp_server0;
uint8_t g_ftp_server0_stack_memory[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_ftp_server0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define g_ftp_server0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_ftp_server0_err_callback  = g_ftp_server0_err_callback_internal
#elif defined(__GNUC__)
#define g_ftp_server0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_ftp_server0_err_callback_internal")))
#endif
void g_ftp_server0_err_callback(void *p_instance, void *p_data)
g_ftp_server0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_ftp_server0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_ftp_server0_err_callback_internal(void *p_instance, void *p_data);
void g_ftp_server0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void ftp_server_init0(void)
 **********************************************************************************************************************/
void ftp_server_init0(void)
{
    UINT g_ftp_server0_err;
    /* Create FTP Server. */
#ifndef NX_DISABLE_IPV6
    g_ftp_server0_err = nxd_ftp_server_create (&g_ftp_server0, "g_ftp_server0 FTP Server", &g_ip0, &g_fx_media0,
                                               &g_ftp_server0_stack_memory[0], 4096, &g_packet_pool0, ftp_login,
                                               ftp_logout);
#else                                                           
                g_ftp_server0_err = nx_ftp_server_create(&g_ftp_server0,
                                                                           "g_ftp_server0 FTP Server",
                                                                           &g_ip0,
                                                                           &g_fx_media0,
                                                                           &g_ftp_server0_stack_memory[0],
                                                                           4096,
                                                                           &g_packet_pool0,
                                                                           ftp_login,
                                                                           ftp_logout);
                #endif                                                                       
    if (NX_SUCCESS != g_ftp_server0_err)
    {
        g_ftp_server0_err_callback ((void*) &g_ftp_server0, &g_ftp_server0_err);
    }
}
NX_FTP_CLIENT g_ftp_client0;
#if defined(__ICCARM__)
            #define g_ftp_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_ftp_client0_err_callback  = g_ftp_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_ftp_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_ftp_client0_err_callback_internal")))
            #endif
void g_ftp_client0_err_callback(void *p_instance, void *p_data)
g_ftp_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_ftp_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_ftp_client0_err_callback_internal(void *p_instance, void *p_data);
void g_ftp_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void ftp_client_init0(void)
 **********************************************************************************************************************/
void ftp_client_init0(void)
{
    UINT g_ftp_client0_err;
    /* Create FTP Client. */
    g_ftp_client0_err = nx_ftp_client_create (&g_ftp_client0, "g_ftp_client0 FTP Client", &g_ip0, 2048,
                                              &g_packet_pool0);
    if (NX_SUCCESS != g_ftp_client0_err)
    {
        g_ftp_client0_err_callback ((void*) &g_ftp_client0, &g_ftp_client0_err);
    }
}
NX_DNS g_dns0;

#ifdef NX_DNS_CLIENT_USER_CREATE_PACKET_POOL
            NX_PACKET_POOL  g_dns0_packet_pool; 
            uint8_t         g_dns0_pool_memory[NX_DNS_PACKET_POOL_SIZE];
            #endif

#if defined(__ICCARM__)
            #define g_dns0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_dns0_err_callback  = g_dns0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_dns0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_dns0_err_callback_internal")))
            #endif
void g_dns0_err_callback(void *p_instance, void *p_data)
g_dns0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_dns0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_dns0_err_callback_internal(void *p_instance, void *p_data);
void g_dns0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void dns_client_init0(void)
 **********************************************************************************************************************/
void dns_client_init0(void)
{
    UINT g_dns0_err;

#ifdef NX_DNS_CLIENT_USER_CREATE_PACKET_POOL
                g_dns0_err = nx_packet_pool_create(&g_dns0_packet_pool, "g_dns0 Packet Pool", NX_DNS_PACKET_PAYLOAD, &g_dns0_pool_memory[0], NX_DNS_PACKET_POOL_SIZE);
				
                if (NX_SUCCESS != g_dns0_err)
                {
                    g_dns0_err_callback((void *)&g_dns0,&g_dns0_err);
                }
                
                g_dns0.nx_dns_packet_pool_ptr = &g_dns0_packet_pool;
                #endif

    /* Create DNS Client. */
    g_dns0_err = nx_dns_create (&g_dns0, &g_ip0, (UCHAR*) "g_dns0 DNS Client");
    if (NX_SUCCESS != g_dns0_err)
    {
        g_dns0_err_callback ((void*) &g_dns0, &g_dns0_err);
    }
}
NX_DHCP_SERVER g_dhcp_server0;
uint8_t g_dhcp_server0_stack_memory[4096] BSP_PLACE_IN_SECTION_V2(".stack.g_dhcp_server0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define g_dhcp_server0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_dhcp_server0_err_callback  = g_dhcp_server0_err_callback_internal
#elif defined(__GNUC__)
#define g_dhcp_server0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_dhcp_server0_err_callback_internal")))
#endif
void g_dhcp_server0_err_callback(void *p_instance, void *p_data)
g_dhcp_server0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_dhcp_server0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_dhcp_server0_err_callback_internal(void *p_instance, void *p_data);
void g_dhcp_server0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     This is nx dhcp server initialization function. User Can call this function in the application if required with the below mentioned prototype.
 *            - void nx_dhcp_server_init0(void)
 *********************************************************************************************************************/
void nx_dhcp_server_init0(void)
{
    UINT g_dhcp_server0_err;
    /* Create DHCP Server. */
    g_dhcp_server0_err = nx_dhcp_server_create (&g_dhcp_server0, &g_ip0, &g_dhcp_server0_stack_memory[0], 4096,
                                                "g_dhcp_server0 dhcp Server", &g_packet_pool0);
    if (NX_SUCCESS != g_dhcp_server0_err)
    {
        g_dhcp_server0_err_callback ((void*) &g_dhcp_server0, &g_dhcp_server0_err);
    }
}
NX_DHCP g_dhcp_client0;
#if defined(__ICCARM__)
            #define g_dhcp_client0_err_callback_WEAK_ATTRIBUTE
            #pragma weak g_dhcp_client0_err_callback  = g_dhcp_client0_err_callback_internal
            #elif defined(__GNUC__)
            #define g_dhcp_client0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_dhcp_client0_err_callback_internal")))
            #endif
void g_dhcp_client0_err_callback(void *p_instance, void *p_data)
g_dhcp_client0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_dhcp_client0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_dhcp_client0_err_callback_internal(void *p_instance, void *p_data);
void g_dhcp_client0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void dhcp_client_init0(void)
 **********************************************************************************************************************/
void dhcp_client_init0(void)
{
    UINT g_dhcp_client0_err;
    /* Create DHCP client. */
    g_dhcp_client0_err = nx_dhcp_create (&g_dhcp_client0, &g_ip0, "g_dhcp_client0_DHCPv4");
    if (NX_SUCCESS != g_dhcp_client0_err)
    {
        g_dhcp_client0_err_callback ((void*) &g_dhcp_client0, &g_dhcp_client0_err);
    }

#if DHCP_USR_OPT_ADD_ENABLE_g_dhcp_client0
                /* Set callback function to add user options.  */
                g_dhcp_client0_err =  nx_dhcp_user_option_add_callback_set(&g_dhcp_client0,
                                                                                             dhcp_user_option_add_client0);

                if (NX_SUCCESS != g_dhcp_client0_err)
                {
                    g_dhcp_client0_err_callback((void *)&g_dhcp_client0,&g_dhcp_client0_err);
                }
                #endif
}

#if DHCP_USR_OPT_ADD_ENABLE_g_dhcp_client0 && DHCP_USR_OPT_ADD_FUNCTION_ENABLE_g_dhcp_client0
            UCHAR g_dhcp_client0_opt_num = 60;
            CHAR *g_dhcp_client0_opt_val = "REA";

            /*******************************************************************************************************************//**
             * @brief     This DHCP user options add function adds Vendor Class ID. User can change the option number and/or option
             *            value in the user defined code by simply overriding the values. This function work fine to add any option
             *            which takes string values for option. Like below
             *            g_dhcp_client0_opt_num = 43;
             *            g_dhcp_client0_opt_val = "OPT43VAL";
             *            If user wants to chain the options, should disable this function generation and provide their own definition.
             **********************************************************************************************************************/
            UINT dhcp_user_option_add_client0(NX_DHCP *dhcp_ptr, UINT iface_index, UINT message_type, UCHAR *user_option_ptr, UINT *user_option_length)
            {
                NX_PARAMETER_NOT_USED(dhcp_ptr);
                NX_PARAMETER_NOT_USED(iface_index);
                NX_PARAMETER_NOT_USED(message_type);

                /* Application can check if add options into the packet by iface_index and message_type.
                   message_type are defined in header file, such as: NX_DHCP_TYPE_DHCPDISCOVER.  */
                /* Add Vendor Class ID option refer to RFC2132.  */

                /* Check if have enough space for this option.  */
                if (*user_option_length < (strlen(g_dhcp_client0_opt_val) + 2))
                {
                    return(NX_FALSE);
                }

                /* Set the option code.  */
                *user_option_ptr = g_dhcp_client0_opt_num;

                /* Set the option length.  */
                *(user_option_ptr + 1) = (UCHAR)strlen(g_dhcp_client0_opt_val);

                /* Set the option value (Vendor class id).  */
                memcpy((user_option_ptr + 2), g_dhcp_client0_opt_val, strlen(g_dhcp_client0_opt_val));

                /* Update the option length.  */
                *user_option_length = (strlen(g_dhcp_client0_opt_val) + 2);

                return(NX_TRUE);
            }
            #endif
NX_AUTO_IP g_auto_ip0;
uint8_t g_auto_ip0_stack_memory[2048] BSP_PLACE_IN_SECTION_V2(".stack.g_auto_ip0") BSP_ALIGN_VARIABLE_V2(BSP_STACK_ALIGNMENT);
#if defined(__ICCARM__)
#define g_auto_ip0_err_callback_WEAK_ATTRIBUTE
#pragma weak g_auto_ip0_err_callback  = g_auto_ip0_err_callback_internal
#elif defined(__GNUC__)
#define g_auto_ip0_err_callback_WEAK_ATTRIBUTE   __attribute__ ((weak, alias("g_auto_ip0_err_callback_internal")))
#endif
void g_auto_ip0_err_callback(void *p_instance, void *p_data)
g_auto_ip0_err_callback_WEAK_ATTRIBUTE;
/*******************************************************************************************************************//**
 * @brief      This is a weak example initialization error function.  It should be overridden by defining a user  function
 *             with the prototype below.
 *             - void g_auto_ip0_err_callback(void * p_instance, void * p_data)
 *
 * @param[in]  p_instance arguments used to identify which instance caused the error and p_data Callback arguments used to identify what error caused the callback.
 **********************************************************************************************************************/
void g_auto_ip0_err_callback_internal(void *p_instance, void *p_data);
void g_auto_ip0_err_callback_internal(void *p_instance, void *p_data)
{
    /** Suppress compiler warning for not using parameters. */
    SSP_PARAMETER_NOT_USED (p_instance);
    SSP_PARAMETER_NOT_USED (p_data);

    /** An error has occurred. Please check function arguments for more information. */
    BSP_CFG_HANDLE_UNRECOVERABLE_ERROR (0);
}
/*******************************************************************************************************************//**
 * @brief     Initialization function that the user can choose to have called automatically during thread entry.
 *            The user can call this function at a later time if desired using the prototype below.
 *            - void auto_ip_init0(void)
 **********************************************************************************************************************/
void auto_ip_init0(void)
{
    UINT g_auto_ip0_err;
    /* Create AutoIP Instance. */
    g_auto_ip0_err = nx_auto_ip_create (&g_auto_ip0, "g_auto_ip0 Auto IP", &g_ip0, &g_auto_ip0_stack_memory, 2048, 3);
    if (NX_SUCCESS != g_auto_ip0_err)
    {
        g_auto_ip0_err_callback ((void*) &g_auto_ip0, &g_auto_ip0_err);
    }
}
extern bool g_ssp_common_initialized;
extern uint32_t g_ssp_common_thread_count;
extern TX_SEMAPHORE g_ssp_common_initialized_semaphore;

void new_thread0_create(void)
{
    /* Increment count so we will know the number of ISDE created threads. */
    g_ssp_common_thread_count++;

    /* Initialize each kernel object. */

    UINT err;
    err = tx_thread_create (&new_thread0, (CHAR*) "Net", new_thread0_func, (ULONG) NULL, &new_thread0_stack, 1024, 1, 1,
                            1, TX_AUTO_START);
    if (TX_SUCCESS != err)
    {
        tx_startup_err_callback (&new_thread0, 0);
    }
}

static void new_thread0_func(ULONG thread_input)
{
    /* Not currently using thread_input. */
    SSP_PARAMETER_NOT_USED (thread_input);

    /* Initialize common components */
    tx_startup_common_init ();

    /* Initialize each module instance. */
    /** Call initialization function if user has selected to do so. */
#if (1)
    snmp_agent_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    smtp_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (0)
                    pop3_client_init0();
               #endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    http_server_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    http_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    dhcpv6_server_init0 ();
#endif
    /** Call nx dhcpv6 client initialization function. User Can call at later time as well if required. */
#if (1)
    nx_dhcpv6_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    mdns_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    web_http_server_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    web_http_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    telnet_server_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    telnet_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    sntp_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    mqtt_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    nat_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    ftp_server_init0 ();
#endif
    /**  Call initialization function if user has selected to do so */
#if (1)
    ftp_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    dns_client_init0 ();
#endif
    /** Call nx dhcp server initialization function. User Can call at later time as well if required. */
#if (1)
    nx_dhcp_server_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    dhcp_client_init0 ();
#endif
    /** Call initialization function if user has selected to do so. */
#if (1)
    auto_ip_init0 ();
#endif

    /* Enter user code for this thread. */
    new_thread0_entry ();
}
