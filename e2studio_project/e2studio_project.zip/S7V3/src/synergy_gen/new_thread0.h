/* generated thread header file - do not edit */
#ifndef NEW_THREAD0_H_
#define NEW_THREAD0_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus
                extern "C" void new_thread0_entry(void);
                #else
extern void new_thread0_entry(void);
#endif
#include "nxd_snmp.h"
#include "nxd_smtp_client.h"
#include "nxd_pop3_client.h"
#include "nx_md5.h"
#include "nxd_http_server.h"
#include "nxd_http_client.h"
#include "nxd_dhcpv6_server.h"
#include "nxd_dhcpv6_client.h"
#include "nxd_mdns.h"
#include "nx_web_http_server.h"
#include "nx_web_http_client.h"
#include "nxd_telnet_server.h"
#include "nxd_telnet_client.h"
#include "nxd_sntp_client.h"
#include "nxd_mqtt_client.h"
#include "nx_api.h"
#include "sf_wifi_nsal_nx.h"
#include "nx_nat.h"
#include "nxd_ftp_server.h"
#include "nxd_ftp_client.h"
#include "nxd_dns.h"
#include "nxd_dhcp_server.h"
#include "nxd_dhcp_client.h"
#include "nx_auto_ip.h"
#ifdef __cplusplus
extern "C" {
#endif
extern NX_SNMP_AGENT g_snmp_agent0;

/* Function Declarations */
void snmp_agent_init0(void);

/* These handlers should be implemented by the user */
UINT sf_snmp0_username_handler(NX_SNMP_AGENT*, UCHAR*);
UINT sf_snmp0_get_handler(NX_SNMP_AGENT*, UCHAR*, NX_SNMP_OBJECT_DATA*);
UINT sf_snmp0_getnext_handler(NX_SNMP_AGENT*, UCHAR*, NX_SNMP_OBJECT_DATA*);
UINT sf_snmp0_set_handler(NX_SNMP_AGENT*, UCHAR*, NX_SNMP_OBJECT_DATA*);
extern NX_SMTP_CLIENT g_smtp_client0;
void g_smtp_client0_err_callback(void *p_instance, void *p_data);
void smtp_client_init0(void);
extern NX_POP3_CLIENT g_pop3_client0;
void g_pop3_client0_err_callback(void *p_instance, void *p_data);
void pop3_client_init0(void);
extern NX_HTTP_SERVER g_http_server0;
#if !defined(authentication_check)
UINT authentication_check(NX_HTTP_SERVER *server_ptr, UINT request_type, CHAR *resource, CHAR **name, CHAR **password,
        CHAR **realm);
#endif
#if !defined(request_notify)
UINT request_notify(NX_HTTP_SERVER *server_ptr, UINT request_type, CHAR *resource, NX_PACKET *packet_ptr);
#endif
void g_http_server0_err_callback(void *p_instance, void *p_data);
void http_server_init0(void);
extern NX_HTTP_CLIENT g_http_client0;
void g_http_client0_err_callback(void *p_instance, void *p_data);
void http_client_init0(void);
extern NX_DHCPV6_SERVER g_dhcpv6_server0;
#if !defined(dhcpv6_address_declined_handler)
VOID dhcpv6_address_declined_handler(struct NX_DHCPV6_SERVER_STRUCT *dhcpv6_server_ptr,
        NX_DHCPV6_CLIENT *dhcpv6_client_ptr, UINT message);
#endif
#if !defined(dhcpv6_option_request_handler)
VOID dhcpv6_option_request_handler(struct NX_DHCPV6_SERVER_STRUCT *dhcpv6_server_ptr, UINT option_request,
        UCHAR *buffer_ptr, UINT *index);
#endif
void g_dhcpv6_server0_err_callback(void *p_instance, void *p_data);
void dhcpv6_server_init0(void);
extern NX_DHCPV6 g_dhcpv6_client0;
#if !defined(dhcpv6_state_change_notify)
VOID dhcpv6_state_change_notify(struct NX_DHCPV6_STRUCT *dhcpv6_ptr, UINT old_state, UINT new_state);
#endif
#if !defined(dhcpv6_server_error_handler)
VOID dhcpv6_server_error_handler(struct NX_DHCPV6_STRUCT *dhcpv6_ptr, UINT op_code, UINT status_code, UINT message_type);
#endif
void g_dhcpv6_client0_err_callback(void *p_instance, void *p_data);
void nx_dhcpv6_client_init0(void);
extern NX_MDNS g_mdns0;
void g_mdns0_err_callback(void *p_instance, void *p_data);
void mdns_init0(void);
#if !defined(probing_notify)
void probing_notify(NX_MDNS *mdns_ptr, UCHAR *name, UINT probing_state);
#endif
extern NX_WEB_HTTP_SERVER g_web_http_server0;
#if !defined(NULL)
UINT NULL(NX_WEB_HTTP_SERVER *server_ptr, UINT request_type, CHAR *resource, CHAR **name, CHAR **password, CHAR **realm);
#endif
#if !defined(NULL)
UINT NULL(NX_WEB_HTTP_SERVER *server_ptr, UINT request_type, CHAR *resource, NX_PACKET *packet_ptr);
#endif
void g_web_http_server0_err_callback(void *p_instance, void *p_data);
void web_http_server_init0(void);
extern NX_WEB_HTTP_CLIENT g_web_http_client0;
void g_web_http_client0_err_callback(void *p_instance, void *p_data);
void web_http_client_init0(void);
#define g_telnet_server0_IP_PTR (&g_ip0)

extern NX_TELNET_SERVER g_telnet_server0;
#if !defined(telnet_client_connect)
void telnet_client_connect(struct NX_TELNET_SERVER_STRUCT *telnet_server_ptr, UINT logical_connection);
#endif
#if !defined(telnet_receive_data)
void telnet_receive_data(struct NX_TELNET_SERVER_STRUCT *telnet_server_ptr, UINT logical_connection,
        NX_PACKET *packet_ptr);
#endif
#if !defined(telnet_client_disconnect)
void telnet_client_disconnect(struct NX_TELNET_SERVER_STRUCT *telnet_server_ptr, UINT logical_connection);
#endif
void g_telnet_server0_err_callback(void *p_instance, void *p_data);
void telnet_server_init0(void);
extern NX_TELNET_CLIENT g_telnet_client0;
void g_telnet_client0_err_callback(void *p_instance, void *p_data);
void telnet_client_init0(void);
extern NX_SNTP_CLIENT g_sntp_client0;
#if !defined(leap_second_handler)
UINT leap_second_handler(NX_SNTP_CLIENT *client_ptr, UINT indicator);
#endif
#if !defined(kiss_of_death_handler)
UINT kiss_of_death_handler(NX_SNTP_CLIENT *client_ptr, UINT code);
#endif
#if !defined(NULL)
VOID NULL(struct NX_SNTP_CLIENT_STRUCT *client_ptr, ULONG *rand);
#endif
void g_sntp_client0_err_callback(void *p_instance, void *p_data);
void sntp_client_init0(void);
extern NXD_MQTT_CLIENT g_mqtt_client0;

/** MQTT CLIENT ID Callback */
#ifdef mqtt_client_id_callback
            #define NXD_MQTT_CLIENT_ID_CALLBACK_USED_g_mqtt_client0 (0)
            #else
#define NXD_MQTT_CLIENT_ID_CALLBACK_USED_g_mqtt_client0 (1)
#endif
#if NXD_MQTT_CLIENT_ID_CALLBACK_USED_g_mqtt_client0
/** Declaration of user callback function. This function MUST be defined in the user application.*/
extern void mqtt_client_id_callback(char *client_id, uint32_t *client_id_length);
#endif

void g_mqtt_client0_err_callback(void *p_instance, void *p_data);
void mqtt_client_init0(void);
/** NetX driver entry function. */
VOID g_sf_el_nx1(NX_IP_DRIVER *p_driver);
extern NX_NAT_DEVICE g_nat0;
void g_nat0_err_callback(void *p_instance, void *p_data);
void nat_init0(void);
extern NX_FTP_SERVER g_ftp_server0;
#ifndef NX_DISABLE_IPV6
#if !defined (ftp_login)
UINT ftp_login(struct NX_FTP_SERVER_STRUCT *ftp_server_ptr, NXD_ADDRESS *client_ip_address, UINT client_port,
        CHAR *name, CHAR *password, CHAR *extra_info);
#endif
#if !defined (ftp_logout)
UINT ftp_logout(struct NX_FTP_SERVER_STRUCT *ftp_server_ptr, NXD_ADDRESS *client_ip_address, UINT client_port,
        CHAR *name, CHAR *password, CHAR *extra_info);
#endif
#else
            #if !defined (ftp_login)
            UINT ftp_login(struct NX_FTP_SERVER_STRUCT *ftp_server_ptr, ULONG client_ip_address, UINT client_port, CHAR *name, CHAR *password, CHAR *extra_info);
            #endif
            #if !defined (ftp_logout)
            UINT ftp_logout(struct NX_FTP_SERVER_STRUCT *ftp_server_ptr, ULONG client_ip_address, UINT client_port, CHAR *name, CHAR *password, CHAR *extra_info);
            #endif
            #endif /*NX_DISABLE_IPV6*/
void g_ftp_server0_err_callback(void *p_instance, void *p_data);
void ftp_server_init0(void);
extern NX_FTP_CLIENT g_ftp_client0;
void g_ftp_client0_err_callback(void *p_instance, void *p_data);
void ftp_client_init0(void);
extern NX_DNS g_dns0;
void g_dns0_err_callback(void *p_instance, void *p_data);
void dns_client_init0(void);
extern NX_DHCP_SERVER g_dhcp_server0;
void g_dhcp_server0_err_callback(void *p_instance, void *p_data);
void nx_dhcp_server_init0(void);
extern NX_DHCP g_dhcp_client0;
void g_dhcp_client0_err_callback(void *p_instance, void *p_data);
void dhcp_client_init0(void);

#define DHCP_USR_OPT_ADD_ENABLE_g_dhcp_client0 (0)
#define DHCP_USR_OPT_ADD_FUNCTION_ENABLE_g_dhcp_client0 (1)

#if DHCP_USR_OPT_ADD_ENABLE_g_dhcp_client0
            UINT dhcp_user_option_add_client0(NX_DHCP *dhcp_ptr, UINT iface_index, UINT message_type, UCHAR *user_option_ptr, UINT *user_option_length);
            #if DHCP_USR_OPT_ADD_FUNCTION_ENABLE_g_dhcp_client0
            extern UCHAR g_dhcp_client0_opt_num;
            extern CHAR *g_dhcp_client0_opt_val;
            #endif
            #endif
extern NX_AUTO_IP g_auto_ip0;
void g_auto_ip0_err_callback(void *p_instance, void *p_data);
void auto_ip_init0(void);
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* NEW_THREAD0_H_ */
