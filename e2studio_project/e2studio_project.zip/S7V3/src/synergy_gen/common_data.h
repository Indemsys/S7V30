/* generated common header file - do not edit */
#ifndef COMMON_DATA_H_
#define COMMON_DATA_H_
#include <stdint.h>
#include "bsp_api.h"
#include "r_dtc.h"
#include "r_transfer_api.h"
#include "r_sci_spi.h"
#include "r_spi_api.h"
#include "r_cgc_api.h"
#include "r_spi_api.h"
#include "sf_spi.h"
#include "sf_spi_api.h"
#include "r_riic.h"
#include "r_i2c_api.h"
#include "r_i2c_api.h"
#include "sf_i2c.h"
#include "sf_i2c_api.h"

#include "nx_api.h"
#include "nx_md5.h"
#include "r_crypto_api.h"
#include "r_aes_api.h"
#include "r_rsa_api.h"
#include "r_ecc_api.h"
#include "r_hash_api.h"
#include "r_trng_api.h"
#include "r_sce.h"
#include "r_trng_api.h"
#include "sf_crypto.h"
#include "sf_crypto_api.h"
#include "nx_crypto_sce_config.h"
#include "nx_secure_tls.h"
#include "nx_secure_tls_api.h"
#include "r_icu.h"
#include "r_external_irq_api.h"
#include "sf_wifi_api.h"
#include "sf_wifi_gt202.h"
#if !SF_WIFI_GT202_CFG_ONCHIP_STACK_SUPPORT
#include "sf_wifi_nsal_api.h"
#endif
#include "nx_api.h"
#include "sf_wifi_nsal_nx.h"
#include "r_dmac.h"
#include "r_transfer_api.h"
#include "r_sdmmc.h"
#include "r_sdmmc_api.h"
#include "sf_block_media_sdmmc.h"
#include "sf_block_media_api.h"
#include "sf_el_fx.h"
#include "nx_api.h"
#include "nx_ppp.h"
#include "nx_api.h"

#include "nxd_bsd.h"
#include "fx_api.h"
#include "fx_api.h"
#include "r_fmi.h"
#include "r_fmi_api.h"
#include "r_ioport.h"
#include "r_ioport_api.h"
#include "r_elc.h"
#include "r_elc_api.h"
#include "r_cgc.h"
#include "r_cgc_api.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer10;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer9;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
extern const spi_cfg_t g_spi1_cfg;
/** SPI on SCI Instance. */
extern const spi_instance_t g_spi1;
extern sci_spi_instance_ctrl_t g_spi1_ctrl;
extern const sci_spi_extended_cfg g_spi1_cfg_extend;

#ifndef NULL
void NULL(spi_callback_args_t *p_args);
#endif

#define SYNERGY_NOT_DEFINED (1)            
#if (SYNERGY_NOT_DEFINED == g_transfer9)
    #define g_spi1_P_TRANSFER_TX (NULL)
#else
#define g_spi1_P_TRANSFER_TX (&g_transfer9)
#endif
#if (SYNERGY_NOT_DEFINED == g_transfer10)
    #define g_spi1_P_TRANSFER_RX (NULL)
#else
#define g_spi1_P_TRANSFER_RX (&g_transfer10)
#endif
#undef SYNERGY_NOT_DEFINED

#define g_spi1_P_EXTEND (&g_spi1_cfg_extend)
extern sf_spi_bus_t g_sf_spi_bus0;
extern spi_api_t const g_spi_on_sci;

#define g_sf_spi_bus0_CHANNEL        (0)
#define g_sf_spi_bus0_OPERATING_MODE (SPI_MODE_MASTER)
#define g_sf_spi_bus0_CLK_PHASE      (SPI_CLK_PHASE_EDGE_ODD)
#define g_sf_spi_bus0_CLK_POLARITY   (SPI_CLK_POLARITY_LOW)          
#define g_sf_spi_bus0_MODE_FAULT     (SPI_MODE_FAULT_ERROR_DISABLE)
#define g_sf_spi_bus0_BIT_ORDER      (SPI_BIT_ORDER_MSB_FIRST)          
#define g_sf_spi_bus0_BIT_RATE       (100000)  
#define g_sf_spi_bus0_P_CALLBACK     (NULL)
#define g_sf_spi_bus0_P_CONTEXT      (&g_spi1)
#define g_sf_spi_bus0_RXI_IPL        ((12))
#define g_sf_spi_bus0_TXI_IPL        ((12))
#define g_sf_spi_bus0_TEI_IPL        ((12))            
#define g_sf_spi_bus0_ERI_IPL        ((12))

/** These are obtained by macros in the SPI driver XMLs. */
#define g_sf_spi_bus0_P_TRANSFER_TX  (g_spi1_P_TRANSFER_TX)
#define g_sf_spi_bus0_P_TRANSFER_RX  (g_spi1_P_TRANSFER_RX)            
#define g_sf_spi_bus0_P_EXTEND       (g_spi1_P_EXTEND)
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer8;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer7;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
extern const i2c_cfg_t g_i2c0_cfg;
/** I2C on RIIC Instance. */
extern const i2c_master_instance_t g_i2c0;
#ifndef NULL
void NULL(i2c_callback_args_t *p_args);
#endif

extern riic_instance_ctrl_t g_i2c0_ctrl;
extern const riic_extended_cfg g_i2c0_extend;
#define SYNERGY_NOT_DEFINED (1)            
#if (SYNERGY_NOT_DEFINED == g_transfer7)
    #define g_i2c0_P_TRANSFER_TX (NULL)
#else
#define g_i2c0_P_TRANSFER_TX (&g_transfer7)
#endif
#if (SYNERGY_NOT_DEFINED == g_transfer8)
    #define g_i2c0_P_TRANSFER_RX (NULL)
#else
#define g_i2c0_P_TRANSFER_RX (&g_transfer8)
#endif
#undef SYNERGY_NOT_DEFINED
#define g_i2c0_P_EXTEND (&g_i2c0_extend)
extern sf_i2c_bus_t g_sf_i2c_bus0;
extern i2c_api_master_t const g_i2c_master_on_riic;

#define g_sf_i2c_bus0_CHANNEL        (0)
#define g_sf_i2c_bus0_RATE           (I2C_RATE_STANDARD)
#define g_sf_i2c_bus0_SLAVE          (0)
#define g_sf_i2c_bus0_ADDR_MODE      (I2C_ADDR_MODE_7BIT)          
#define g_sf_i2c_bus0_SDA_DELAY      (300)  
#define g_sf_i2c_bus0_P_CALLBACK     (NULL)
#define g_sf_i2c_bus0_P_CONTEXT      (&g_i2c0)
#define g_sf_i2c_bus0_RXI_IPL        ((12))
#define g_sf_i2c_bus0_TXI_IPL        ((12))
#define g_sf_i2c_bus0_TEI_IPL        ((12))            
#define g_sf_i2c_bus0_ERI_IPL        ((12))

/** These are obtained by macros in the I2C driver XMLs. */
#define g_sf_i2c_bus0_P_TRANSFER_TX  (g_i2c0_P_TRANSFER_TX)
#define g_sf_i2c_bus0_P_TRANSFER_RX  (g_i2c0_P_TRANSFER_RX)            
#define g_sf_i2c_bus0_P_EXTEND       (g_i2c0_P_EXTEND)
extern const crypto_instance_t g_sce_0;
#define R_SCE_SERVICES_AES_PLAIN_TEXT_128_ECB   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_128_CBC   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_128_CTR   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_128_GCM   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_128_XTS   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_192_ECB   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_192_CBC   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_192_CTR   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_192_GCM   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_256_ECB   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_256_CBC   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_256_CTR   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_256_GCM   (1)
#define R_SCE_SERVICES_AES_PLAIN_TEXT_256_XTS   (1)
#define R_SCE_SERVICES_AES_WRAPPED_128_ECB      (1)
#define R_SCE_SERVICES_AES_WRAPPED_128_CBC      (1)
#define R_SCE_SERVICES_AES_WRAPPED_128_CTR      (1)
#define R_SCE_SERVICES_AES_WRAPPED_128_GCM      (1)
#define R_SCE_SERVICES_AES_WRAPPED_128_XTS      (1)
#define R_SCE_SERVICES_AES_WRAPPED_192_ECB      (1)
#define R_SCE_SERVICES_AES_WRAPPED_192_CBC      (1)
#define R_SCE_SERVICES_AES_WRAPPED_192_CTR      (1)
#define R_SCE_SERVICES_AES_WRAPPED_192_GCM      (1)
#define R_SCE_SERVICES_AES_WRAPPED_256_ECB      (1)
#define R_SCE_SERVICES_AES_WRAPPED_256_CBC      (1)
#define R_SCE_SERVICES_AES_WRAPPED_256_CTR      (1)
#define R_SCE_SERVICES_AES_WRAPPED_256_GCM      (1)
#define R_SCE_SERVICES_AES_WRAPPED_256_XTS      (1)
#define R_SCE_SERVICES_RSA_PLAIN_TEXT_1024      (1)
#define R_SCE_SERVICES_RSA_PLAIN_TEXT_2048      (1)
#define R_SCE_SERVICES_RSA_WRAPPED_1024         (1)
#define R_SCE_SERVICES_RSA_WRAPPED_2048         (1)
#define R_SCE_SERVICES_ECC_PLAIN_TEXT_192       (1)
#define R_SCE_SERVICES_ECC_PLAIN_TEXT_224       (1)
#define R_SCE_SERVICES_ECC_PLAIN_TEXT_256       (1)
#define R_SCE_SERVICES_ECC_PLAIN_TEXT_384       (1)
#define R_SCE_SERVICES_ECC_WRAPPED_192          (1)
#define R_SCE_SERVICES_ECC_WRAPPED_224          (1)
#define R_SCE_SERVICES_ECC_WRAPPED_256          (1)
#define R_SCE_SERVICES_ECC_WRAPPED_384          (1)
#define R_SCE_SERVICES_HASH_SHA1                (1)
#define R_SCE_SERVICES_HASH_SHA256              ((1) || (1))
#define R_SCE_SERVICES_HASH_MD5                 (1)
#define R_SCE_SERVICES_TRNG                     (1)
extern const trng_instance_t g_sce_trng;
extern const sf_crypto_instance_t g_sf_crypto0;
/** Software based crypto ciphers for use with nx_secure_tls_session_create. */
extern const NX_SECURE_TLS_CRYPTO nx_crypto_tls_ciphers;
/* External IRQ on ICU Instance. */
extern const external_irq_instance_t g_external_irq0;
#ifndef custom_hw_irq_isr
void custom_hw_irq_isr(external_irq_callback_args_t *p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer6;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer5;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
extern const spi_cfg_t g_spi0_cfg;
/** SPI on SCI Instance. */
extern const spi_instance_t g_spi0;
extern sci_spi_instance_ctrl_t g_spi0_ctrl;
extern const sci_spi_extended_cfg g_spi0_cfg_extend;

#ifndef NULL
void NULL(spi_callback_args_t *p_args);
#endif

#define SYNERGY_NOT_DEFINED (1)            
#if (SYNERGY_NOT_DEFINED == g_transfer5)
    #define g_spi0_P_TRANSFER_TX (NULL)
#else
#define g_spi0_P_TRANSFER_TX (&g_transfer5)
#endif
#if (SYNERGY_NOT_DEFINED == g_transfer6)
    #define g_spi0_P_TRANSFER_RX (NULL)
#else
#define g_spi0_P_TRANSFER_RX (&g_transfer6)
#endif
#undef SYNERGY_NOT_DEFINED

#define g_spi0_P_EXTEND (&g_spi0_cfg_extend)
void sf_wifi_gt202_init0(void);
/** sf_wifi_v2 on GT202 Wi-Fi Driver instance */
extern sf_wifi_instance_t g_sf_wifi0;
#ifdef NULL
		#define SF_WIFI_ON_WIFI_GT202_CALLBACK_USED_g_sf_wifi0 (0)
		#else
#define SF_WIFI_ON_WIFI_GT202_CALLBACK_USED_g_sf_wifi0 (1)
#endif
#if SF_WIFI_ON_WIFI_GT202_CALLBACK_USED_g_sf_wifi0
/** Declaration of user callback function. This function MUST be defined in the user application.*/
void NULL(sf_wifi_callback_args_t *p_args);
#endif
/** NetX driver entry function. */
VOID g_sf_el_nx0(NX_IP_DRIVER *p_driver);

/* Transfer on DMAC Instance. */
extern const transfer_instance_t g_transfer4;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/* Transfer on DMAC Instance. */
extern const transfer_instance_t g_transfer3;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
#include "ux_api.h"
#include "ux_hcd_synergy.h"
#include "sf_el_ux_hcd_hs_cfg.h"
/* Transfer on DMAC Instance. */
extern const transfer_instance_t g_transfer2;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/* Transfer on DMAC Instance. */
extern const transfer_instance_t g_transfer1;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
#include "ux_api.h"
#include "ux_dcd_synergy.h"
#include "sf_el_ux_dcd_fs_cfg.h"
void g_sf_el_ux_dcd_fs_0_err_callback(void *p_instance, void *p_data);
#include "ux_api.h"

/* USBX Host Stack initialization error callback function. User can override the function if needed. */
void ux_v2_err_callback(void *p_instance, void *p_data);

#if !defined(NULL)
/* User Callback for Host Event Notification (Only valid for USB Host). */
extern UINT NULL(ULONG event, UX_HOST_CLASS *host_class, VOID *instance);
#endif

#if !defined(NULL)
/* User Callback for Device Event Notification (Only valid for USB Device). */
extern UINT NULL(ULONG event);
#endif

#ifdef UX_HOST_CLASS_STORAGE_H
            /* Utility function to get the pointer to a FileX Media Control Block for a USB Mass Storage device. */
            UINT ux_system_host_storage_fx_media_get(UX_HOST_CLASS_STORAGE * instance, UX_HOST_CLASS_STORAGE_MEDIA ** p_storage_media, FX_MEDIA ** p_fx_media);
#endif
void ux_common_init0(void);

/* Function prototype for the function to register the USBX Host Class Mass Storage. */
void ux_host_stack_class_register_storage(void);
/* Function prototype for the function to notify a USB event from the USBX Host system. */
UINT ux_system_host_change_function(ULONG event, UX_HOST_CLASS *host_class, VOID *instance);
/* memory pool allocation used by USBX system. */
extern CHAR g_ux_pool_memory[];
void g_ux_host_0_err_callback(void *p_instance, void *p_data);
void ux_host_init0(void);
/* Transfer on DMAC Instance. */
extern const transfer_instance_t g_transfer0;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/** SDMMC on SDMMC Instance. */
extern const sdmmc_instance_t g_sdmmc0;
#ifndef NULL
void NULL(sdmmc_callback_args_t *p_args);
#endif
/** Block Media on SDMMC Instance */
extern sf_block_media_instance_t g_sf_block_media_sdmmc0;
extern sf_el_fx_t g_sf_el_fx0_cfg;
#ifndef NULL
void NULL(sf_el_fx_callback_args_t *p_args);
#endif
void nx_common_init0(void);
extern ssp_err_t sce_initialize(void);
extern void nx_secure_tls_initialize(void);
extern void nx_secure_common_init(void);
extern NX_PACKET_POOL g_packet_pool0;
void g_packet_pool0_err_callback(void *p_instance, void *p_data);
void packet_pool_init0(void);
extern NX_IP g_ip0;
void g_ip0_err_callback(void *p_instance, void *p_data);
void ip_init0(void);
void nx_bsd_err_callback(void *p_instance, void *p_data);
void nx_bsd_init0(void);
void fx_common_init0(void);
extern FX_MEDIA g_fx_media0;

void g_fx_media0_err_callback(void *p_instance, void *p_data);
ssp_err_t fx_media_init0_format(void);
uint32_t fx_media_init0_open(void);
void fx_media_init0(void);
/** FMI on FMI Instance. */
extern const fmi_instance_t g_fmi;
/** IOPORT Instance */
extern const ioport_instance_t g_ioport;
/** ELC Instance */
extern const elc_instance_t g_elc;
/** CGC Instance */
extern const cgc_instance_t g_cgc;
void g_common_init(void);
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* COMMON_DATA_H_ */
