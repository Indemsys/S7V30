/* generated thread header file - do not edit */
#ifndef NEW_THREAD1_H_
#define NEW_THREAD1_H_
#include "bsp_api.h"
#include "tx_api.h"
#include "hal_data.h"
#ifdef __cplusplus
                extern "C" void new_thread1_entry(void);
                #else
extern void new_thread1_entry(void);
#endif
#include "r_iwdt.h"
#include "r_wdt_api.h"
#include "r_wdt.h"
#include "r_wdt_api.h"
#include "r_rtc.h"
#include "r_rtc_api.h"
#include "r_dtc.h"
#include "r_transfer_api.h"
#include "r_sci_uart.h"
#include "r_uart_api.h"
#include "sf_block_media_ram.h"
#include "sf_block_media_api.h"
#include "r_agt.h"
#include "r_timer_api.h"
#include "r_adc.h"
#include "r_adc_api.h"
#include "sf_adc_periodic.h"
#include "sf_crypto_trng.h"
#include "r_hash_api.h"
#include "sf_crypto_hash.h"
#include "sf_crypto_signature.h"
#include "r_sce_key_installation.h"
#include "sf_crypto_key_installation.h"
#include "sf_crypto_key.h"
#include "sf_crypto_cipher.h"
#include "r_can.h"
#include "r_can_api.h"
#ifdef __cplusplus
extern "C" {
#endif
/** WDT on IWDT Instance. */
extern const wdt_instance_t g_wdt1;
#ifndef NULL
void NULL(wdt_callback_args_t *p_args);
#endif
/** WDT on WDT Instance. */
extern const wdt_instance_t g_wdt0;
#ifndef NULL
void NULL(wdt_callback_args_t *p_args);
#endif
/** RTC on RTC Instance. */
extern const rtc_instance_t g_rtc0;
#ifndef NULL
void NULL(rtc_callback_args_t *p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer13;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer12;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/** UART on SCI Instance. */
extern const uart_instance_t g_uart0;
#ifdef NULL
            #else
extern void NULL(uint32_t channel, uint32_t level);
#endif
#ifndef user_uart_callback
void user_uart_callback(uart_callback_args_t *p_args);
#endif
/** Block Media on RAM Instance */
extern sf_block_media_instance_t g_sf_block_media_ram0;
/* Transfer on DTC Instance. */
extern const transfer_instance_t g_transfer11;
#ifndef NULL
void NULL(transfer_callback_args_t *p_args);
#endif
/** AGT Timer Instance */
extern const timer_instance_t g_timer0;
#ifndef NULL
void NULL(timer_callback_args_t *p_args);
#endif
/** ADC on ADC Instance. */
extern const adc_instance_t g_adc0;
#ifndef NULL
void NULL(adc_callback_args_t *p_args);
#endif
/** ADC Periodic on ADC Periodic instance */
extern sf_adc_periodic_instance_t g_sf_adc_periodic0;
/** Buffer where the sampled data will be stored for application usage */
#define SF_ADC_PERIODIC_PRV_ADC_RESOLUTION_12_BIT
#ifdef SF_ADC_PERIODIC_PRV_ADC_RESOLUTION_24_BIT
            extern uint32_t g_user_buffer[128];
            #else
extern uint16_t g_user_buffer[128];
#endif
#ifndef g_adc_framework_user_callback
void g_adc_framework_user_callback(sf_adc_periodic_callback_args_t *p_args);
#endif
void g_sf_adc_periodic0_err_callback(void *p_instance, void *p_data);
void sf_adc_periodic_init0(void);
extern sf_crypto_trng_instance_t g_sf_crypto_trng1;
void g_sf_crypto_trng1_err_callback(void *p_instance, void *p_data);
void sf_crypto_trng_init1(void);
extern const hash_instance_t g_sce_hash_1;
extern sf_crypto_hash_instance_t g_sf_crypto_hash1;

/* Crypto HASH Framework Initialization Function for the instance 'g_sf_crypto_hash1'. */
void sf_crypto_hash_init1(void);
/* Crypto HASH Framework Error Callback Function for the instance 'g_sf_crypto_hash1'. */
void g_sf_crypto_hash1_err_callback(void *p_instance, void *p_data);
extern sf_crypto_signature_instance_t g_sf_crypto_signature0;
void g_sf_crypto_signature0_err_callback(void *p_instance, void *p_data);
void sf_crypto_signature_init0(void);
extern key_installation_instance_t g_sce_key_installation_0;
extern sf_crypto_key_installation_instance_t g_sf_crypto_key_installation0;
void g_sf_crypto_key_installation0_err_callback(void *p_instance, void *p_data);
void sf_crypto_key_installation_init0(void);
extern sf_crypto_key_instance_t g_sf_crypto_key0;
void g_sf_crypto_key0_err_callback(void *p_instance, void *p_data);
void sf_crypto_key_init0(void);
extern const hash_instance_t g_sce_hash_0;
extern sf_crypto_hash_instance_t g_sf_crypto_hash0;

/* Crypto HASH Framework Initialization Function for the instance 'g_sf_crypto_hash0'. */
void sf_crypto_hash_init0(void);
/* Crypto HASH Framework Error Callback Function for the instance 'g_sf_crypto_hash0'. */
void g_sf_crypto_hash0_err_callback(void *p_instance, void *p_data);
extern sf_crypto_trng_instance_t g_sf_crypto_trng0;
void g_sf_crypto_trng0_err_callback(void *p_instance, void *p_data);
void sf_crypto_trng_init0(void);
extern sf_crypto_cipher_instance_t g_sf_crypto_cipher0;
void g_sf_crypto_cipher0_err_callback(void *p_instance, void *p_data);
void sf_crypto_cipher_init0(void);
/** CAN on CAN Instance. */
extern const can_instance_t g_can1;
#ifndef CAN_callback
void CAN_callback(can_callback_args_t *p_args);
#endif
#define CAN_NO_OF_MAILBOXES_g_can1 (32)
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* NEW_THREAD1_H_ */
