#include "new_thread0.h"

/* Net entry function */
void new_thread0_entry(void)
{
    /* TODO: add your own code here */
    while (1)
    {
        tx_thread_sleep (1);
    }
}
