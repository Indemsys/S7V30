/***********************************************************************************************************************
 * Copyright [2017-2021] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
 *
 * This file is part of Renesas SynergyTM Software Package (SSP)
 *
 * The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
 * and/or its licensors ("Renesas") and subject to statutory and contractual protections.
 *
 * This file is subject to a Renesas SSP license agreement. Unless otherwise agreed in an SSP license agreement with
 * Renesas: 1) you may not use, copy, modify, distribute, display, or perform the contents; 2) you may not use any name
 * or mark of Renesas for advertising or publicity purposes or in connection with your use of the contents; 3) RENESAS
 * MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED
 * "AS IS" WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, AND NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR
 * CONSEQUENTIAL DAMAGES, INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF
 * CONTRACT OR TORT, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents
 * included in this file may be subject to different terms.
**********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name    : r_sce_ecc.h
 * Description  : SCE ECC module common HAL APIs interface
***********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @ingroup SCE
 * @addtogroup SCE_ECC
 * @{
***********************************************************************************************************************/

#ifndef SSP_SRC_DRIVER_R_SCE_ECC_H_
#define SSP_SRC_DRIVER_R_SCE_ECC_H_

#include "bsp_api.h"
#include "r_ecc_api.h"
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define SCE_ECC_CODE_VERSION_MAJOR   (1U)
#define SCE_ECC_CODE_VERSION_MINOR   (0U)

ssp_err_t R_SCE_ECC_Open(ecc_ctrl_t * const p_ctrl, ecc_cfg_t const * const p_cfg);
ssp_err_t R_SCE_ECC_Close(ecc_ctrl_t * const p_ctrl);
ssp_err_t R_SCE_ECC_VersionGet(ssp_version_t * const p_version);

#endif /* SSP_SRC_DRIVER_R_SCE_ECC_H_ */

/*******************************************************************************************************************//**
 * @} (end addtogroup SCE_ECC)
***********************************************************************************************************************/
